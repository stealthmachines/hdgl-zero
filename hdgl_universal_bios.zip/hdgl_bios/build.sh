#!/bin/bash
# HDGL Universal BIOS — build script
# Requires: nasm
set -e
echo "[1/4] Assemble MBR stage1 (sector 0, 512B)..."
nasm -f bin hdgl_mbr.asm -o hdgl_mbr.bin

echo "[2/4] Assemble stage2 stub (sector 1, 512B)..."
nasm -f bin hdgl_stage2.asm -o hdgl_stage2.bin

echo "[3/4] Assemble runtime (sectors 2-17, 8KB)..."
nasm -f bin firmware_runtime_full.asm -o firmware_runtime_full.bin

echo "[4/4] Compose image..."
SRC=hdgl_firmware.hdgl
SRCSEC=$(( ($(wc -c < $SRC) + 511) / 512 ))
TOTAL=$(( 18 + SRCSEC + 4 ))
dd if=/dev/zero bs=512 count=$TOTAL of=hdgl_universal_bios.img 2>/dev/null
dd if=hdgl_mbr.bin             bs=512 count=1        seek=0  conv=notrunc of=hdgl_universal_bios.img 2>/dev/null
dd if=hdgl_stage2.bin          bs=512 count=1        seek=1  conv=notrunc of=hdgl_universal_bios.img 2>/dev/null
dd if=firmware_runtime_full.bin bs=512 count=16      seek=2  conv=notrunc of=hdgl_universal_bios.img 2>/dev/null
dd if=$SRC                     bs=512 count=$SRCSEC  seek=18 conv=notrunc of=hdgl_universal_bios.img 2>/dev/null

echo ""
echo "Built: hdgl_universal_bios.img"
echo ""
echo "Run in QEMU:"
echo "  qemu-system-x86_64 -drive file=hdgl_universal_bios.img,format=raw,if=ide -boot order=c -m 64M -serial stdio"
echo ""
echo "Flash to USB/disk:"
echo "  dd if=hdgl_universal_bios.img of=/dev/sdX bs=512 oflag=sync"
