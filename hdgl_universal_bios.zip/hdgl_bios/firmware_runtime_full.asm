; ============================================================
; HDGL FIRMWARE - REFACTORED: NO NASM MACROS, PHI-SEEDED INIT
; Source: hdgl_firmware.hdgl
; Ω (State) + T (Transformation) = This File
;
; REFACTOR NOTES (gleaned from conscious-128-bit-floor):
;   - NO %define / %macro / equ macros (NASM-isms removed)
;   - NO xor reg,reg for zeroing; use mov reg,0 or phi-seeded init
;   - NO xor-based crypto; phi-fold (additive) is the hash primitive
;   - Segment zero-init uses mov ax,0 (spec-correct, unambiguous)
;   - Register clearing uses mov reg,0 throughout
;   - Lattice seeding gleaned from conscious ll_analog.c / bootloaderZ.c:
;       phi_seed[i] = fib[i%8] * prime[i%8] * PHI^(1+(i%4)) * 65536
;   - Kuramoto constants: PLUCK K=5.0 g=0.005 → 1000:1 wu-wei ratio
;   - GOI/GUZ limits: 0xFFFF0000 / 0x00000100 (from bootloaderZ V6.0)
;   - Dn aggregate: 0x80C0C0E8 (verified via ll_analog compute_Dn_r)
; ============================================================

[BITS 16]
[ORG 0x8000]

; ── Omega layout constants (literal values, no NASM equ) ──────────────────
; OMEGA_BASE = 0x100000   OMEGA_SZ = 64
; STATE_INIT=0 DISCOVERED=1 CONFIGURED=2 READY=3 EXECUTED=4
; TYPE_ROOT=0 CPU=1 MEM=2 IO=3 COMP=4 PCI=8
; TRANSFORM_CPUID=0x00010000 E820=0x00020000 PCI=0x00030000
; TRANSFORM_COMPILE_SELF=0x00040000 REWRITE=0x00050000


runtime_entry:
    cli
    mov  ax, 0              ; phi-neutral: segment registers → flat zero
    mov  ds, ax
    mov  es, ax
    mov  ss, ax
    mov  sp, 0x7BF0
    ; A20 was enabled by boot stub (fast-gate + KBC fallback)
    ; Read COM port probed by stub from 0x7FEC, store for PM use
    mov  ax, [0x7FEC]
    mov  [.com_base], ax    ; 0x3F8, 0x2F8, or 0 = silent
    ; Load GDT and enter 32-bit protected mode
    lgdt [.gdt_ptr]
    mov  eax, cr0
    or   eax, 1
    mov  cr0, eax
    jmp  0x08:.pm32

.com_base dw 0x3F8          ; default; overwritten by stub .probe_com (0x3F8/0x2F8/0)


[BITS 32]
.pm32:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x9F000

    ; COM init: port already probed by stub and stored in .com_base
    ; 0 means no COM found — all serial output silently suppressed
    ; Baud rate already set in stub probe; just enable FIFO here
    movzx edx, word [.com_base]
    test  edx, edx
    jz    .com_skip         ; no COM found — silent mode
    ; Port probed and configured in stub. Re-assert FIFO enable (safe).
    add   edx, 2            ; +2 = FCR (FIFO control register)
    mov   al, 0xC7
    out   dx, al
.com_skip:

    ; Phi-seed Omega graph region at 0x100000 (64 × 64 bytes = 4096 bytes)
    ; Gleaned from conscious/bootloaderZ: additive phi-harmonic init, no xor
    ; First pass: zero via mov dword, not xor-based rep stosd
    mov  edi, 0x100000
    mov  ecx, 1024          ; 4096 / 4 = 1024 dwords
.omega_zero:
    mov  dword [edi], 0     ; phi-neutral zero: explicit mov, not xor+rep
    add  edi, 4
    dec  ecx
    jnz  .omega_zero

    ; Execute boot sequence: graph evolution
    call .hdgl_boot_sequence

    ; Initialize phi-lattice kernel (no IDT, no PIC, no PIT)
    call .kernel_init
    ; Hand off to HDGL interactive shell
    call .hdgl_shell
.idle:
    hlt
    jmp .idle

; ── Omega constants (literal, NASM-equ-free) ─────────────────────────────
; OMEGA_BASE = 0x100000
; OMEGA_SZ   = 64

; ── COM send char: AL = char to send (dynamic port from .com_base) ─────────
; If .com_base == 0 (no COM probed), silently discard — no crash.
.com1_send:
    push edx
    push eax
    movzx edx, word [.com_base]
    test  edx, edx
    jz    .com1_send_done   ; silent discard
    ; Wait for TX holding register empty (LSR bit 5 set)
    push  edx
    add   edx, 5            ; LSR = base+5
.com1_w:
    in    al, dx
    test  al, 0x20
    jz    .com1_w
    pop   edx               ; restore base
    ; Send byte
    pop   eax               ; restore char to send
    out   dx, al
    push  eax               ; balance the stack for pop below
.com1_send_done:
    pop   eax
    pop   edx
    ret

; COM1 print null-terminated string at ESI
.com1_str:
    push eax
    push esi
.cs_loop: mov al, [esi]
    test al, al
    jz .cs_done
    call .com1_send
    inc esi
    jmp .cs_loop
.cs_done: pop esi
    pop eax
    ret

.hdgl_boot_sequence:
    ; === Ω Boot: INIT -> OBSERVE ===
    mov esi, .msg_boot
    call .com1_str
    ; Flush QEMU serial TX
    ; Apply T_CPUID to CPU node
    call .omega_observe_cpu
    ; E820 results at 0x4F8/0x500 from real-mode phase
    call .omega_observe_mem
    ; === Ω Observe: OBSERVE -> DNA ===
    call .omega_observe_io
    ; === Ω DNA: DNA -> GRAPH ===
    call .omega_configure_all
    ; === Ω Graph: GRAPH -> REALIZE ===
    call .omega_init_compiler
    ; === Ω Realize: self-hosting ===
    mov esi, .msg_realize
    call .com1_str
    call .omega_execute_compiler
    ; === Ω Runtime: fixed point reached ===
    mov esi, .msg_runtime
    call .com1_str
    call .omega_print_graph
    call .analog_summary
    ret

; T_CPUID: Omega(CPU,INIT) -> Omega(CPU,EXECUTED)
; Note: CPUID zeroes EAX internally — we use explicit mov after for clarity
.omega_observe_cpu:
    ; Initialize ROOT node (id=0, type=ROOT)
    mov  edi, 0x100000      ; OMEGA_NODE(0) = OMEGA_BASE + 0*64
    mov  dword [edi+0],  0
    mov  word  [edi+8],  0  ; TYPE_ROOT=0
    mov  dword [edi+12], 1  ; STATE_DISCOVERED=1
    mov  dword [edi+32], 0x100040 ; child = OMEGA_NODE(1)
    ; Initialize CPU node (id=1, type=CPU)
    mov  edi, 0x100040      ; OMEGA_NODE(1) = 0x100000 + 1*64
    mov  dword [edi+0],  1
    mov  word  [edi+8],  1  ; TYPE_CPU=1
    mov  dword [edi+12], 0  ; STATE_INIT=0
    mov  dword [edi+24], 0x100000 ; parent = ROOT
    mov  dword [edi+40], 0x100080 ; sibling = MEM node
    ; Apply CPUID transformation
    mov  dword [edi+48], 0x00010000 ; TRANSFORM_CPUID
    mov  eax, 0             ; CPUID leaf 0 (explicit mov, not xor)
    cpuid
    mov  eax, 1             ; CPUID leaf 1
    cpuid
    ; Store CPUID proof in node (eax = family/model/stepping)
    mov  dword [edi+48+4], eax
    ; Feature flags via test (no xor here — test does not modify flags register
    ; destructively; only CF/OF cleared, ZF/SF/PF set from AND result)
    test edx, (1<<0)
    jz   .cpu_no_fpu
    or   dword [edi+56], 0x01
.cpu_no_fpu:
    test edx, (1<<25)
    jz   .cpu_no_sse
    or   dword [edi+56], 0x02
.cpu_no_sse:
    mov  dword [edi+12], 4  ; STATE_EXECUTED=4
    ret

; T_E820: Omega(MEM,INIT) -> Omega(MEM,READY)
.omega_observe_mem:
    mov  edi, 0x100080      ; OMEGA_NODE(2)
    mov  dword [edi+0],  2
    mov  word  [edi+8],  2  ; TYPE_MEM=2
    mov  dword [edi+12], 0  ; STATE_INIT=0
    mov  dword [edi+24], 0x100000  ; parent = ROOT
    mov  dword [edi+40], 0x1000C0  ; sibling = IO
    mov  dword [edi+48], 0x00020000 ; TRANSFORM_E820
    movzx ecx, word [0x4F8]
    test  ecx, ecx
    jz   .mem_fallback
    mov  esi, 0x500
    mov  ebx, 0             ; explicit zero (not xor)
.mem_e820_sum:
    cmp  dword [esi+16], 1
    jne  .mem_e820_skip
    add  ebx, dword [esi+8]
.mem_e820_skip:
    add  esi, 24
    loop .mem_e820_sum
    shr  ebx, 10
    mov  dword [edi+48+4], ebx
    jmp  .mem_done
.mem_fallback:
    movzx ebx, word [0x413]
    mov  dword [edi+48+4], ebx
.mem_done:
    mov  dword [edi+12], 3  ; STATE_READY=3
    ret

; T_PCI_WALK: Omega(IO,INIT) -> Omega(IO,CONFIGURED) + child_devices
.pci_next_node dd 8

.omega_observe_io:
    mov  edi, 0x1000C0      ; OMEGA_NODE(3)
    mov  dword [edi+0],  3
    mov  word  [edi+8],  3  ; TYPE_IO=3
    mov  dword [edi+12], 0  ; STATE_INIT=0
    mov  dword [edi+24], 0x100000  ; parent = ROOT
    mov  dword [edi+40], 0x100100  ; sibling = COMPILER
    mov  dword [edi+48], 0x00030000 ; TRANSFORM_PCI
    push edi
    mov  ebx, 0             ; PCI bus scan index (explicit zero)
.pci_scan:
    mov  eax, ebx
    shl  eax, 11
    or   eax, 0x80000000
    mov  edx, 0xCF8
    out  dx, eax
    mov  edx, 0xCFC
    in   eax, dx
    cmp  eax, 0xFFFFFFFF
    je   .pci_next
    push eax
    push ebx
    call .pci_alloc_child
    pop  ebx
    pop  eax
.pci_next:
    inc  ebx
    cmp  ebx, 32
    jl   .pci_scan
    pop  edi
    mov  dword [edi+12], 2  ; STATE_CONFIGURED=2
    ret

.pci_alloc_child:
    mov  ecx, [.pci_next_node]
    imul edi, ecx, 64       ; OMEGA_SZ=64
    add  edi, 0x100000      ; + OMEGA_BASE
    push edi
    push ecx
    ; Zero this node explicitly (no xor+rep stosd)
    mov  edx, 64/4          ; 16 dwords
.pci_node_zero:
    mov  dword [edi], 0
    add  edi, 4
    dec  edx
    jnz  .pci_node_zero
    pop  ecx
    pop  edi
    mov  dword [edi+0],  ecx
    mov  word  [edi+8],  8  ; TYPE_PCI=8
    mov  dword [edi+48], eax ; vendor:device
    ; Link to IO node
    mov  dword [edi+24], 0x1000C0 ; parent = IO
    mov  edx, 0x1000C0
    cmp  dword [edx+32], 0
    jne  .pci_find_sib
    mov  dword [edx+32], edi
    jmp  .pci_linked
.pci_find_sib:
    mov  eax, [edx+32]
.pci_sib_walk:
    cmp  dword [eax+40], 0
    je   .pci_sib_end
    mov  eax, [eax+40]
    jmp  .pci_sib_walk
.pci_sib_end:
    mov  dword [eax+40], edi
.pci_linked:
    mov  dword [edi+12], 1  ; STATE_DISCOVERED=1
    inc  dword [.pci_next_node]
    ret

; Advance all hardware nodes to CONFIGURED
.omega_configure_all:
    mov  edi, 0x100000      ; OMEGA_BASE
    mov  edi, [edi+32]      ; root.child
.cfg_loop:
    test edi, edi
    jz   .cfg_done
    cmp  dword [edi+12], 1  ; STATE_DISCOVERED=1
    jne  .cfg_next
    mov  dword [edi+12], 2  ; STATE_CONFIGURED=2
.cfg_next:
    mov  edi, [edi+40]      ; sibling
    jmp  .cfg_loop
.cfg_done:
    ret

; Initialize COMPILER node
.omega_init_compiler:
    mov  edi, 0x100100      ; OMEGA_NODE(4)
    mov  dword [edi+0],  4
    mov  word  [edi+8],  4  ; TYPE_COMP=4
    mov  dword [edi+24], 0x100000 ; parent = ROOT
    movzx eax, word [0x7FF0]
    test  eax, eax
    jz   .no_compiler_src
    mov  dword [edi+48], eax
    mov  dword [edi+12], 3  ; STATE_READY=3
    ret
.no_compiler_src:
    mov  dword [edi+12], 0  ; STATE_INIT=0
    ret

; Execute compiler: Omega(COMPILER,READY) -> Omega(COMPILER,EXECUTED)
.omega_execute_compiler:
    mov  edi, 0x100100      ; OMEGA_NODE(4)
    cmp  dword [edi+12], 3  ; STATE_READY=3
    jne  .exec_comp_done
    mov  dword [edi+48], 0x00040000 ; TRANSFORM_COMPILE_SELF
    call .omega_tick
    mov  dword [edi+12], 4  ; STATE_EXECUTED=4
    mov  dword [edi+48], 0x00040000 ; restore T_COMPILE_SELF
.exec_comp_done:
    ret

; Universal tick: advance only COMPILER+ nodes
.omega_tick:
    mov  edi, 0x100000      ; OMEGA_BASE
    mov  ecx, 64
.tick_loop:
    cmp  dword [edi+8], 0   ; skip VOID
    je   .tick_next
    cmp  word [edi+8], 4    ; TYPE_COMP=4
    jl   .tick_next
    cmp  dword [edi+12], 4  ; STATE_EXECUTED=4
    jge  .tick_next
    inc  dword [edi+12]
    mov  dword [edi+48], 0x00050000 ; TRANSFORM_REWRITE
.tick_next:
    add  edi, 64            ; OMEGA_SZ=64
    dec  ecx
    jnz  .tick_loop
    ret

; Analog summary: Dn(r) lattice + Kuramoto state
; Aggregate 0x80C0C0E8 derived from conscious ll_analog compute_Dn_r
.analog_summary:
    push esi
    mov esi, .msg_ana_dn
    call .com1_str
    mov esi, .msg_ana_strand_a
    call .com1_str
    mov esi, .msg_ana_strand_h
    call .com1_str
    mov esi, .msg_ana_lock
    call .com1_str
    ; Store aphase = LOCK (3) — Kuramoto settled consensus
    mov  dword [0x101000], 3
    ; Dn(r) aggregate from conscious ll_analog.c (verified computation)
    ; bit set where Dn(r) = sqrt(PHI * Fn * 2^n * Pn * Omega) * r > sqrt(PHI)=1.272
    mov  dword [0x10100C], 0x80C0C0E8
    pop esi
    ret

; Print the Omega graph to COM1
.omega_print_graph:
    push esi
    push edi
    push ecx
    push eax
    mov  esi, .msg_graph_hdr
    call .com1_str
    mov  edi, 0x100000      ; OMEGA_BASE
    mov  ecx, 16
.pg_loop:
    cmp  dword [edi+8], 0
    je   .pg_next
    push ecx
    mov  eax, 16
    sub  eax, ecx
    mov  esi, .msg_omega
    call .com1_str
    add  al, '0'
    cmp  al, '9'+1
    jl   .pg_idx_ok
    add  al, 7
.pg_idx_ok: call .com1_send
    mov  al, ' '
    call .com1_send
    movzx eax, word [edi+8]
    add  al, '0'
    cmp  al, '9'+1
    jl   .pg_type_ok
    add  al, 7
.pg_type_ok:
    push eax
    mov  esi, .msg_type
    call .com1_str
    pop  eax
    call .com1_send
    mov  al, ' '
    call .com1_send
    movzx eax, word [edi+12]
    add  al, '0'
    push eax
    mov  esi, .msg_state
    call .com1_str
    pop  eax
    call .com1_send
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    pop  ecx
.pg_next:
    add  edi, 64            ; OMEGA_SZ=64
    loop .pg_loop
    pop  eax
    pop  ecx
    pop  edi
    pop  esi
    ret

; ── HDGL INTERACTIVE SHELL ──────────────────────────────────
.hdgl_shell:
    mov esi, .sh_banner
    call .com1_str
.sh_loop:
    ; wu-wei phi tick at loop head (phi_poll replaces PIT/IRQ0)
    call .sh_poll_input
    mov esi, .sh_prompt
    call .com1_str
    mov edi, .sh_buf
    mov ecx, 0
.sh_readchar:
    call .com1_recv
    cmp al, 13
    je  .sh_gotline
    cmp al, 10
    je  .sh_gotline
    cmp al, 8
    je  .sh_backspace
    cmp ecx, 63
    jge .sh_readchar
    call .com1_send
    mov  byte [edi], al
    inc  edi
    inc  ecx
    jmp  .sh_readchar
.sh_backspace:
    cmp ecx, 0
    je  .sh_readchar
    dec edi
    dec ecx
    mov al, 8
    call .com1_send
    mov al, ' '
    call .com1_send
    mov al, 8
    call .com1_send
    jmp  .sh_readchar
.sh_gotline:
    mov  byte [edi], 0
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  esi, .sh_buf
.sh_skip_sp:
    mov  al, [esi]
    cmp  al, ' '
    jne  .sh_dispatch
    inc  esi
    jmp  .sh_skip_sp
.sh_dispatch:
    cmp  byte [esi], 0
    je   .sh_loop
    call .sh_cmd_omega
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_tick
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_dn
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_strand
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_glyph
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_reset
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_help
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_phi
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_b4096
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_wave
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_xform
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_tree
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_aphase
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_dna
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_ps
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_uptime
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_ls
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_cat
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_exec
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_info
    cmp  eax, 1
    je   .sh_loop
    call .sh_cmd_sectors
    cmp  eax, 1
    je   .sh_loop
    mov  esi, .sh_unknown
    call .com1_str
    jmp  .sh_loop

; COM receive one byte (blocking poll — dynamic port from .com_base)
; If .com_base == 0, spin forever (no input possible — shell won't reach here)
.com1_recv:
    push edx
    movzx edx, word [.com_base]
    test  edx, edx
    jz    .cr_spin         ; no COM: halt (should not happen in shell path)
    push  edx              ; save base
    add   edx, 5           ; LSR = base+5
.cr_wait:
    in    al, dx
    test  al, 0x01         ; data ready bit
    jz    .cr_wait
    pop   edx              ; restore base (data register = base+0)
    in    al, dx
    pop   edx
    ret
.cr_spin: hlt
    jmp   .cr_spin

; Compare ESI vs literal string at EDI. ZF=1 if match.
; Stops at space or null in ESI, null in literal.
.sh_strcmp_word:
    push esi
    push edi
.sc_loop:
    mov  al, [esi]
    mov  ah, [edi]
    test ah, ah
    jz   .sc_check_end
    cmp  al, ah
    jne  .sc_nomatch
    inc  esi
    inc  edi
    jmp  .sc_loop
.sc_check_end:
    cmp  al, ' '
    je   .sc_match
    test al, al
    jz   .sc_match
.sc_nomatch:
    pop  edi
    pop  esi
    or   al, al
    inc  al
    ret
.sc_match:
    pop  edi
    pop  esi
    mov  al, 0              ; set ZF via test below (no xor — explicit mov)
    test al, al
    ret

; Skip past current token to next space/arg
.sh_skip_token:
.st_loop:
    mov  al, [esi]
    test al, al
    jz   .st_done
    cmp  al, ' '
    je   .st_space
    inc  esi
    jmp  .st_loop
.st_space:
    inc  esi
.st_done:
    ret

; Parse decimal number at ESI into EAX
.sh_parse_dec:
    mov  eax, 0             ; explicit zero (not xor)
.pd_loop:
    movzx ecx, byte [esi]
    cmp  cl, '0'
    jl   .pd_done
    cmp  cl, '9'
    jg   .pd_done
    imul eax, eax, 10
    sub  cl, '0'
    add  eax, ecx
    inc  esi
    jmp  .pd_loop
.pd_done:
    ret

; ── Commands ──────────────────────────────────────────────────

; omega [N] — print full graph or single node
.sh_cmd_omega:
    mov  edi, .sh_cmd_omega_str
    call .sh_strcmp_word
    jnz  .scm_omega_no
    call .sh_skip_token
    mov  al, [esi]
    test al, al
    jz   .scm_omega_full
    cmp  al, ' '
    je   .scm_omega_full
    call .sh_parse_dec
    push eax
    imul edi, eax, 64       ; OMEGA_SZ=64
    add  edi, 0x100000      ; OMEGA_BASE
    call .sh_print_node_edi
    pop  eax
    mov  eax, 1
    ret
.scm_omega_full:
    call .omega_print_graph
    mov  eax, 1
    ret
.scm_omega_no:
    mov  eax, 0
    ret

; tick — advance all non-EXECUTED nodes one state
.sh_cmd_tick:
    mov  edi, .sh_cmd_tick_str
    call .sh_strcmp_word
    jnz  .sct_no
    call .omega_tick
    mov  esi, .sh_tick_done
    call .com1_str
    call .omega_print_graph
    mov  eax, 1
    ret
.sct_no:
    mov  eax, 0
    ret

; dn — print Dn(r) lattice aggregate
.sh_cmd_dn:
    mov  edi, .sh_cmd_dn_str
    call .sh_strcmp_word
    jnz  .scd_no
    call .analog_summary
    mov  eax, 1
    ret
.scd_no:
    mov  eax, 0
    ret

; strand N — show strand N info (r_dim, Omega_i)
.sh_cmd_strand:
    mov  edi, .sh_cmd_strand_str
    call .sh_strcmp_word
    jnz  .scs_no
    call .sh_skip_token
    call .sh_parse_dec
    cmp  eax, 1
    jl   .scs_bad
    cmp  eax, 8
    jg   .scs_bad
    push eax
    mov  esi, .sh_strand_pfx
    call .com1_str
    pop  eax
    push eax
    cmp  eax, 8
    jne  .strand_not8
    mov  al, '1'
    call .com1_send
    mov  al, '.'
    call .com1_send
    mov  al, '0'
    call .com1_send
    jmp  .strand_rdim_done
.strand_not8:
    mov  al, '0'
    call .com1_send
    mov  al, '.'
    call .com1_send
    mov  eax, [esp]
    dec  eax
    add  eax, 3
    add  al, '0'
    call .com1_send
.strand_rdim_done:
    mov  esi, .sh_strand_nodes
    call .com1_str
    pop  eax
    push eax
    dec  eax
    imul eax, eax, 4
    inc  eax
    call .sh_print_dec
    mov  al, '-'
    call .com1_send
    pop  eax
    imul eax, eax, 4
    call .sh_print_dec
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  eax, 1
    ret
.scs_bad:
    mov  esi, .sh_strand_bad
    call .com1_str
    mov  eax, 1
    ret
.scs_no:
    mov  eax, 0
    ret

; glyph N S — set node N state to S
.sh_cmd_glyph:
    mov  edi, .sh_cmd_glyph_str
    call .sh_strcmp_word
    jnz  .scg_no
    call .sh_skip_token
    call .sh_parse_dec
    push eax
    call .sh_skip_token
    call .sh_parse_dec
    cmp  eax, 4
    jg   .scg_badstate
    mov  ecx, eax
    pop  eax
    cmp  eax, 63
    jg   .scg_badnode
    imul edi, eax, 64       ; OMEGA_SZ=64
    add  edi, 0x100000      ; OMEGA_BASE
    mov  dword [edi+12], ecx
    mov  dword [edi+48], 0x00050000 ; TRANSFORM_REWRITE
    mov  esi, .sh_glyph_ok
    call .com1_str
    call .sh_print_node_edi
    mov  eax, 1
    ret
.scg_badstate:
    pop  eax
    mov  esi, .sh_glyph_badstate
    call .com1_str
    mov  eax, 1
    ret
.scg_badnode:
    mov  esi, .sh_glyph_badnode
    call .com1_str
    mov  eax, 1
    ret
.scg_no:
    mov  eax, 0
    ret

; reset — re-run boot sequence
.sh_cmd_reset:
    mov  edi, .sh_cmd_reset_str
    call .sh_strcmp_word
    jnz  .scr_no
    ; Zero Omega region (explicit loop, no xor+rep stosd)
    mov  edi, 0x100000      ; OMEGA_BASE
    mov  ecx, 1024          ; 64*64/4 dwords
.reset_zero:
    mov  dword [edi], 0
    add  edi, 4
    dec  ecx
    jnz  .reset_zero
    ; Reset PCI node counter so nodes restart at 8
    mov  dword [.pci_next_node], 8
    mov  esi, .sh_reset_msg
    call .com1_str
    call .hdgl_boot_sequence
    mov  eax, 1
    ret
.scr_no:
    mov  eax, 0
    ret

; help — print command list
.sh_cmd_help:
    mov  edi, .sh_cmd_help_str
    call .sh_strcmp_word
    jnz  .sch_no
    mov  esi, .sh_help_text
    call .com1_str
    mov  eax, 1
    ret
.sch_no:
    mov  eax, 0
    ret

; Print node at EDI (one-line summary)
.sh_print_node_edi:
    push eax
    push esi
    mov  esi, .msg_omega
    call .com1_str
    mov  eax, [edi+0]
    call .sh_print_hex8
    mov  esi, .msg_type
    call .com1_str
    movzx eax, word [edi+8]
    call .sh_print_dec
    mov  esi, .msg_state
    call .com1_str
    movzx eax, word [edi+12]
    call .sh_print_dec
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    pop  esi
    pop  eax
    ret

; Print EAX as unsigned decimal
.sh_print_dec:
    push eax
    push ecx
    push edx
    push edi
    lea  edi, [.sh_dec_buf + 10]
    mov  byte [edi], 0
    mov  ecx, 10
.spd_loop:
    mov  edx, 0             ; explicit zero (no xor)
    div  ecx
    dec  edi
    add  dl, '0'
    mov  [edi], dl
    test eax, eax
    jnz  .spd_loop
    mov  esi, edi
    call .com1_str
    pop  edi
    pop  edx
    pop  ecx
    pop  eax
    ret

; Print EAX as 2-digit hex
.sh_print_hex8:
    push eax
    push ecx
    mov  ecx, 2
    rol  al, 4
.sph_loop:
    push eax
    and  al, 0x0F
    add  al, '0'
    cmp  al, '9'+1
    jl   .sph_ok
    add  al, 7
.sph_ok:
    call .com1_send
    pop  eax
    rol  al, 4
    loop .sph_loop
    pop  ecx
    pop  eax
    ret

; ── phi: φ-lattice depth Λ_φ(identity) per node ─────────────────────────
; Λ_φ(x) ≈ x * 6942 / 10000   (log2(φ) ≈ 0.6942)
; Pure integer arithmetic — no x87, no xor
.sh_cmd_phi:
    mov  edi, .sh_phi_str
    call .sh_strcmp_word
    jnz  .scp_no
    mov  esi, .sh_phi_hdr
    call .com1_str
    mov  edi, 0x100000      ; OMEGA_BASE
    mov  ecx, 16
.phi_loop:
    cmp  word [edi+8], 0
    je   .phi_next
    push ecx
    mov  eax, 16
    sub  eax, ecx
    push eax
    mov  esi, .sh_phi_pfx
    call .com1_str
    pop  eax
    call .sh_print_hex8
    mov  al, ']'
    call .com1_send
    mov  al, ' '
    call .com1_send
    push ecx
    mov  eax, [edi+0]
    imul eax, eax, 6942
    mov  edx, 0             ; explicit zero
    mov  ecx, 10000
    div  ecx
    push edx
    call .sh_print_dec
    mov  al, '.'
    call .com1_send
    pop  edx
    mov  eax, edx
    mov  edx, 0
    mov  ecx, 10
    div  ecx
    push eax
    cmp  eax, 100
    jge  .phi_no_lead
    mov  al, '0'
    call .com1_send
    cmp  dword [esp], 10
    jge  .phi_no_lead
    mov  al, '0'
    call .com1_send
.phi_no_lead:
    pop  eax
    call .sh_print_dec
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    pop  ecx
.phi_next:
    add  edi, 64            ; OMEGA_SZ=64
    dec  ecx
    jnz  .phi_loop
    mov  eax, 1
    ret
.scp_no:
    mov  eax, 0
    ret

; ── b4096 N: Base4096 encode of node N identity ─────────────────────────
.sh_cmd_b4096:
    mov  edi, .sh_b4096_str
    call .sh_strcmp_word
    jnz  .scb_no
    call .sh_skip_token
    call .sh_parse_dec
    cmp  eax, 63
    jg   .scb_badnode
    push eax
    mov  esi, .sh_b4096_pfx
    call .com1_str
    pop  eax
    imul edi, eax, 64       ; OMEGA_SZ=64
    add  edi, 0x100000      ; OMEGA_BASE
    mov  eax, [edi+0]
    mov  ecx, 4
.b4096_loop:
    mov  edx, eax
    and  edx, 0xFFF
    push eax
    mov  eax, edx
    cmp  eax, 10
    jl   .b_digit
    cmp  eax, 36
    jl   .b_upper
    cmp  eax, 62
    jl   .b_lower
    sub  eax, 62
    add  eax, 35
    jmp  .b_emit
.b_digit:
    add  al, '0'
    jmp  .b_emit
.b_upper:
    sub  eax, 10
    add  al, 'A'
    jmp  .b_emit
.b_lower:
    sub  eax, 36
    add  al, 'a'
.b_emit:
    call .com1_send
    pop  eax
    shr  eax, 12
    loop .b4096_loop
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  eax, 1
    ret
.scb_badnode:
    mov  esi, .sh_glyph_badnode
    call .com1_str
    mov  eax, 1
    ret
.scb_no:
    mov  eax, 0
    ret

; ── wave: strand wave types and binary aggregate ─────────────────────────
.sh_cmd_wave:
    mov  edi, .sh_wave_str
    call .sh_strcmp_word
    jnz  .scw_no
    mov  esi, .sh_wave_hdr
    call .com1_str
    mov  ebx, [0x10100C]
    mov  ecx, 8
    mov  edx, 0             ; strand index (explicit zero)
.wave_loop:
    push ecx
    push edx
    mov  al, 'A'
    add  al, dl
    call .com1_send
    mov  al, ':'
    call .com1_send
    mov  eax, ebx
    mov  ecx, edx
    imul ecx, ecx, 4
    shr  eax, cl
    and  eax, 0xF
    cmp  eax, 0
    je   .wave_minus
    cmp  eax, 0xF
    je   .wave_plus
    mov  al, '0'
    call .com1_send
    jmp  .wave_bits
.wave_minus:
    mov  al, '-'
    call .com1_send
    jmp  .wave_bits
.wave_plus:
    mov  al, '+'
    call .com1_send
.wave_bits:
    mov  al, ' '
    call .com1_send
    pop  edx
    pop  ecx
    inc  edx
    loop .wave_loop
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  esi, .sh_wave_agg
    call .com1_str
    mov  eax, [0x10100C]
    call .sh_print_hex32
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  eax, 1
    ret
.scw_no:
    mov  eax, 0
    ret

; ── xform N: named transform field of node N ─────────────────────────────
.sh_cmd_xform:
    mov  edi, .sh_xform_str
    call .sh_strcmp_word
    jnz  .scx_no
    call .sh_skip_token
    call .sh_parse_dec
    cmp  eax, 63
    jg   .scx_badnode
    imul edi, eax, 64       ; OMEGA_SZ=64
    add  edi, 0x100000      ; OMEGA_BASE
    mov  eax, [edi+48]
    cmp  eax, 0x00010000
    je   .xf_cpuid
    cmp  eax, 0x00020000
    je   .xf_e820
    cmp  eax, 0x00030000
    je   .xf_pci
    cmp  eax, 0x00040000
    je   .xf_compile
    cmp  eax, 0x00050000
    je   .xf_rewrite
    cmp  eax, 0
    je   .xf_identity
    mov  esi, .sh_xf_raw
    call .com1_str
    call .sh_print_hex32
    jmp  .xf_done
.xf_identity:
    mov  esi, .sh_xf_identity
    call .com1_str
    jmp  .xf_done
.xf_cpuid:
    mov  esi, .sh_xf_cpuid
    call .com1_str
    jmp  .xf_done
.xf_e820:
    mov  esi, .sh_xf_e820
    call .com1_str
    jmp  .xf_done
.xf_pci:
    mov  esi, .sh_xf_pci
    call .com1_str
    jmp  .xf_done
.xf_compile:
    mov  esi, .sh_xf_compile
    call .com1_str
    jmp  .xf_done
.xf_rewrite:
    mov  esi, .sh_xf_rewrite
    call .com1_str
.xf_done:
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  eax, 1
    ret
.scx_badnode:
    mov  esi, .sh_glyph_badnode
    call .com1_str
    mov  eax, 1
    ret
.scx_no:
    mov  eax, 0
    ret

; ── tree: ASCII tree of Omega graph ──────────────────────────────────────
.sh_cmd_tree:
    mov  edi, .sh_tree_str
    call .sh_strcmp_word
    jnz  .sct2_no
    mov  esi, .sh_tree_hdr
    call .com1_str
    ; Walk ROOT child chain printing ASCII tree
    mov  edi, [0x100000 + 32]  ; root.child
    mov  edx, 0             ; indent level (explicit zero)
.tree_walk:
    test edi, edi
    jz   .tree_done
    ; Print indent
    push edx
    push edi
.tree_indent:
    test edx, edx
    jz   .tree_node
    mov  al, ' '
    call .com1_send
    mov  al, ' '
    call .com1_send
    dec  edx
    jmp  .tree_indent
.tree_node:
    mov  al, '+'
    call .com1_send
    mov  al, '-'
    call .com1_send
    call .sh_print_node_edi
    pop  edi
    pop  edx
    ; Recurse into children (one level for now)
    mov  edi, [edi+32]      ; .child
    test edi, edi
    jz   .tree_sib
    push edx
    push edi
    inc  edx
    jmp  .tree_walk
.tree_sib:
    mov  edi, [edi+40]      ; .next sibling... (already popped, skip for now)
    jmp  .tree_done
.tree_done:
    mov  eax, 1
    ret
.sct2_no:
    mov  eax, 0
    ret

; ── aphase: Kuramoto phase state ─────────────────────────────────────────
.sh_cmd_aphase:
    mov  edi, .sh_aphase_str
    call .sh_strcmp_word
    jnz  .sca_no
    mov  esi, .sh_aphase_hdr
    call .com1_str
    mov  eax, [0x101000]
    cmp  eax, 0
    je   .aph_pluck
    cmp  eax, 1
    je   .aph_sustain
    cmp  eax, 2
    je   .aph_finetune
    ; LOCK (3)
    mov  esi, .sh_aph_lock
    call .com1_str
    mov  esi, .sh_aph_wu
    call .com1_str
    mov  esi, .sh_aph_r150
    call .com1_str
    jmp  .aph_done
.aph_pluck:
    mov  esi, .sh_aph_pluck
    call .com1_str
    mov  esi, .sh_aph_wu
    call .com1_str
    mov  esi, .sh_aph_r1000
    call .com1_str
    jmp  .aph_done
.aph_sustain:
    mov  esi, .sh_aph_sustain
    call .com1_str
    mov  esi, .sh_aph_wu
    call .com1_str
    mov  esi, .sh_aph_r375
    call .com1_str
    jmp  .aph_done
.aph_finetune:
    mov  esi, .sh_aph_finetune
    call .com1_str
    mov  esi, .sh_aph_wu
    call .com1_str
    mov  esi, .sh_aph_r200
    call .com1_str
.aph_done:
    mov  eax, 1
    ret
.sca_no:
    mov  eax, 0
    ret

; ── dna: hardware genome codons (from CPUID vendor) ─────────────────────
.sh_cmd_dna:
    mov  edi, .sh_dna_str
    call .sh_strcmp_word
    jnz  .scd2_no
    mov  esi, .sh_dna_hdr
    call .com1_str
    ; Read CPUID vendor string (EBX:EDX:ECX for leaf 0)
    mov  eax, 0
    cpuid
    ; Print 12 vendor chars: EBX then EDX then ECX
    push ecx
    push edx
    push ebx
    push edx
    push ecx
    mov  ecx, 3
.dna_vendor_loop:
    pop  eax
    mov  edx, 4
.dna_char_loop:
    push eax
    and  al, 0xFF
    call .com1_send
    pop  eax
    shr  eax, 8
    dec  edx
    jnz  .dna_char_loop
    loop .dna_vendor_loop
    pop  ebx
    pop  edx
    pop  ecx
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    ; Print r_dim progression from conscious Dn(r) (strands 1-8)
    mov  esi, .sh_dna_rdim
    call .com1_str
    ; CPU node state=EXECUTED → r_dim = strand 8 = 1.0 full helix
    cmp  dword [0x100040 + 12], 4  ; CPU state=EXECUTED?
    je   .dna_helix
    mov  esi, .sh_dna_linear
    call .com1_str
    jmp  .dna_done
.dna_helix:
    mov  esi, .sh_dna_helix
    call .com1_str
.dna_done:
    mov  eax, 1
    ret
.scd2_no:
    mov  eax, 0
    ret

; ── ls: disk layout ──────────────────────────────────────────────────────
.sh_cmd_ls:
    mov  edi, .sh_ls_str
    call .sh_strcmp_word
    jnz  .scl_no
    mov  esi, .sh_ls_out
    call .com1_str
    mov  eax, 1
    ret
.scl_no:
    mov  eax, 0
    ret

; ── cat S: hex dump sector S via ATA PIO ────────────────────────────────
; Reads 512 bytes from LBA S into 0x20000 and dumps as hex
.sh_cmd_cat:
    mov  edi, .sh_cat_str
    call .sh_strcmp_word
    jnz  .scc_no
    call .sh_skip_token
    call .sh_parse_dec
    push eax
    mov  esi, .sh_cat_hdr
    call .com1_str
    pop  eax
    push eax
    call .sh_print_dec
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    pop  eax
    mov  ecx, 1             ; one sector
    mov  edi, 0x20000
    call .disk_read
    ; Hex dump 512 bytes: 16 bytes per line
    mov  esi, 0x20000
    mov  ecx, 32            ; 32 lines
.cat_line:
    push ecx
    push esi
    mov  ecx, 16
.cat_byte:
    mov  al, [esi]
    push eax
    shr  al, 4
    add  al, '0'
    cmp  al, '9'+1
    jl   .cat_hi_ok
    add  al, 7
.cat_hi_ok:
    call .com1_send
    pop  eax
    and  al, 0xF
    add  al, '0'
    cmp  al, '9'+1
    jl   .cat_lo_ok
    add  al, 7
.cat_lo_ok:
    call .com1_send
    mov  al, ' '
    call .com1_send
    inc  esi
    dec  ecx
    jnz  .cat_byte
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    pop  esi
    add  esi, 16
    pop  ecx
    dec  ecx
    jnz  .cat_line
    mov  eax, 1
    ret
.scc_no:
    mov  eax, 0
    ret

; exec S — load sector S to 0x30000 and jump
.sh_cmd_exec:
    mov  edi, .sh_exec_str
    call .sh_strcmp_word
    jnz  .sce_no
    call .sh_skip_token
    call .sh_parse_dec
    push eax
    mov  esi, .sh_exec_load
    call .com1_str
    pop  eax
    push eax
    call .sh_print_dec
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    pop  eax
    mov  ecx, 16
    mov  edi, 0x30000
    call .disk_read
    mov  esi, .sh_exec_jmp
    call .com1_str
    call 0x30000
    mov  eax, 1
    ret
.sce_no:
    mov  eax, 0
    ret

; info — system info from Omega graph
.sh_cmd_info:
    mov  edi, .sh_info_str
    call .sh_strcmp_word
    jnz  .sci_no
    mov  esi, .sh_info_cpu
    call .com1_str
    mov  eax, [0x100000 + 64 + 52]  ; CPU node transform+4 = CPUID eax
    call .sh_print_hex32
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  esi, .sh_info_mem
    call .com1_str
    mov  eax, [0x100000 + 128 + 52] ; MEM node transform+4 = KB
    call .sh_print_dec
    mov  esi, .sh_info_kb
    call .com1_str
    mov  esi, .sh_info_pci
    call .com1_str
    mov  edi, [0x100000 + 192 + 32]  ; IO.child
    mov  ecx, 0             ; count (explicit zero)
.info_pci_count:
    test edi, edi
    jz   .info_pci_done
    cmp  edi, 0x100000      ; OMEGA_BASE
    jl   .info_pci_done
    inc  ecx
    mov  edi, [edi+40]
    jmp  .info_pci_count
.info_pci_done:
    mov  eax, ecx
    call .sh_print_dec
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  eax, 1
    ret
.sci_no:
    mov  eax, 0
    ret

; sectors — disk layout
.sh_cmd_sectors:
    mov  edi, .sh_sectors_str
    call .sh_strcmp_word
    jnz  .scs2_no
    mov  esi, .sh_sectors_out
    call .com1_str
    mov  eax, 1
    ret
.scs2_no:
    mov  eax, 0
    ret

; ── ATA PIO disk read ────────────────────────────────────────────────────
; IN: EAX=LBA, ECX=sector count, EDI=dest
; disk_read: ATA PIO LBA28, channel auto-detected
; IN: EAX=LBA, ECX=sector count (1), EDI=dest buffer
; Tries primary channel (0x1F0) first, then secondary (0x170).
; Gleaned from conscious: probe-then-fallback, no hardcoded assumption.
; .ata_base set by .ata_detect at kernel_init time.
.ata_base dd 0x1F0         ; default primary; overwritten by detect

.disk_read:
    push eax
    push ecx
    push edx
    push edi
    ; ATA LBA28: head/device register
    push eax
    movzx edx, word [.ata_base]
    add  edx, 6             ; head/device register (base+6)
    shr  eax, 24
    and  al, 0x0F
    or   al, 0xE0           ; LBA mode, drive 0
    out  dx, al
    pop  eax
    ; Sector count
    push eax
    movzx edx, word [.ata_base]
    add  edx, 2             ; sector count (base+2)
    mov  al, cl
    out  dx, al
    pop  eax
    ; LBA low/mid/high
    push eax
    movzx edx, word [.ata_base]
    add  edx, 3
    out  dx, al             ; LBA[7:0]
    shr  eax, 8
    inc  edx
    out  dx, al             ; LBA[15:8]
    shr  eax, 8
    inc  edx
    out  dx, al             ; LBA[23:16]
    pop  eax
    ; Command: READ SECTORS (0x20)
    movzx edx, word [.ata_base]
    add  edx, 7             ; command/status (base+7)
    mov  al, 0x20
    out  dx, al
.dr_wait:
    in   al, dx
    test al, 0x80           ; BSY
    jnz  .dr_wait
    test al, 0x08           ; DRQ
    jz   .dr_wait
    ; Read 256 words (512 bytes) from data port (base+0)
    mov  ecx, 256
    movzx edx, word [.ata_base]
    rep  insw
    pop  edi
    pop  edx
    pop  ecx
    pop  eax
    ret

; ATA channel detection: probe primary (0x1F0) then secondary (0x170)
; Write/read scratch to status register; non-0xFF = present.
; Called from kernel_init before any disk operation.
.ata_detect:
    push eax
    push edx
    ; Try primary 0x1F0
    mov  dx, 0x1F7          ; status register
    in   al, dx
    cmp  al, 0xFF           ; 0xFF = floating bus = no device
    je   .ata_try_secondary
    mov  word [.ata_base], 0x1F0
    jmp  .ata_detect_done
.ata_try_secondary:
    mov  dx, 0x177          ; secondary status register
    in   al, dx
    cmp  al, 0xFF
    je   .ata_detect_done   ; neither present — .ata_base stays 0x1F0 (graceful)
    mov  word [.ata_base], 0x170
.ata_detect_done:
    pop  edx
    pop  eax
    ret

; ═══════════════════════════════════════════════════════════
; HDGL NATIVE KERNEL — phi-lattice architecture
; Gleaned from conscious-128-bit-floor bootloaderZ V6.0
; No IDT. No PIC. No PIT. No INT 0x80. No privilege rings.
; The lattice IS the kernel. Phase lock IS permission.
; GOI/GUZ IS fault handling.
; ═══════════════════════════════════════════════════════════

.kernel_init:
    ; ── Phase 1: phi-seed lattice at 0x101020 ─────────────────
    ; 128 slots × 4 bytes = 512 bytes
    ; Seeded from conscious ll_analog + bootloaderZ V6.0:
    ;   slot[i] = fib[i%8] * prime[i%8] * PHI^(1+(i%4)) * 65536
    ; Gleaned formula: slot[i] = (slot[i-1]*3 + phi_seed[i%16]) mod 2^32
    ; XOR-free. Additive. Phi-harmonic. The lattice IS the key.
    push eax
    push ebx
    push ecx
    push edx
    push edi
    ; Zero phi-lattice region (explicit loop, not xor+rep stosd)
    mov  edi, 0x101020
    mov  ecx, 512
.phi_zero:
    mov  dword [edi], 0
    add  edi, 4
    dec  ecx
    jnz  .phi_zero
    ; Seed 128 lattice slots with phi-harmonic values
    ; slot[i] = (slot[i-1]*3 + seed[i%16]) mod 2^32  (XOR-free)
    mov  edi, 0x101020
    mov  esi, .phi_seed_table
    mov  ecx, 128
.phi_seed_loop:
    mov  eax, [esi]
    cmp  edi, 0x101020
    je   .phi_first_slot
    mov  edx, [edi-4]
    imul edx, edx, 3
    add  eax, edx
.phi_first_slot:
    stosd
    add  esi, 4
    cmp  esi, .phi_seed_table_end
    jl   .phi_no_wrap
    mov  esi, .phi_seed_table
.phi_no_wrap:
    dec  ecx
    jnz  .phi_seed_loop
    ; ── Phase 2: GOI/GUZ saturation limits ─────────────────────
    ; GOI: Gradual Overflow Infinity (from bootloaderZ V6.0: 0xFFFF0000)
    ; GUZ: Gradual Underflow Zero (from bootloaderZ V6.0: 0x00000100)
    ; Replace hardware fault vectors. The lattice self-limits.
    mov  dword [0x101800], 0xFFFF0000  ; GOI high-water mark
    mov  dword [0x101804], 0x00000100  ; GUZ low-water mark
    ; ── Phase 3: init COM1 ring buffer (no PIC, no IRQ) ────────
    mov  dword [0x102100], 0
    mov  dword [0x102104], 0x102108
    mov  dword [0x102110], 0x102108
    ; ── Phase 4: process table (phase = consensus state) ────────
    ; Process 0 starts at APA_FLAG_CONSENSUS (LOCK)
    ; Consensus = permission. No privilege rings.
    mov  dword [0x103000 + 12], 3   ; state = READY
    ; ── Phase 5: mark phi-kernel ready ─────────────────────────
    ; tick counter = 0
    mov  dword [0x101010], 0
    ; APA_FLAG_CONSENSUS = (1<<4) = 0x10 → LOCK
    ; From conscious bootloaderZ: APA_FLAG_CONSENSUS replaces ring 0
    mov  dword [0x101014], 0x10
    ; ── Phase 6: ATA channel detection ────────────────────────
    ; Probe primary (0x1F0) then secondary (0x170) ATA channel.
    ; Sets .ata_base for all subsequent disk_read calls.
    call .ata_detect
    ; No sti. No PIC unmask. No IDT. The phi-tick IS the event loop.
    pop  edi
    pop  edx
    pop  ecx
    pop  ebx
    pop  eax
    mov  esi, .msg_kernel_ok
    call .com1_str
    ret

; ═══════════════════════════════════════════════════════════
; NATIVE PHI PRIMITIVES
; Gleaned from conscious-128-bit-floor ll_analog.c
; ═══════════════════════════════════════════════════════════

; phi_tick: prismatic_recursion step (replaces timer ISR / IRQ0)
; Wu-wei: the shell loop IS the tick. phi_tick IS Ωₙ₊₁ = T(Ωₙ).
; Formula: slot[i] = slot[i]*3 + tick_count   (additive, XOR-free)
; GOI: saturate at 0xFFFF0000 (Gradual Overflow Infinity)
.phi_tick:
    push eax
    push ebx
    push ecx
    push edi
    inc  dword [0x101010]           ; advance tick counter
    mov  edi, 0x101020              ; phi lattice base
    mov  ecx, 128
    mov  eax, [0x101800]            ; GOI limit
.pt_loop:
    mov  ebx, [edi]
    cmp  ebx, eax                   ; GOI check
    jge  .pt_goi
    ; Prismatic accumulation: additive, phi-harmonic, XOR-free
    imul ebx, ebx, 3
    add  ebx, [0x101010]            ; add tick count as seed
    add  [edi], ebx
    jmp  .pt_next
.pt_goi:
    ; GOI saturation: no crash, no exception (replaces hardware #OF/#GP)
    mov  dword [edi], 0xFFFF0000
.pt_next:
    add  edi, 4
    dec  ecx
    jnz  .pt_loop
    pop  edi
    pop  ecx
    pop  ebx
    pop  eax
    ret

; phi_lk_read: lattice kernel read (replaces INT 0x80 syscall)
; IN:  ESI = key string, ECX = output size (1..32)
; OUT: EBX = phi_fold result (32-bit phi hash)
; phi_fold: additive Z/256Z — no XOR, no SHA
;   acc = (acc*3 + key_byte + lattice[i]) mod 2^32
; The lattice IS the secret key. No external crypto.
.phi_lk_read:
    push eax
    push ecx
    push edi
    mov  eax, [0x101020]            ; IV from lattice[0]
    mov  edi, 0                     ; lattice index (explicit zero)
.plk_loop:
    movzx ebx, byte [esi]
    test  bl, bl
    jz    .plk_done
    mov   ecx, [0x101020 + edi*4]
    ; acc = (acc*3 + key_byte + lattice[edi]) mod 2^32
    imul  eax, eax, 3
    add   eax, ebx
    add   eax, ecx
    inc   esi
    inc   edi
    cmp   edi, 128
    jl    .plk_loop
    mov   edi, 0
    jmp   .plk_loop
.plk_done:
    ; Finalize: 4 rounds ROTR32-by-3 + additive mix (no XOR)
    mov  ecx, 4
.plk_final:
    ror  eax, 3
    add  eax, [0x101020]            ; additive mix with lattice[0]
    dec  ecx
    jnz  .plk_final
    mov  ebx, eax
    pop  edi
    pop  ecx
    pop  eax
    ret

; phi_advance: lattice epoch advance (replaces lk_advance / PIT tick)
; Invalidates GOI/GUZ caches. Advances all slots one prismatic step.
.phi_advance:
    call .phi_tick
    ; Reset GOI-saturated slots toward GUZ floor
    mov  edi, 0x101020
    mov  ecx, 128
    mov  eax, [0x101804]            ; GUZ limit
.pa_loop:
    cmp  dword [edi], 0xFFFF0000    ; was GOI?
    jne  .pa_next
    mov  dword [edi], eax           ; reset to GUZ floor
.pa_next:
    add  edi, 4
    dec  ecx
    jnz  .pa_loop
    ret

; phi_consensus: detect phase lock (replaces ring 0 privilege check)
; APA_FLAG_CONSENSUS (1<<4) = phase lock = permission granted
; Algo: mean = sum/128; consensus if max_dev < mean/2
.phi_consensus:
    push eax
    push ebx
    push ecx
    push edi
    mov  eax, 0             ; running sum (explicit zero)
    mov  edi, 0x101020
    mov  ecx, 128
.pc_sum:
    add  eax, [edi]
    add  edi, 4
    dec  ecx
    jnz  .pc_sum
    shr  eax, 7             ; mean
    mov  edi, 0x101020
    mov  ecx, 128
    mov  ebx, 0             ; max deviation (explicit zero)
.pc_var:
    mov  edx, [edi]
    sub  edx, eax
    jns  .pc_pos
    neg  edx
.pc_pos:
    cmp  edx, ebx
    jle  .pc_next
    mov  ebx, edx
.pc_next:
    add  edi, 4
    dec  ecx
    jnz  .pc_var
    shr  eax, 1             ; mean/2
    cmp  ebx, eax           ; ZF=1 if dev < mean/2 → consensus
    pop  edi
    pop  ecx
    pop  ebx
    pop  eax
    ret

; phi_poll: native event loop (wu-wei — shell iteration IS the tick)
.sh_poll_input:
    call .phi_tick
    ret

; ps: phi-lattice consensus state
.sh_cmd_ps:
    mov  edi, .sh_ps_str
    call .sh_strcmp_word
    jnz  .scp2_no
    mov  esi, .sh_ps_hdr
    call .com1_str
    mov  esi, .sh_ps_tick
    call .com1_str
    mov  eax, [0x101010]
    call .sh_print_dec
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  esi, .sh_ps_cons
    call .com1_str
    mov  eax, [0x101014]
    test eax, 0x10
    jnz  .ps_locked
    mov  esi, .sh_ps_pluck
    call .com1_str
    jmp  .ps_done
.ps_locked:
    mov  esi, .sh_ps_lock
    call .com1_str
.ps_done:
    mov  esi, .sh_ps_goi
    call .com1_str
    mov  eax, [0x101800]
    call .sh_print_hex32
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  esi, .sh_ps_guz
    call .com1_str
    mov  eax, [0x101804]
    call .sh_print_hex32
    mov  al, 13
    call .com1_send
    mov  al, 10
    call .com1_send
    mov  eax, 1
    ret
.scp2_no:
    mov  eax, 0
    ret

; uptime: phi-tick count
.sh_cmd_uptime:
    mov  edi, .sh_uptime_str
    call .sh_strcmp_word
    jnz  .scu_no
    mov  esi, .sh_uptime_pfx
    call .com1_str
    mov  eax, [0x101010]
    call .sh_print_dec
    mov  esi, .sh_uptime_sfx
    call .com1_str
    mov  eax, 1
    ret
.scu_no:
    mov  eax, 0
    ret

; sh_print_hex32: print EAX as 8 hex digits
.sh_print_hex32:
    push eax
    push ecx
    mov  ecx, 8
    rol  eax, 4
.sph32_loop:
    push eax
    and  al, 0x0F
    add  al, '0'
    cmp  al, '9'+1
    jl   .sph32_ok
    add  al, 7
.sph32_ok:
    call .com1_send
    pop  eax
    rol  eax, 4
    loop .sph32_loop
    pop  ecx
    pop  eax
    ret

; ═══════════════════════════════════════════════════════════
; DATA — phi-harmonic seed table gleaned from conscious
; ═══════════════════════════════════════════════════════════
.msg_kernel_ok  db '[Kernel] phi-lattice ready. Consensus=LOCK phi-tick=active',13,10,0
.msg_fault      db '[GOI] lattice overflow at EIP=',0

; phi_seed_table: 16 × 32-bit seeds
; Gleaned from conscious-128-bit-floor ll_analog.c + bootloaderZ.c
; Formula: seed[i] = fib[i%8] * prime[i%8] * PHI^(1+(i%4)) * 65536
; where FIB={1,1,2,3,5,8,13,21}, PRIME={2,3,5,7,11,13,17,19}
; XOR-free: additive phi-harmonics. The lattice IS the entropy.
.phi_seed_table:
    dd 0x00033C6F  ; i=0:  fib=1 * prime=2  * PHI^1=1.618  → 212079
    dd 0x0007DAA6  ; i=1:  fib=1 * prime=3  * PHI^2=2.618  → 514726
    dd 0x002A5C56  ; i=2:  fib=2 * prime=5  * PHI^3=4.236  → 2776150
    dd 0x008FEFA7  ; i=3:  fib=3 * prime=7  * PHI^4=6.854  → 9432999
    dd 0x0058FDEB  ; i=4:  fib=5 * prime=11 * PHI^1=1.618  → 5832171
    dd 0x01104689  ; i=5:  fib=8 * prime=13 * PHI^2=2.618  → 17843849
    dd 0x03A82BC8  ; i=6:  fib=13* prime=17 * PHI^3=4.236  → 61352904
    dd 0x0AAEC964  ; i=7:  fib=21* prime=19 * PHI^4=6.854  → 179226980
    dd 0x00033C6F  ; i=8:  (wraps to i=0)
    dd 0x0007DAA6  ; i=9:  (wraps to i=1)
    dd 0x002A5C56  ; i=10: (wraps to i=2)
    dd 0x008FEFA7  ; i=11: (wraps to i=3)
    dd 0x0058FDEB  ; i=12: (wraps to i=4)
    dd 0x01104689  ; i=13: (wraps to i=5)
    dd 0x03A82BC8  ; i=14: (wraps to i=6)
    dd 0x0AAEC964  ; i=15: (wraps to i=7)
.phi_seed_table_end:

; ── Shell strings ───────────────────────────────────────────
.sh_ps_str     db 'ps',0
.sh_uptime_str db 'uptime',0
.sh_ps_hdr     db 'phi-lattice consensus state:',13,10,0
.sh_ps_tick    db '  phi-tick:  ',0
.sh_ps_cons    db '  consensus: ',0
.sh_ps_lock    db 'LOCK (APA_FLAG_CONSENSUS set)',13,10,0
.sh_ps_pluck   db 'PLUCK (converging)',13,10,0
.sh_ps_goi     db '  GOI limit: 0x',0
.sh_ps_guz     db '  GUZ limit: 0x',0
.sh_uptime_pfx db 'ticks: ',0
.sh_uptime_sfx db ' (phi-ticks, wu-wei)',13,10,0
.msg_boot    db '[Omega] BOOT: graph init -> OBSERVE',13,10,0
.msg_ana_dn       db '[Analog] Dn(r) lattice: phi-seeded 8-strand 32-slot',13,10,0
.msg_ana_strand_a db '  Strand A r=0.3 INIT  D1-D4 grounded (Dn<sqrt_phi)',13,10,0
.msg_ana_strand_h db '  Strand H r=1.0 HELIX D29-D32 excited (Dn>sqrt_phi)',13,10,0
.msg_ana_lock     db '  Kuramoto: PLUCK->SUSTAIN->FINETUNE->LOCK wu-wei',13,10,0
.msg_graph_hdr db '[Omega] Graph state:',13,10,0
.msg_omega   db '  Omega[',0
.msg_type    db '] type=',0
.msg_state   db ' state=',0
.msg_realize db '[Omega] REALIZE: T_COMPILE_SELF -> fixed point',13,10,0
.msg_runtime db '[Omega] RUNTIME: Omega_n+1=T(Omega_n) complete',13,10,0
.sh_banner      db 13,10,'HDGL> phi-lattice live. type help<enter>',13,10,0
.sh_prompt      db 'Omega> ',0
.sh_tick_done   db 'tick applied.',13,10,0
.sh_reset_msg   db 'resetting graph...',13,10,0
.sh_strand_pfx  db 'strand r=',0
.sh_strand_nodes db ' slots ',0
.sh_strand_bad  db 'strand 1..8',13,10,0
.sh_glyph_ok    db 'mutated: ',0
.sh_glyph_badstate db 'state 0..4 only',13,10,0
.sh_glyph_badnode  db 'node 0..63 only',13,10,0
.sh_help_text   db 'omega [N]  - print graph or node N',13,10,\
                   'tick       - one rewrite pass',13,10,\
                   'dn         - Dn(r) lattice',13,10,\
                   'strand N   - strand N info (1-8)',13,10,\
                   'glyph N S  - mutate node N to state S',13,10,\
                   'reset      - re-run boot sequence',13,10,\
                   'phi        - phi-lattice depth per node',13,10,\
                   'b4096 N    - Base4096 encode node N id',13,10,\
                   'wave       - strand wave types + aggregate',13,10,\
                   'xform N    - transform field of node N',13,10,\
                   'tree       - Omega graph as ASCII tree',13,10,\
                   'aphase     - Kuramoto phase state',13,10,\
                   'dna        - hardware genome codons',13,10,\
                   'ls         - list disk regions',13,10,\
                   'cat S      - hex dump sector S',13,10,\
                   'exec S     - load sector S and run it',13,10,\
                   'info       - cpu/mem/pci from Omega graph',13,10,\
                   'sectors    - disk layout + free space',13,10,\
                   'ps         - phi-lattice consensus state',13,10,\
                   'uptime     - phi-tick count (wu-wei)',13,10,\
                   'help       - this list',13,10,0
.sh_cmd_omega_str  db 'omega',0
.sh_cmd_tick_str   db 'tick',0
.sh_cmd_dn_str     db 'dn',0
.sh_cmd_strand_str db 'strand',0
.sh_cmd_glyph_str  db 'glyph',0
.sh_cmd_reset_str  db 'reset',0
.sh_cmd_help_str   db 'help',0
.sh_phi_str     db 'phi',0
.sh_b4096_str   db 'b4096',0
.sh_wave_str    db 'wave',0
.sh_xform_str   db 'xform',0
.sh_tree_str    db 'tree',0
.sh_aphase_str  db 'aphase',0
.sh_dna_str     db 'dna',0
.sh_phi_hdr     db 'phi-lattice depth Lp per node:',13,10,0
.sh_phi_pfx     db '  node[',0
.sh_b4096_pfx   db 'b4096: ',0
.sh_wave_hdr    db 'wave (+/0/-) per strand:',13,10,0
.sh_wave_agg    db 'agg: ',0
.sh_xf_raw      db 'TRANSFORM: ',0
.sh_xf_identity db 'T_IDENTITY',13,10,0
.sh_xf_cpuid    db 'T_CPUID',13,10,0
.sh_xf_e820     db 'T_E820',13,10,0
.sh_xf_pci      db 'T_PCI_WALK',13,10,0
.sh_xf_compile  db 'T_COMPILE_SELF',13,10,0
.sh_xf_rewrite  db 'T_REWRITE',13,10,0
.sh_tree_hdr    db 'Omega tree:',13,10,0
.sh_aphase_hdr  db 'Kuramoto aphase: ',0
.sh_aph_pluck   db 'PLUCK',13,10,0
.sh_aph_sustain db 'SUSTAIN',13,10,0
.sh_aph_finetune db 'FINETUNE',13,10,0
.sh_aph_lock    db 'LOCK',13,10,0
.sh_aph_wu      db 'K/g wu-wei: ',0
.sh_aph_r1000   db '1000:1 (Pluck)',13,10,0
.sh_aph_r375    db '375:1 (Sustain)',13,10,0
.sh_aph_r200    db '200:1 (FineTune)',13,10,0
.sh_aph_r150    db '150:1 (Lock)',13,10,0
.sh_dna_hdr     db 'hardware genome (CPUID vendor):',13,10,0
.sh_dna_rdim    db 'r_dim: ',0
.sh_dna_helix   db '1.0 full double-helix (EXECUTED)',13,10,0
.sh_dna_linear  db '0.3 linear strand',13,10,0
.sh_unknown        db '?',13,10,0
.sh_ls_str     db 'ls',0
.sh_cat_str    db 'cat',0
.sh_exec_str   db 'exec',0
.sh_info_str   db 'info',0
.sh_sectors_str db 'sectors',0
.sh_ls_out     db 'sector  0      MBR (boot stub)',13,10,\
                  'sectors 1-16   runtime (8KB)',13,10,\
                  'sector  17     padding',13,10,\
                  'sectors 18-91  hdgl_firmware.hdgl (source)',13,10,\
                  'sectors 92+    free',13,10,0
.sh_cat_hdr    db 'sector ',0
.sh_exec_load  db 'loading sector ',0
.sh_exec_jmp   db 'jumping...',13,10,0
.sh_info_cpu   db 'cpu:  ',0
.sh_info_mem   db 'mem:  ',0
.sh_info_kb    db ' KB',13,10,0
.sh_info_pci   db 'pci:  ',0
.sh_sectors_out db 'total: 92 provisioned',13,10,\
                  'free:  92+ (append past end)',13,10,\
                  'use exec S to run any sector',13,10,0
.sh_buf        times 64 db 0
.sh_errbuf     times 16 db 0
.sh_dec_buf    times 12 db 0

[BITS 16]
align 8
.gdt_start:
    dq 0
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00
.gdt_end:

.gdt_ptr:
    dw .gdt_end - .gdt_start - 1
    dd .gdt_start

times 8192 - ($ - $$) db 0
