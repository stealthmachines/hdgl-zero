#!/bin/bash
# Interactive QEMU session with HDGL universal BIOS
IMG=${1:-hdgl_universal_bios.img}
MACHINE=${2:-pc}
MEM=${3:-64M}

echo "HDGL Universal BIOS — QEMU ($MACHINE, $MEM)"
echo "Serial console: type 'help' for commands"
echo ""

qemu-system-x86_64 \
    -machine $MACHINE \
    -m $MEM \
    -drive file=$IMG,format=raw,if=ide \
    -boot order=c \
    -no-reboot \
    -display none \
    -serial stdio
