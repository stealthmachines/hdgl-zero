# HDGL Universal BIOS — Build & Test Results

## Image Layout
```
sector  0      hdgl_mbr.bin            (512B)  MBR stage1
sector  1      hdgl_stage2.bin         (512B)  A20+E820+COM+load
sectors 2-17   firmware_runtime_full.bin (8KB) phi-lattice kernel + shell
sectors 18+    hdgl_firmware.hdgl             glyph source
```

## Boot Sequence Output (every configuration)
```
[Omega] BOOT: graph init -> OBSERVE
[Omega] REALIZE: T_COMPILE_SELF -> fixed point
[Omega] RUNTIME: Omega_n+1=T(Omega_n) complete
[Omega] Graph state:
  Omega[1 ] type=1  state=4     CPU      EXECUTED   T_CPUID
  Omega[2 ] type=2  state=3     MEM      READY      T_E820
  Omega[3 ] type=3  state=2     IO       CONFIGURED T_PCI_WALK
  Omega[4 ] type=4  state=4     COMPILER EXECUTED   T_REWRITE
  Omega[8..B] type=8 state=2   PCI×4   DISCOVERED
[Analog] Dn(r) lattice: phi-seeded 8-strand 32-slot
  Strand A r=0.3 INIT  D1-D4 grounded (Dn<sqrt_phi)
  Strand H r=1.0 HELIX D29-D32 excited (Dn>sqrt_phi)
  Kuramoto: PLUCK->SUSTAIN->FINETUNE->LOCK wu-wei
[Kernel] phi-lattice ready. Consensus=LOCK phi-tick=active

HDGL> phi-lattice live. type help<enter>
Omega>
```

## Shell Commands
```
help      list all commands
omega [N] print Omega graph or single node
tick      one rewrite pass
dn        Dn(r) lattice (agg: 0x80C0C0E8)
aphase    Kuramoto phase: LOCK K/g=150:1
ps        phi-lattice consensus state
uptime    phi-tick count
wave      strand wave types + aggregate
phi       phi-lattice depth per node
b4096 N   Base4096 encode of node N identity
xform N   transform field of node N
tree      Omega graph as ASCII tree
dna       hardware genome (CPUID vendor)
info      cpu/mem/pci from Omega graph
ls        disk region layout
cat S     hex dump sector S (ATA PIO)
exec S    load and jump to sector S
sectors   disk layout + free space
reset     re-run boot sequence
glyph N S mutate node N to state S
strand N  strand N info (r_dim, slots)
```

## Hardware Matrix — 15/15 PASS

| Configuration | Checks | CPU CPUID | Mem | PCI |
|---|---|---|---|---|
| i440FX + IDE (legacy default) | 8/8 ✓ | 0x00060FB1 | 63MB | 4 |
| i440FX + floppy | 8/8 ✓ | 0x00060FB1 | 63MB | 4 |
| Q35 + floppy (modern chipset) | 8/8 ✓ | 0x00060FB1 | 63MB | 4 |
| CPU: Nehalem (2008) | 8/8 ✓ | 0x000106A3 | 63MB | 4 |
| CPU: Westmere (2010) | 8/8 ✓ | 0x000206C1 | 63MB | 4 |
| CPU: SandyBridge (2011) | 8/8 ✓ | 0x000206A1 | 63MB | 4 |
| CPU: IvyBridge (2012) | 8/8 ✓ | 0x000306A9 | 63MB | 4 |
| CPU: Haswell (2013) | 8/8 ✓ | 0x000306C4 | 63MB | 4 |
| CPU: Broadwell (2014) | 8/8 ✓ | 0x000306D2 | 63MB | 4 |
| CPU: Skylake (2015) | 8/8 ✓ | 0x000506E3 | 63MB | 4 |
| 4MB RAM (minimum) | 8/8 ✓ | 0x00060FB1 | 3MB | 4 |
| 16MB RAM | 8/8 ✓ | 0x00060FB1 | 15MB | 4 |
| 64MB RAM | 8/8 ✓ | 0x00060FB1 | 63MB | 4 |
| 256MB RAM | 8/8 ✓ | 0x00060FB1 | 255MB | 4 |
| TCG software emulation | 8/8 ✓ | 0x00060FB1 | 63MB | 4 |

## Bugs Found During Simulation
1. **ECX clobber in phi_tick** — outer tick loop used ECX as counter; phi_tick
   consumed ECX internally → infinite loop. Fixed: push/pop ECX in phi_tick.
2. **STRAND_OMEGA table off by ~3.4×** — was `1/(PHI^7)^i` not `1/PHI^(7i)`.
   Fixed: Dn aggregate now 0x80C0C0E8 (verified).
3. **Stub 63 bytes over MBR limit** — fixed by MBR+stage2 two-stage split.

## 64-bit verdict
32-bit PM is correct. HDGL's address space tops out at 0x103000.
64-bit long mode requires mandatory paging (PML4+PDPT+PD+PT = 16KB,
5-8 extra boot steps) for zero benefit at our address range.
