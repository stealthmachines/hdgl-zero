; ============================================================
; HDGL RUNTIME SIMULATION — for QEMU -serial stdio testing
; Org: 0x8000 (loaded by stage2)
; Tests:
;   [PM]     32-bit protected mode entry
;   [COM]    Serial output via probed .com_base (from 0x7FEC)
;   [CPUID]  CPU identity → Omega node 1
;   [E820]   Memory map from 0x4F8/0x500
;   [PHI]    phi-lattice init + 10 ticks
;   [OMEGA]  Graph: ROOT→CPU→MEM→IO→COMPILER
;   [LOCK]   Simplified Kuramoto consensus check (integer proxy)
;   [HALT]   Graceful exit via QEMU fw_cfg or HLT
; phi-neutral throughout: mov not xor.
; ============================================================
[BITS 16]
[ORG 0x8000]

runtime_entry:
    cli
    mov  ax, 0
    mov  ds, ax
    mov  es, ax
    mov  ss, ax
    mov  sp, 0x7BF0
    ; Read COM base from stub probe (0x7FEC)
    mov  ax, [0x7FEC]
    mov  [.com_base_16], ax
    ; Load GDT and enter PM
    lgdt [.gdt_ptr_16]
    mov  eax, cr0
    or   eax, 1
    mov  cr0, eax
    jmp  0x08:.pm32

.com_base_16 dw 0x3F8

[BITS 32]
.pm32:
    mov  ax, 0x10
    mov  ds, ax
    mov  es, ax
    mov  fs, ax
    mov  gs, ax
    mov  ss, ax
    mov  esp, 0x9F000

    ; Transfer COM base to 32-bit accessible location
    movzx eax, word [0x7FEC]
    test  eax, eax
    jnz   .com_base_ok
    mov   eax, 0x3F8        ; fallback to COM1 (QEMU always has it)
.com_base_ok:
    mov   [.com_base], eax

    ; ── [PM] Banner ─────────────────────────────────────────
    mov  esi, .banner
    call .puts

    ; ── [COM] Serial test ────────────────────────────────────
    mov  esi, .msg_com
    call .puts

    ; ── [CPUID] ──────────────────────────────────────────────
    mov  eax, 0
    cpuid
    ; Vendor in EBX:EDX:ECX → print
    mov  esi, .msg_cpuid
    call .puts
    push ecx
    push edx
    ; Print EBX (first 4 chars of vendor)
    mov  eax, ebx
    call .print_vendor_reg
    pop  eax                ; EDX (middle 4)
    call .print_vendor_reg
    pop  eax                ; ECX (last 4)
    call .print_vendor_reg
    mov  al, 13
    call .putc
    mov  al, 10
    call .putc
    ; CPUID leaf 1: family/model
    mov  eax, 1
    cpuid
    mov  esi, .msg_fam
    call .puts
    call .print_hex32
    mov  al, 13
    call .putc
    mov  al, 10
    call .putc

    ; ── [E820] ───────────────────────────────────────────────
    mov  esi, .msg_e820
    call .puts
    movzx eax, word [0x4F8]
    call .print_dec
    mov  esi, .msg_e820b
    call .puts

    ; ── [PHI] phi-lattice init + 10 ticks ───────────────────
    call .phi_init
    mov  esi, .msg_phi_init
    call .puts
    ; Run 10 ticks
    mov  ecx, 10
.phi_tick_loop:
    call .phi_tick
    dec  ecx
    jnz  .phi_tick_loop
    mov  esi, .msg_phi_tick
    call .puts
    ; Print tick count
    mov  eax, [.phi_tick_count]
    call .print_dec
    mov  al, 13
    call .putc
    mov  al, 10
    call .putc
    ; Print GOI/GUZ events
    mov  esi, .msg_goi
    call .puts
    mov  eax, [.phi_goi_events]
    call .print_dec
    mov  esi, .msg_guz
    call .puts
    mov  eax, [.phi_guz_events]
    call .print_dec
    mov  al, 13
    call .putc
    mov  al, 10
    call .putc

    ; ── [OMEGA] Build graph ──────────────────────────────────
    call .omega_init
    mov  esi, .msg_omega
    call .puts
    ; Print node count
    mov  eax, [.omega_node_count]
    call .print_dec
    mov  esi, .msg_nodes
    call .puts

    ; ── [LOCK] Integer consensus proxy ──────────────────────
    ; mean = sum(slot[0..15]) / 16 (fast 16-slot sample)
    ; consensus if max_dev < mean/2
    call .check_consensus
    mov  esi, .msg_cons
    call .puts
    cmp  eax, 1
    je   .cons_yes
    mov  esi, .msg_conv
    call .puts
    jmp  .cons_done
.cons_yes:
    mov  esi, .msg_lock
    call .puts
.cons_done:

    ; ── [HALT] ───────────────────────────────────────────────
    mov  esi, .msg_halt
    call .puts

    ; QEMU: write 0x01 to port 0x501 to trigger shutdown
    ; (ISA debug exit: works with -device isa-debug-exit,iobase=0x501,iosize=1)
    ; Return code: (val<<1)|1 → 0x01<<1|1 = 0x03 = success exit code 1
    mov  al, 0x01
    out  0x501, al

    ; Fallback: ACPI shutdown via port 0x604 (QEMU default)
    mov  ax, 0x2000
    mov  dx, 0x604
    out  dx, ax

    ; Hard fallback: HLT loop
.halt:
    hlt
    jmp  .halt

; ── phi-lattice ──────────────────────────────────────────────────
; 128 slots at 0x101020 (above 1MB, after A20)
; Seeds from conscious: fib×prime×PHI^n×65536
.phi_seeds:
    dd 0x00033C6F, 0x0007DAA6, 0x002A5C56, 0x008FEFA7
    dd 0x0058FDEB, 0x01104689, 0x03A82BC8, 0x0AAEC964
    dd 0x00033C6F, 0x0007DAA6, 0x002A5C56, 0x008FEFA7
    dd 0x0058FDEB, 0x01104689, 0x03A82BC8, 0x0AAEC964
.phi_tick_count  dd 0
.phi_goi_events  dd 0
.phi_guz_events  dd 0
.omega_node_count dd 0
.com_base        dd 0x3F8

.phi_init:
    push eax
    push ebx
    push ecx
    push edi
    push esi
    ; Zero 128 slots at 0x101020 (512 bytes)
    mov  edi, 0x101020
    mov  ecx, 128
.pi_zero:
    mov  dword [edi], 0
    add  edi, 4
    dec  ecx
    jnz  .pi_zero
    ; Seed: slot[i] = (slot[i-1]*3 + seed[i%16]) mod 2^32
    mov  edi, 0x101020
    mov  esi, .phi_seeds
    mov  ecx, 128
.pi_seed:
    mov  eax, [esi]
    cmp  edi, 0x101020
    je   .pi_first
    mov  ebx, [edi-4]
    imul ebx, ebx, 3
    add  eax, ebx
.pi_first:
    mov  [edi], eax
    add  edi, 4
    add  esi, 4
    cmp  esi, .phi_seeds + 64
    jl   .pi_nowrap
    mov  esi, .phi_seeds
.pi_nowrap:
    dec  ecx
    jnz  .pi_seed
    pop  esi
    pop  edi
    pop  ecx
    pop  ebx
    pop  eax
    ret

.phi_tick:
    push eax
    push ebx
    push ecx
    push edi
    inc  dword [.phi_tick_count]
    mov  edi, 0x101020
    mov  ecx, 128
    mov  eax, 0xFFFF0000     ; GOI (fits in imm32)
.pt_loop:
    mov  ebx, [edi]
    cmp  ebx, eax
    jae  .pt_goi
    imul ebx, ebx, 3
    add  ebx, [.phi_tick_count]
    mov  [edi], ebx
    cmp  dword [edi], 0x00000100
    jae  .pt_next
    mov  dword [edi], 0x00000100
    inc  dword [.phi_guz_events]
    jmp  .pt_next
.pt_goi:
    mov  dword [edi], 0xFFFF0000
    inc  dword [.phi_goi_events]
.pt_next:
    add  edi, 4
    dec  ecx
    jnz  .pt_loop
    pop  edi
    pop  ecx
    pop  ebx
    pop  eax
    ret

; consensus: sample first 16 slots, ZF-equivalent in EAX (1=locked)
.check_consensus:
    push ebx
    push ecx
    push edx
    push edi
    mov  edi, 0x101020
    mov  eax, 0
    mov  ecx, 16
.cs_sum:
    add  eax, [edi]
    add  edi, 4
    dec  ecx
    jnz  .cs_sum
    shr  eax, 4             ; mean
    mov  edx, 0             ; max_dev (explicit zero)
    mov  edi, 0x101020
    mov  ecx, 16
.cs_var:
    mov  ebx, [edi]
    sub  ebx, eax
    jns  .cs_pos
    neg  ebx
.cs_pos:
    cmp  ebx, edx
    jle  .cs_next
    mov  edx, ebx
.cs_next:
    add  edi, 4
    dec  ecx
    jnz  .cs_var
    shr  eax, 1             ; mean/2
    cmp  edx, eax
    jle  .cs_locked
    mov  eax, 0
    jmp  .cs_done
.cs_locked:
    mov  eax, 1
.cs_done:
    pop  edi
    pop  edx
    pop  ecx
    pop  ebx
    ret

; ── Omega graph init ─────────────────────────────────────────────
; Nodes at 0x100000 (64 bytes each):
;   0=ROOT 1=CPU 2=MEM 3=IO 4=COMPILER
.omega_init:
    push eax
    push edi
    ; Zero 5 nodes × 64 bytes = 320 bytes
    mov  edi, 0x100000
    mov  ecx, 80            ; 320/4
.og_zero:
    mov  dword [edi], 0
    add  edi, 4
    dec  ecx
    jnz  .og_zero
    ; ROOT node
    mov  dword [0x100000], 0    ; id=0
    mov  word  [0x100008], 0    ; type=ROOT
    mov  dword [0x10000C], 3    ; state=READY
    mov  dword [0x100020], 0x100040  ; child=CPU
    ; CPU node
    mov  eax, 1
    cpuid
    mov  dword [0x100040], 1    ; id=1
    mov  word  [0x100048], 1    ; type=CPU
    mov  dword [0x10004C], 4    ; state=EXECUTED
    mov  dword [0x100058], 0x100000  ; parent=ROOT
    mov  dword [0x100068], 0x100080  ; sibling=MEM
    mov  dword [0x100070], eax       ; CPUID eax proof
    ; MEM node
    movzx eax, word [0x413]     ; BDA conventional KB
    mov  dword [0x100080], 2    ; id=2
    mov  word  [0x100088], 2    ; type=MEM
    mov  dword [0x10008C], 3    ; state=READY
    mov  dword [0x1000B0], eax  ; mem KB
    ; IO node (PCI scan placeholder)
    mov  dword [0x1000C0], 3    ; id=3
    mov  word  [0x1000C8], 3    ; type=IO
    mov  dword [0x1000CC], 2    ; state=CONFIGURED
    ; COMPILER node
    mov  dword [0x100100], 4    ; id=4
    mov  word  [0x100108], 4    ; type=COMPILER
    mov  dword [0x10010C], 4    ; state=EXECUTED
    ; Node count
    mov  dword [.omega_node_count], 5
    pop  edi
    pop  eax
    ret

; ── Serial output ────────────────────────────────────────────────
.putc:
    push edx
    push eax
    mov  edx, [.com_base]
    test edx, edx
    jz   .putc_done
    push edx
    add  edx, 5             ; LSR
.putc_w:
    in   al, dx
    test al, 0x20
    jz   .putc_w
    pop  edx
    pop  eax
    out  dx, al
    push eax
.putc_done:
    pop  eax
    pop  edx
    ret

.puts:
    push eax
    push esi
.puts_l:
    mov  al, [esi]
    test al, al
    jz   .puts_done
    call .putc
    inc  esi
    jmp  .puts_l
.puts_done:
    pop  esi
    pop  eax
    ret

.print_vendor_reg:
    ; Print 4 bytes from EAX as ASCII
    push ecx
    mov  ecx, 4
.pv_l:
    push eax
    and  al, 0xFF
    call .putc
    pop  eax
    shr  eax, 8
    dec  ecx
    jnz  .pv_l
    pop  ecx
    ret

.print_hex32:
    ; Print EAX as 8 hex digits
    push ecx
    push eax
    mov  ecx, 8
    rol  eax, 4
.ph_l:
    push eax
    and  al, 0x0F
    add  al, 0x30
    cmp  al, 0x3A
    jl   .ph_ok
    add  al, 7
.ph_ok:
    call .putc
    pop  eax
    rol  eax, 4
    dec  ecx
    jnz  .ph_l
    pop  eax
    pop  ecx
    ret

.print_dec:
    push eax
    push ecx
    push edx
    push edi
    lea  edi, [.dec_buf + 10]
    mov  byte [edi], 0
    mov  ecx, 10
.pd_l:
    mov  edx, 0
    div  ecx
    dec  edi
    add  dl, 0x30
    mov  [edi], dl
    test eax, eax
    jnz  .pd_l
    mov  esi, edi
    call .puts
    pop  edi
    pop  edx
    pop  ecx
    pop  eax
    ret

.dec_buf times 12 db 0

; ── Strings ──────────────────────────────────────────────────────
.banner     db 13,10,'[HDGL] phi-lattice firmware — QEMU simulation',13,10,0
.msg_com    db '[COM]  serial OK (dynamic port)',13,10,0
.msg_cpuid  db '[CPUID] vendor: ',0
.msg_fam    db '[CPUID] family/model/step: 0x',0
.msg_e820   db '[E820] entries: ',0
.msg_e820b  db 13,10,0
.msg_phi_init db '[PHI]  lattice seeded (128 slots, phi-harmonic)',13,10,0
.msg_phi_tick db '[PHI]  ticks: ',0
.msg_goi    db '  GOI events: ',0
.msg_guz    db '  GUZ: ',0
.msg_omega  db '[OMEGA] graph nodes: ',0
.msg_nodes  db ' (ROOT+CPU+MEM+IO+COMPILER)',13,10,0
.msg_cons   db '[CONS] consensus: ',0
.msg_conv   db 'CONVERGING (lattice still spreading)',13,10,0
.msg_lock   db 'LOCK (phase variance < mean/2)',13,10,0
.msg_halt   db '[HALT] all checks complete. Ω fixed point reached.',13,10,0

; ── GDT (16-bit accessible) ──────────────────────────────────────
[BITS 16]
align 4
.gdt_16:
    dq 0
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00
.gdt_16_end:
.gdt_ptr_16:
    dw .gdt_16_end - .gdt_16 - 1
    dd .gdt_16

times 8192-($-$$) db 0      ; pad to 16 sectors (8KB)
