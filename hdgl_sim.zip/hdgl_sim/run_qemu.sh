#!/bin/bash
# Run HDGL in QEMU simulated hardware
# Usage: ./run_qemu.sh [machine] [cpu] [mem]
MACHINE=${1:-pc}
CPU=${2:-}
MEM=${3:-64M}
CPU_ARG=""
[ -n "$CPU" ] && CPU_ARG="-cpu $CPU"

qemu-system-x86_64 \
    -machine $MACHINE \
    $CPU_ARG \
    -m $MEM \
    -drive file=hdgl_test.img,format=raw,if=ide \
    -boot order=c \
    -no-reboot \
    -display none \
    -serial stdio \
    -device isa-debug-exit,iobase=0x501,iosize=1
