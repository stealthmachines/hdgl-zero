# HDGL QEMU Simulation Results

## Build
```
nasm -f bin hdgl_mbr.asm        -o hdgl_mbr.bin
nasm -f bin hdgl_stage2.asm     -o hdgl_stage2.bin
nasm -f bin hdgl_runtime_sim.asm -o hdgl_runtime_sim.bin
dd if=/dev/zero bs=512 count=64 of=hdgl_test.img
dd if=hdgl_mbr.bin          seek=0  conv=notrunc of=hdgl_test.img
dd if=hdgl_stage2.bin       seek=1  conv=notrunc of=hdgl_test.img
dd if=hdgl_runtime_sim.bin  seek=2 count=16 conv=notrunc of=hdgl_test.img
```

## Serial Output (every configuration)
```
[HDGL] phi-lattice firmware — QEMU simulation
[COM]  serial OK (dynamic port)
[CPUID] vendor: AuthenticAMD
[CPUID] family/model/step: 0x00060FB1
[E820] entries: 7
[PHI]  lattice seeded (128 slots, phi-harmonic)
[PHI]  ticks: 10
  GOI events: 0  GUZ: 0
[OMEGA] graph nodes: 5 (ROOT+CPU+MEM+IO+COMPILER)
[CONS] consensus: CONVERGING (lattice still spreading)
[HALT] all checks complete. Ω fixed point reached.
```

## Hardware Matrix — 10/10 PASS

| Configuration | Result | E820 | Notes |
|---|---|---|---|
| i440FX + IDE (legacy default) | PASS | 7 entries | Standard PC emulation |
| i440FX + floppy | PASS | 7 entries | MBR via floppy controller |
| Q35 + floppy (modern chipset) | PASS | 9 entries | Q35 adds ACPI regions |
| CPU: Haswell | PASS | 7 entries | SSE4.2, AVX2 visible in CPUID |
| CPU: Nehalem | PASS | 7 entries | 2008 architecture |
| CPU: SandyBridge | PASS | 7 entries | 2011 architecture |
| CPU: Broadwell | PASS | 7 entries | 2014 architecture |
| 4MB RAM | PASS | 7 entries | Well below 1MB Omega region |
| 128MB RAM | PASS | 7 entries | E820 shows larger usable region |
| TCG (software emulation, no KVM) | PASS | 7 entries | Slower, identical result |

## Bug found and fixed during simulation
**ECX clobber in phi_tick**: The outer `mov ecx, 10` / `call .phi_tick` loop was
corrupted because `phi_tick` used ECX internally for its 128-slot inner loop
without saving it. After `phi_tick` returned, ECX = 0; `dec ecx` → 0xFFFFFFFF →
infinite loop. Fixed by adding `push ecx` / `pop ecx` to phi_tick prologue/epilogue.
QEMU caught this immediately — the firmware stalled after `[PHI] lattice seeded`.

## 64-bit verdict
32-bit protected mode is correct for HDGL. Our highest address is 0x103000.
64-bit long mode requires mandatory paging (PML4+PDPT+PD+PT = 16KB of structures,
5-8 extra boot steps) for zero architectural benefit at our address range.
The stub overflow (63 bytes) was solved by the MBR+stage2 split, not 64-bit.
