; x86 real mode entry — refactored from boot_stub glyph
; REFACTOR: NO xor reg,reg — use mov reg,0 for zero-init
; Source: conscious-128-bit-floor philosophy — phi-neutral, XOR-free
[bits 16]
[org  0x7C00]

; Flatten segments — Omega requires clean flat state
; Phi-neutral: segment registers → 0 via mov (not xor)
cli
mov  ax, 0
mov  ds, ax
mov  es, ax
mov  ss, ax
mov  sp, 0x7BF0
sti

; Preserve drive number — storage glyph needs it
mov  [.drive], dl

; LBA detection: try INT 13h AH=41h
mov  ah, 0x41
mov  bx, 0x55AA
int  0x13
jc   .use_chs
cmp  bx, 0xAA55
jne  .use_chs
mov  byte [.lba], 1

; Load runtime (sectors 1-16)
.use_chs:
call .load_runtime
jc   .halt

; Load HDGL source (sectors 18-21)
call .load_source

; Mark load address for runtime to find
mov  word [0x7FF0], 0xA000
mov  word [0x7FF2], 0x0000

; Transfer — this stub's work is done
jmp  0x0000:0x7E00

.halt:
cli
hlt
jmp  .halt

; Load runtime: LBA 1-16 to 0x7E00
.load_runtime:
cmp  byte [.lba], 0
je   .rt_chs
mov  dword [.dap+8],  1
mov  dword [.dap+12], 0
mov  word  [.dap+2],  16
mov  word  [.dap+4],  0x7E00
mov  word  [.dap+6],  0
mov  ah, 0x42
mov  dl, [.drive]
mov  si, .dap
int  0x13
ret
.rt_chs:
mov  ah, 0x02
mov  al, 16
mov  ch, 0
mov  cl, 2
mov  dh, 0
mov  dl, [.drive]
mov  bx, 0x7E00
int  0x13
ret

; Load HDGL source: LBA 18-21 to 0xA000
.load_source:
cmp  byte [.lba], 0
je   .src_chs
mov  dword [.dap+8],  18
mov  dword [.dap+12], 0
mov  word  [.dap+2],  4
mov  word  [.dap+4],  0xA000
mov  word  [.dap+6],  0
mov  ah, 0x42
mov  dl, [.drive]
mov  si, .dap
int  0x13
ret
.src_chs:
mov  ah, 0x02
mov  al, 74
mov  ch, 0
mov  cl, 1
mov  dh, 1
mov  dl, [.drive]
mov  bx, 0xA000
int  0x13
ret

.drive db 0x80
.lba   db 0
.dap   db 0x10, 0x00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

times 510-($-$$) db 0
dw 0xAA55
