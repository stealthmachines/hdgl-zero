#!/bin/bash
# HDGL Firmware — build from source
# Requires: gcc, nasm
set -e
echo "[1/4] Compile bootstrap..."
gcc -O2 -std=c99 hdgl_bootstrap.c -o hdgl_bootstrap -lm
echo "[2/4] Parse glyphs → emit x86..."
./hdgl_bootstrap hdgl_firmware.hdgl firmware_runtime.asm
echo "[3/4] Assemble..."
nasm -f bin hdgl_boot_stub.asm -o hdgl_boot_stub.bin
nasm -f bin firmware_runtime.asm -o firmware_runtime.bin
echo "[4/4] Compose image..."
SRCSEC=$(( ($(wc -c < hdgl_firmware.hdgl) + 511) / 512 ))
IMGSZ=$(( (18 + SRCSEC) * 512 ))
dd if=/dev/zero bs=$IMGSZ count=1 of=hdgl_firmware.img 2>/dev/null
dd if=hdgl_boot_stub.bin  bs=512 count=1        seek=0  conv=notrunc of=hdgl_firmware.img 2>/dev/null
dd if=firmware_runtime.bin bs=512 count=16      seek=1  conv=notrunc of=hdgl_firmware.img 2>/dev/null
dd if=hdgl_firmware.hdgl   bs=512 count=$SRCSEC seek=18 conv=notrunc of=hdgl_firmware.img 2>/dev/null
echo ""
echo "Done: hdgl_firmware.img"
echo "Run:  qemu-system-x86_64 -drive file=hdgl_firmware.img,format=raw,if=ide -boot order=c -m 64M -no-reboot -display none -serial stdio"
echo "Flash: dd if=hdgl_firmware.img of=/dev/sdX bs=512 oflag=sync"
echo ""
echo "NOTE: Two post-emit fixes to firmware_runtime.asm before nasm (see MANIFEST)"
