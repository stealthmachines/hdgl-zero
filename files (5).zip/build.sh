#!/bin/bash
# HDGL Firmware — Build Script
# ============================================================
# Requires: gcc, nasm, python3
# No other dependencies.

set -e

echo "[1/5] Compiling bootstrap..."
gcc -O2 -std=c99 hdgl_bootstrap.c -o hdgl_bootstrap -lm

echo "[2/5] Parsing firmware source → Omega graph → x86 assembly..."
./hdgl_bootstrap hdgl_firmware.hdgl firmware_runtime.asm

echo "[3/5] Assembling runtime (16 sectors, 8192 bytes)..."
nasm -f bin firmware_runtime.asm -o firmware_runtime.bin

echo "[4/5] Extracting and assembling boot stub (1 sector, 512 bytes)..."
python3 -c "
with open('hdgl_boot.hdg') as f: content = f.read()
start = content.find('        ; x86 real mode entry - generated from boot_stub glyph')
end   = content.rfind('\n    end\nend')
asm = content[start:end]
lines = [l[8:] if l.startswith('        ') else (l[4:] if l.startswith('    ') else l)
         for l in asm.split('\n')]
open('hdgl_boot_stub.asm','w').write('\n'.join(lines))
"
nasm -f bin hdgl_boot_stub.asm -o hdgl_boot_stub.bin

echo "[5/5] Composing firmware image..."
SOURCE_SECS=\$(( (\$(wc -c < hdgl_firmware.hdgl) + 511) / 512 ))
IMAGE_SIZE=\$(( (18 + SOURCE_SECS) * 512 ))
dd if=/dev/zero    bs=\$IMAGE_SIZE count=1 of=hdgl_firmware.img 2>/dev/null
dd if=hdgl_boot_stub.bin  bs=512 count=1            seek=0  conv=notrunc of=hdgl_firmware.img 2>/dev/null
dd if=firmware_runtime.bin bs=512 count=16           seek=1  conv=notrunc of=hdgl_firmware.img 2>/dev/null
dd if=hdgl_firmware.hdgl   bs=512 count=\$SOURCE_SECS seek=18 conv=notrunc of=hdgl_firmware.img 2>/dev/null

echo ""
echo "Done. hdgl_firmware.img: \$(wc -c < hdgl_firmware.img) bytes"
echo ""
echo "Run (QEMU):"
echo "  qemu-system-x86_64 -drive file=hdgl_firmware.img,format=raw,if=floppy \\"
echo "    -boot order=a -m 64M -no-reboot -serial stdio"
echo ""
echo "Flash (USB):"
echo "  sudo dd if=hdgl_firmware.img of=/dev/sdX bs=512 count=92 oflag=sync"
