/*
 * ═══════════════════════════════════════════════════════════════════════════
 * HDGL RUNTIME - Console Version
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Same as hdgl_runtime_native.c but outputs to console as well
 * ═══════════════════════════════════════════════════════════════════════════
 */

#include <stdio.h>
#include <stdint.h>

typedef enum {
    OMEGA_ROOT = 0,
    OMEGA_CPU,
    OMEGA_MEM,
    OMEGA_IO,
    OMEGA_GPU,
    OMEGA_STORAGE,
    OMEGA_NET,
    OMEGA_BOOT,
    OMEGA_COMPILER,
    OMEGA_PARSER,
    OMEGA_CODEGEN,
    OMEGA_OPTIMIZER,
    OMEGA_MAX
} OmegaClass;

typedef enum {
    OMEGA_STATE_INIT = 0,
    OMEGA_STATE_DISCOVERED,
    OMEGA_STATE_CONFIGURED,
    OMEGA_STATE_READY,
    OMEGA_STATE_EXECUTED,
    OMEGA_STATE_COMPLETED,
    OMEGA_STATE_MAX
} OmegaState;

typedef struct Omega {
    uint64_t id;
    uint16_t class;
    uint16_t subtype;
    uint32_t state;
    uint64_t capabilities;
    struct Omega* parent;
    struct Omega* child;
    struct Omega* sibling;
    uint32_t flags;
} Omega;

static Omega omega_root;
static Omega omega_devices[256];
static size_t omega_count = 0;

static inline void hdgl_print(const char* str) {
    printf("%s", str);
}

static inline Omega* hdgl_glyph(OmegaClass cls, const char* name) {
    if (omega_count >= 256) return NULL;
    
    Omega* omega = &omega_devices[omega_count++];
    omega->id = omega_count;
    omega->class = cls;
    omega->state = OMEGA_STATE_INIT;
    omega->capabilities = 0;
    omega->parent = NULL;
    omega->child = NULL;
    omega->sibling = NULL;
    omega->flags = 0;
    
    return omega;
}

static inline void hdgl_mutate(Omega* omega, OmegaState new_state, uint32_t new_flags) {
    omega->state = (uint32_t)new_state;
    omega->flags = (omega->flags & ~(0x0F)) | (new_flags & 0x0F);
}

static inline Omega* hdgl_branch(Omega* parent, Omega* child) {
    child->parent = parent;
    
    if (!parent->child) {
        parent->child = child;
    } else {
        Omega* sibling = parent->child;
        while (sibling->sibling) {
            sibling = sibling->sibling;
        }
        sibling->sibling = child;
    }
    
    child->sibling = NULL;
    return child;
}

static inline void hdgl_recurse(Omega* root, void (*fn)(Omega*)) {
    Omega* current = root->child;
    while (current) {
        fn(current);
        current = current->sibling;
    }
}

static inline void hdgl_prune(Omega* omega) {
    if (omega->parent) {
        Omega* sibling = omega->parent->child;
        while (sibling) {
            if (sibling == omega) {
                if (sibling->sibling) {
                    sibling->parent->child = sibling->sibling;
                }
                omega->parent->child = NULL;
                break;
            }
            sibling = sibling->sibling;
        }
    }
    omega->parent = NULL;
    omega->child = NULL;
    omega->sibling = NULL;
    omega->state = OMEGA_STATE_INIT;
    omega->flags = 0;
}

typedef struct {
    const char* source;
    size_t pos;
    size_t len;
} HDGLParser;

static inline void hdgl_skip_whitespace(HDGLParser* p) {
    while (p->pos < p->len && (p->source[p->pos] == ' ' || p->source[p->pos] == '\t' || p->source[p->pos] == '\n' || p->source[p->pos] == '\r')) {
        p->pos++;
    }
}

static inline void hdgl_parse_glyph(HDGLParser* p) {
    static const char classes[] = "ROOT CPU MEM IO GPU STORAGE NET BOOT COMPILER PARSER CODEGEN OPTIMIZER";
    
    char name[64] = {0};
    OmegaClass cls = OMEGA_CPU;
    
    size_t i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\n' && i < 63) {
        name[i++] = p->source[p->pos++];
    }
    name[i] = '\0';
    
    if (strstr(name, "ROOT") != NULL) cls = OMEGA_ROOT;
    else if (strstr(name, "CPU") != NULL) cls = OMEGA_CPU;
    else if (strstr(name, "MEM") != NULL) cls = OMEGA_MEM;
    else if (strstr(name, "IO") != NULL) cls = OMEGA_IO;
    else if (strstr(name, "GPU") != NULL) cls = OMEGA_GPU;
    else if (strstr(name, "STORAGE") != NULL) cls = OMEGA_STORAGE;
    else if (strstr(name, "BOOT") != NULL) cls = OMEGA_BOOT;
    else if (strstr(name, "COMPILER") != NULL) cls = OMEGA_COMPILER;
    else if (strstr(name, "PARSER") != NULL) cls = OMEGA_PARSER;
    else if (strstr(name, "CODEGEN") != NULL) cls = OMEGA_CODEGEN;
    else if (strstr(name, "OPTIMIZER") != NULL) cls = OMEGA_OPTIMIZER;
    
    Omega* parent = NULL;
    if (strstr(name, "root") != NULL) parent = &omega_root;
    else if (strstr(name, "cpu") != NULL) parent = &omega_root;
    
    Omega* new_glyph = hdgl_glyph(cls, name);
    
    if (new_glyph) {
        if (parent) hdgl_branch(parent, new_glyph);
        
        hdgl_print(name);
        hdgl_print(": Created\n");
    }
}

static inline void hdgl_parse_recurse(HDGLParser* p) {
    char name[64] = {0};
    
    size_t i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\n' && i < 63) {
        name[i++] = p->source[p->pos++];
    }
    name[i] = '\0';
    
    Omega* found = NULL;
    Omega* current = omega_root.child;
    
    while (current) {
        if (current->class >= 'A' && current->class <= 'Z') {
            if (strstr((const char*)&current->class, name) != NULL) {
                found = current;
                break;
            }
        }
        current = current->sibling;
    }
    
    if (found) {
        hdgl_recurse(found, (void (*)(Omega*))hdgl_mutate);
        hdgl_mutate(found, OMEGA_STATE_DISCOVERED, 0x01);
        
        hdgl_print(name);
        hdgl_print(": recursed\n");
    }
}

static inline void hdgl_parse_mutate(HDGLParser* p) {
    static const char* states[] = {"discovered", "configured", "ready", "executed", "completed"};
    
    char state_name[32] = {0};
    size_t i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\n' && i < 31) {
        state_name[i++] = p->source[p->pos++];
    }
    state_name[i] = '\0';
    
    Omega* active = &omega_root;
    
    for (int s = 0; s < 5; s++) {
        if (strstr(state_name, states[s]) != NULL) {
            hdgl_mutate(active, OMEGA_STATE_INIT + s, 0x02);
            hdgl_print("mutated to ");
            hdgl_print(states[s]);
            hdgl_print("\n");
            break;
        }
    }
}

static inline void hdgl_parse_branch(HDGLParser* p) {
    char parent_name[64] = {0};
    char child_name[64] = {0};
    
    size_t i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\t' && i < 63) {
        parent_name[i++] = p->source[p->pos++];
    }
    parent_name[i] = '\0';
    
    hdgl_skip_whitespace(p);
    
    i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\n' && i < 63) {
        child_name[i++] = p->source[p->pos++];
    }
    child_name[i] = '\0';
    
    OmegaClass child_class = OMEGA_IO;
    if (strstr(child_name, "cpu") != NULL) child_class = OMEGA_CPU;
    if (strstr(child_name, "mem") != NULL) child_class = OMEGA_MEM;
    if (strstr(child_name, "pci") != NULL) child_class = OMEGA_IO;
    
    Omega* child = hdgl_glyph(child_class, child_name);
    
    if (child) {
        Omega* parent = &omega_root;
        if (strstr(parent_name, "root") != NULL) parent = &omega_root;
        
        if (parent) {
            hdgl_branch(parent, child);
            hdgl_print("branched ");
            hdgl_print(child_name);
            hdgl_print(" under ");
            hdgl_print(parent_name);
            hdgl_print("\n");
        }
    }
}

static inline void hdgl_parse_prune(HDGLParser* p) {
    char name[64] = {0};
    size_t i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\n' && i < 63) {
        name[i++] = p->source[p->pos++];
    }
    name[i] = '\0';
    
    Omega* current = omega_root.child;
    Omega* found = NULL;
    
    while (current) {
        if (current->class >= 'A' && current->class <= 'Z') {
            if (strstr((const char*)&current->class, name) != NULL) {
                found = current;
                break;
            }
        }
        current = current->sibling;
    }
    
    if (found) {
        hdgl_prune(found);
        hdgl_print("pruned ");
        hdgl_print(name);
        hdgl_print("\n");
    }
}

void hdgl_runtime_main(const char* source) {
    HDGLParser p;
    p.source = source;
    p.pos = 0;
    p.len = strlen(source);
    
    printf("╔══════════════════════════════════════════════════════════╗\n");
    printf("║  HDGL RUNTIME - Pure Glyph Interpreter                    ║\n");
    printf("║  Executing: Glyph Operations                              ║\n");
    printf("╚══════════════════════════════════════════════════════════╝\n\n");
    
    while (p.pos < p.len) {
        hdgl_skip_whitespace(&p);
        if (p.pos >= p.len) break;
        if (p.source[p.pos] == '#') {
            while (p.pos < p.len && p.source[p.pos] != '\n') p.pos++;
            continue;
        }
        
        if (p.pos < p.len && p.source[p.pos] == 'g') {
            hdgl_parse_glyph(&p);
            continue;
        }
        
        if (p.pos < p.len && p.source[p.pos] == 'r') {
            if (strstr(&p.source[p.pos], "recurse") != NULL) {
                hdgl_parse_recurse(&p);
                continue;
            }
        }
        
        if (p.pos < p.len && p.source[p.pos] == 'm') {
            if (strstr(&p.source[p.pos], "mutate") != NULL) {
                hdgl_parse_mutate(&p);
                continue;
            }
        }
        
        if (p.pos < p.len && p.source[p.pos] == 'b') {
            if (strstr(&p.source[p.pos], "branch") != NULL) {
                hdgl_parse_branch(&p);
                continue;
            }
        }
        
        if (p.pos < p.len && p.source[p.pos] == 'p') {
            if (strstr(&p.source[p.pos], "prune") != NULL) {
                hdgl_parse_prune(&p);
                continue;
            }
        }
        
        p.pos++;
    }
    
    printf("\n✓ HDGL Execution Complete\n");
}

void hdgl_reset_entry(void) {
    omega_root.id = 0;
    omega_root.class = OMEGA_ROOT;
    omega_root.state = OMEGA_STATE_INIT;
    
    printf("╔══════════════════════════════════════════════════════════╗\n");
    printf("║  HDGL RUNTIME v1.0 - Pure Glyph Interpreter               ║\n");
    printf("║  Reset Vector: 0xFFFF:0000                                ║\n");
    printf("╚══════════════════════════════════════════════════════════╝\n\n");
    
    const char* hdgl_source = 
"# HDGL Test Source - Demonstrates Four Primitives\nglyph root\nglyph cpu\nbranch cpu memory\nrecurse cpu\nmutate discovered\nmutate executed\n";
    
    hdgl_runtime_main(hdgl_source);
    
    while (1) {
    }
}

int main(void) {
    hdgl_reset_entry();
    return 0;
}
