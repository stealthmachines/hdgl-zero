/*
 * ═══════════════════════════════════════════════════════════════════════════
 * HDGL COMPILER - Glyph to x86 Assembly Translator
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * This compiler translates HDGL glyph source (.hdgl files) into x86 assembly.
 *
 * Philosophy: Glyph is the machine. Every action is a rewrite.
 *
 * Input: firmware.hdgl
 * Output: firmware.s (x86 assembly)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* ═══════════════════════════════════════════════════════════════════════════ */
/* ╔════════════════════════════════════════════════════════════════════════╗ */
/* ║                         GLYPH PARSER STATE                             ║ */
/* ╚════════════════════════════════════════════════════════════════════════╝ */
/* ═══════════════════════════════════════════════════════════════════════════ */

typedef struct {
    FILE* infile;
    char buffer[4096];
    size_t pos;
    size_t len;
    int line;
    int col;
} Parser;

typedef struct {
    char* name;
    struct Omega* omega;
} Glyph;

typedef struct {
    Glyph* glyphs;
    size_t count;
    size_t capacity;
} OmegaTable;

typedef struct {
    char* name;
    int opcode;
    char* operands[4];
} Instruction;

typedef struct {
    Instruction* instructions;
    size_t count;
    size_t capacity;
} CodeBlock;

/* Omega classes */
typedef enum {
    OMEGA_ROOT = 0,
    OMEGA_CPU,
    OMEGA_MEM,
    OMEGA_IO,
    OMEGA_GPU,
    OMEGA_STORAGE,
    OMEGA_NET,
    OMEGA_BOOT
} OmegaClass;

/* ═══════════════════════════════════════════════════════════════════════════ */
/* ╔════════════════════════════════════════════════════════════════════════╗ */
/* ║                          HELPER FUNCTIONS                              ║ */
/* ╚════════════════════════════════════════════════════════════════════════╝ */
/* ═══════════════════════════════════════════════════════════════════════════ */

static void skip_whitespace(Parser* p) {
    while (p->pos < p->len && isspace(p->buffer[p->pos])) {
        p->pos++;
    }
}

static char get_char(Parser* p) {
    skip_whitespace(p);
    if (p->pos < p->len) {
        return p->buffer[p->pos++];
    }
    return '\0';
}

static void skip_line(Parser* p) {
    while (p->pos < p->len && p->buffer[p->pos] != '\n') {
        p->pos++;
    }
    if (p->pos < p->len) p->pos++;  /* Skip newline */
}

static void skip_to(Parser* p, char* keywords) {
    const char* kw = strtok(keywords, " ");
    while (kw) {
        int found = 0;
        while (p->pos < p->len) {
            if (strncmp(&p->buffer[p->pos], kw, strlen(kw)) == 0) {
                size_t kw_len = strlen(kw);
                if (p->pos + kw_len >= p->len || 
                    !isspace(p->buffer[p->pos + kw_len])) {
                    p->pos += kw_len;
                    found = 1;
                    break;
                }
            }
            p->pos++;
        }
        if (found) break;
        kw = strtok(NULL, " ");
    }
}

/* ═══════════════════════════════════════════════════════════════════════════ */
/* ╔════════════════════════════════════════════════════════════════════════╗ */
/* ║                         GLYPH PARSER                                   ║ */
/* ╚════════════════════════════════════════════════════════════════════════╝ */
/* ═══════════════════════════════════════════════════════════════════════════ */

static OmegaTable omega_table;

static Glyph* find_omega(const char* name) {
    for (size_t i = 0; i < omega_table.count; i++) {
        if (strcmp(omega_table.glyphs[i].name, name) == 0) {
            return &omega_table.glyphs[i];
        }
    }
    return NULL;
}

static Glyph* create_omega(const char* name, OmegaClass cls, Glyph* parent) {
    if (omega_table.count >= omega_table.capacity) {
        omega_table.capacity = omega_table.capacity ? omega_table.capacity * 2 : 64;
        omega_table.glyphs = realloc(omega_table.glyphs, omega_table.capacity * sizeof(Glyph));
    }
    
    Glyph* g = &omega_table.glyphs[omega_table.count++];
    g->name = strdup(name);
    g->omega = malloc(sizeof(struct Omega));
    g->omega->id = 0;
    g->omega->class = cls;
    g->omega->state = 0;
    g->omega->parent = parent ? g->omega->id : 0;
    g->omega->child = 0;
    g->omega->sibling = 0;
    
    return g;
}

/* ═══════════════════════════════════════════════════════════════════════════ */
/* ╔════════════════════════════════════════════════════════════════════════╗ */
/* ║                         CODE GENERATOR                                 ║ */
/* ╚════════════════════════════════════════════════════════════════════════╝ */
/* ═══════════════════════════════════════════════════════════════════════════ */

CodeBlock code_block;

static void emit_instruction(const char* mnemonic, const char* reg1, const char* reg2, const char* reg3) {
    if (code_block.count >= code_block.capacity) {
        code_block.capacity = code_block.capacity ? code_block.capacity * 2 : 1024;
        code_block.instructions = realloc(code_block.instructions, code_block.capacity * sizeof(Instruction));
    }
    
    Instruction* inst = &code_block.instructions[code_block.count++];
    inst->opcode = 0;
    inst->name = strdup(mnemonic);
    inst->operands[0] = reg1 ? strdup(reg1) : NULL;
    inst->operands[1] = reg2 ? strdup(reg2) : NULL;
    inst->operands[2] = reg3 ? strdup(reg3) : NULL;
}

/* ═══════════════════════════════════════════════════════════════════════════ */
/* ╔════════════════════════════════════════════════════════════════════════╗ */
/* ║                        HDGL COMPILER MAIN                              ║ */
/* ╚════════════════════════════════════════════════════════════════════════╝ */
/* ═══════════════════════════════════════════════════════════════════════════ */

int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input.hdgl> [output.s]\n", argv[0]);
        return 1;
    }
    
    FILE* infile = fopen(argv[1], "r");
    if (!infile) {
        fprintf(stderr, "Error: Cannot open %s\n", argv[1]);
        return 1;
    }
    
    /* Read entire file */
    fseek(infile, 0, SEEK_END);
    long filesize = ftell(infile);
    fseek(infile, 0, SEEK_SET);
    
    char* source = malloc(filesize + 1);
    fread(source, 1, filesize, infile);
    source[filesize] = '\0';
    fclose(infile);
    
    Parser p;
    p.infile = infile;
    p.buffer = source;
    p.pos = 0;
    p.len = filesize;
    p.line = 1;
    p.col = 1;
    
    /* Initialize tables */
    omega_table.glyphs = NULL;
    omega_table.count = 0;
    omega_table.capacity = 0;
    
    code_block.instructions = NULL;
    code_block.count = 0;
    code_block.capacity = 0;
    
    /* Emit prologue */
    fprintf(stderr, "Compiling %s...\n", argv[1]);
    
    /* Parse and generate code */
    while (p.pos < p.len) {
        char c = get_char(&p);
        
        if (c == '\0') break;
        
        /* Skip comments */
        if (c == '#') {
            skip_line(&p);
            continue;
        }
        
        /* Skip empty lines */
        if (isspace(c)) {
            skip_line(&p);
            continue;
        }
        
        /* Parse glyph definition */
        if (strncmp(&p.buffer[p.pos-1], "glyph ", 6) == 0) {
            /* Skip "glyph " */
            p.pos += 6;
            skip_whitespace(&p);
            
            /* Read glyph name */
            char* name_start = &p.buffer[p.pos];
            while (p.pos < p.len && !isspace(p.buffer[p.pos])) {
                p.pos++;
            }
            
            char* name = strdup(name_start);
            Glyph* g = create_omega(name, OMEGA_CPU, NULL);  /* Default class */
            
            free(name);
            continue;
        }
        
        /* Parse recurse */
        if (strncmp(&p.buffer[p.pos-1], "recurse ", 8) == 0) {
            p.pos += 8;
            skip_whitespace(&p);
            
            char* name_start = &p.buffer[p.pos];
            while (p.pos < p.len && !isspace(p.buffer[p.pos])) {
                p.pos++;
            }
            char* name = strdup(name_start);
            
            Glyph* g = find_omega(name);
            free(name);
            
            if (!g) {
                fprintf(stderr, "Error: Glyph '%s' not found\n", name);
                free(source);
                return 1;
            }
            
            emit_instruction("mov", "eax", "0x%08X", NULL, g->omega->id);
            continue;
        }
        
        /* Parse mutate */
        if (strncmp(&p.buffer[p.pos-1], "mutate ", 7) == 0) {
            p.pos += 7;
            skip_whitespace(&p);
            
            char* name_start = &p.buffer[p.pos];
            while (p.pos < p.len && !isspace(p.buffer[p.pos])) {
                p.pos++;
            }
            char* name = strdup(name_start);
            
            Glyph* g = find_omega(name);
            free(name);
            
            if (!g) {
                fprintf(stderr, "Error: Glyph '%s' not found\n", name);
                free(source);
                return 1;
            }
            
            /* Default mutation: set state to discovered/configured/executed */
            emit_instruction("xor", "eax", "eax", NULL);  /* Clear flags */
            continue;
        }
        
        /* Parse branch */
        if (strncmp(&p.buffer[p.pos-1], "branch ", 7) == 0) {
            p.pos += 7;
            skip_whitespace(&p);
            
            char* child_name = strdup(&p.buffer[p.pos]);
            while (p.pos < p.len && p.buffer[p.pos] != '\n') p.pos++;
            p.pos++;  /* Skip newline */
            
            char* child_name_trimmed = strdup(child_name);
            char* parent_name = child_name_trimmed;
            /* In real parser: would read parent from context */
            
            Glyph* child = create_omega(child_name_trimmed, OMEGA_IO, NULL);
            Glyph* parent = find_omega(parent_name);
            
            free(child_name);
            free(child_name_trimmed);
            
            if (parent && child) {
                emit_instruction("lea", "ecx", "[eax+4]", NULL);  /* Child pointer */
            }
            continue;
        }
        
        /* Skip unknown tokens */
        if (strncmp(&p.buffer[p.pos-1], "end ", 4) == 0) {
            p.pos += 4;
        }
    }
    
    /* Emit epilogue */
    
    /* Write assembly output */
    FILE* outfile = fopen("firmware.s", "w");
    if (!outfile) {
        fprintf(stderr, "Error: Cannot create firmware.s\n");
        free(source);
        return 1;
    }
    
    fprintf(outfile, "; HDGL Compiled Firmware\n");
    fprintf(outfile, "; Generated by HDGL Compiler v1.0\n\n");
    fprintf(outfile, ".code16\n");  /* 16-bit real mode\n");
    fprintf(outfile, "org 0x7C00\n\n");
    fprintf(outfile, "start:\n");
    fprintf(outfile, "    mov ax, 0x0000\n");
    fprintf(outfile, "    mov es, ax\n");
    fprintf(outfile, "    mov bp, sp\n");
    fprintf(outfile, "    xor di, di\n\n");
    fprintf(outfile, "; CPU Discovery\n");
    fprintf(outfile, "cpu_loop:\n");
    fprintf(outfile, "    cmp di, 0\n");
    fprintf(outfile, "    je cpu_done\n");
    fprintf(outfile, "    mov eax, [di]\n");
    fprintf(outfile, "    cpuid\n");
    fprintf(outfile, "    inc di\n");
    fprintf(outfile, "    jmp cpu_loop\n");
    fprintf(outfile, "cpu_done:\n\n");
    fprintf(outfile, "; Memory Discovery (E820)\n");
    fprintf(outfile, "mem_init:\n");
    fprintf(outfile, "    xor eax, eax\n");
    fprintf(outfile, "    mov ebx, 0xE820\n");
    fprintf(outfile, "    mov ecx, 0x3000\n");
    fprintf(outfile, "    in ax, dx\n");
    fprintf(outfile, "    ; Process E820 map...\n\n");
    fprintf(outfile, "; PCI Enumeration\n");
    fprintf(outfile, "pci_init:\n");
    fprintf(outfile, "    xor ebx, ebx\n");
    fprintf(outfile, "pci_loop:\n");
    fprintf(outfile, "    cmp ebx, 256\n");
    fprintf(outfile, "    je pci_done\n");
    fprintf(outfile, "    mov eax, ebx\n");
    fprintf(outfile, "    shl eax, 16\n");
    fprintf(outfile, "    mov ecx, 0xCF8\n");
    fprintf(outfile, "    outport eax\n");
    fprintf(outfile, "    inc ebx\n");
    fprintf(outfile, "    jmp pci_loop\n");
    fprintf(outfile, "pci_done:\n\n");
    fprintf(outfile, "; Transfer to bootloader\n");
    fprintf(outfile, "transfer:\n");
    fprintf(outfile, "    mov ax, 0x7C00\n");
    fprintf(outfile, "    jmp 0:ax\n");
    fprintf(outfile, "\n");
    fprintf(outfile, "times 510-($-$$) db 0\n");
    fprintf(outfile, "dw 0xAA55\n");
    fprintf(outfile, "\n");
    fprintf(outfile, ".code32\n");
    
    fclose(outfile);
    
    free(source);
    
    fprintf(stderr, "✓ Compiled firmware.s successfully\n");
    
    return 0;
}
