@echo off
REM ═══════════════════════════════════════════════════════════════════════════
REM HDGL Native Runtime Test Suite
REM ═══════════════════════════════════════════════════════════════════════════

echo ╔══════════════════════════════════════════════════════════╗
echo ║  HDGL Native Runtime Test Suite                          ║
echo ║  Testing: Pure Glyph Execution Engine                    ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

REM Test 1: Check if HDGL runtime exists
echo Test 1: Checking HDGL Runtime Source...
if exist hdgl_runtime_native.c (
    echo [OK] hdgl_runtime_native.c found
    find /C /V "" hdgl_runtime_native.c > temp_count.txt
    for /f %%a in ('type temp_count.txt') do (
        echo [INFO] hdgl_runtime_native.c has %%~a lines
    )
    del temp_count.txt
) else (
    echo [ERROR] hdgl_runtime_native.c not found
)

REM Test 2: Check if HDGL compiler exists
echo.
echo Test 2: Checking HDGL Compiler Source...
if exist hdgl_compiler.hdgl (
    echo [OK] hdgl_compiler.hdgl found
    find /C /V "" hdgl_compiler.hdgl > temp_count.txt
    for /f %%a in ('type temp_count.txt') do (
        echo [INFO] hdgl_compiler.hdgl has %%~a lines
    )
    del temp_count.txt
) else (
    echo [ERROR] hdgl_compiler.hdgl not found
)

REM Test 3: Check if firmware source exists
echo.
echo Test 3: Checking HDGL Firmware Source...
if exist firmware.hdgl (
    echo [OK] firmware.hdgl found
) else (
    echo [ERROR] firmware.hdgl not found
)

REM Test 4: Validate HDGL Runtime Structure
echo.
echo Test 4: Validating HDGL Runtime Structure...
if exist hdgl_runtime_native.c (
    findstr /C:"typedef struct Omega" hdgl_runtime_native.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] Omega structure defined
    )
    findstr /C:"hdgl_glyph" hdgl_runtime_native.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] hdgl_glyph() primitive defined
    )
    findstr /C:"hdgl_mutate" hdgl_runtime_native.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] hdgl_mutate() primitive defined
    )
    findstr /C:"hdgl_branch" hdgl_runtime_native.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] hdgl_branch() primitive defined
    )
    findstr /C:"hdgl_recurse" hdgl_runtime_native.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] hdgl_recurse() primitive defined
    )
    findstr /C:"hdgl_prune" hdgl_runtime_native.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] hdgl_prune() primitive defined
    )
    findstr /C:"\.code16" hdgl_runtime_native.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] 16-bit x86 code section defined
    )
)

REM Test 5: Validate HDGL Compiler Structure
echo.
echo Test 5: Validating HDGL Compiler Structure...
if exist hdgl_compiler.hdgl (
    findstr /C:"glyph compiler_root" hdgl_compiler.hdgl > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] Compiler root glyph defined
    )
    findstr /C:"rule glyph_def" hdgl_compiler.hdgl > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] Glyph definition rule defined
    )
    findstr /C:"self_compile" hdgl_compiler.hdgl > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] Self-hosting rule defined
    )
)

REM Test 6: Show HDGL Source Preview
echo.
echo Test 6: HDGL Source Preview...
if exist hdgl_compiler.hdgl (
    echo [INFO] hdgl_compiler.hdgl (first 10 lines):
    findstr /N "^glyph\|^rule\|^entry\|^self" hdgl_compiler.hdgl | findstr /N "^1\|^2\|^3\|^4\|^5\|^6\|^7\|^8\|^9\|^10"
)

REM Test 7: Show Runtime Preview
echo.
echo Test 7: HDGL Runtime Preview...
if exist hdgl_runtime_native.c (
    echo [INFO] hdgl_runtime_native.c primitives:
    findstr /C:"hdgl_glyph\|hdgl_mutate\|hdgl_branch\|hdgl_recurse\|hdgl_prune" hdgl_runtime_native.c | findstr /N "^.*primitive\|^.*inline\|^.*static" | head -10
)

REM Test 8: Show Compilation Workflow
echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║  HDGL Native Compilation Workflow                        ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
echo Step 1: Compile HDGL Runtime
echo   gcc hdgl_runtime_native.c -o hdgl_runtime
echo.
echo Step 2: Run HDGL Interpreter
echo   ./hdgl_runtime firmware.hdgl
echo.
echo Step 3: Generate Assembly
echo   (HDGL runtime outputs firmware.s)
echo.
echo Step 4: Assemble
echo   as -o firmware.o firmware.s
echo.
echo Step 5: Link
echo   ld -o firmware.bin firmware.o
echo.
echo Step 6: Boot in QEMU
echo   qemu-system-x86_64 -bios firmware.bin -boot n

REM Test 9: Validate Four Primitives
echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║  HDGL Four Primitives                                     ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
echo Primitive 0: glyph - Create state
echo   hdgl_glyph(OmegaClass cls, const char* name)
echo.
echo Primitive 1: mutate - State transition
echo   hdgl_mutate(omega, state, flags)
echo.
echo Primitive 2: branch - Hierarchy creation
echo   hdgl_branch(parent, child)
echo.
echo Primitive 3: recurse - Discovery traversal
echo   hdgl_recurse(root, operation)
echo.
echo Primitive 4: prune - Resource cleanup
echo   hdgl_prune(omega)
echo.

REM Test 10: Summary
echo ╔══════════════════════════════════════════════════════════╗
echo ║  HDGL Native Compiler Suite Complete                      ║
echo ║  Self-Hosting: HDGL Compiler Written in HDGL              ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
echo Next Steps:
echo   1. Install GCC (https://winlibs.com)
echo   2. Compile: gcc hdgl_runtime_native.c -o hdgl_runtime
echo   3. Execute: ./hdgl_runtime firmware.hdgl
echo   4. See pure glyph operations execute in real-time
echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║  Glyph IS the Machine                                    ║
echo ║  Compiler IS HDGL                                        ║
echo ║  Firmware IS Glyph                                       ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
