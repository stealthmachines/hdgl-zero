#include <stdio.h>
#include <stdint.h>
#include <string.h>

typedef enum { OMEGA_ROOT = 0, OMEGA_CPU, OMEGA_MEM, OMEGA_IO } OmegaClass;
typedef enum { OMEGA_STATE_INIT = 0, OMEGA_STATE_DISCOVERED, OMEGA_STATE_EXECUTED, OMEGA_STATE_MAX } OmegaState;

typedef struct Omega {
    uint64_t id; uint16_t class; uint16_t subtype; uint32_t state;
    uint64_t capabilities; struct Omega* parent; struct Omega* child;
    struct Omega* sibling; uint32_t flags;
} Omega;

typedef struct { const char* source; size_t pos; size_t len; } HDGLParser;

static Omega omega_root;
static Omega omega_devices[256];
static size_t omega_count = 0;

static inline void hdgl_print(const char* str) { printf("%s", str); }

static inline Omega* hdgl_glyph(OmegaClass cls, const char* name) {
    if (omega_count >= 256) return NULL;
    Omega* omega = &omega_devices[omega_count++];
    omega->id = omega_count; omega->class = cls; omega->state = OMEGA_STATE_INIT;
    omega->parent = NULL; omega->child = NULL; omega->sibling = NULL; omega->flags = 0;
    return omega;
}

static inline void hdgl_mutate(Omega* omega, OmegaState new_state) { omega->state = new_state; }

static inline Omega* hdgl_branch(Omega* parent, Omega* child) {
    child->parent = parent;
    if (!parent->child) parent->child = child;
    else {
        Omega* sibling = parent->child;
        while (sibling->sibling) sibling = sibling->sibling;
        sibling->sibling = child;
    }
    child->sibling = NULL;
    return child;
}

static inline void hdgl_recurse(Omega* root, void (*fn)(Omega*)) {
    Omega* current = root->child;
    while (current) { fn(current); current = current->sibling; }
}

static inline void hdgl_skip_whitespace(HDGLParser* p) {
    while (p->pos < p->len && (p->source[p->pos] == ' ' || p->source[p->pos] == '\t' || p->source[p->pos] == '\n' || p->source[p->pos] == '\r')) p->pos++;
}

static inline void hdgl_parse_glyph(HDGLParser* p) {
    char name[64] = {0}; OmegaClass cls = OMEGA_CPU;
    size_t i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\n' && i < 63) name[i++] = p->source[p->pos++];
    name[i] = '\0';
    
    if (strstr(name, "ROOT") != NULL) cls = OMEGA_ROOT;
    else if (strstr(name, "CPU") != NULL) cls = OMEGA_CPU;
    else if (strstr(name, "MEM") != NULL) cls = OMEGA_MEM;
    else if (strstr(name, "IO") != NULL) cls = OMEGA_IO;
    
    Omega* parent = strstr(name, "root") != NULL ? &omega_root : strstr(name, "cpu") != NULL ? &omega_root : NULL;
    Omega* new_glyph = hdgl_glyph(cls, name);
    if (new_glyph && parent) hdgl_branch(parent, new_glyph);
    hdgl_print(name); hdgl_print(": Created\n");
}

static inline void hdgl_parse_mutate(HDGLParser* p) {
    static const char* states[] = {"INIT", "DISCOVERED", "CONFIGURED", "READY", "EXECUTED"};
    char state_name[32] = {0};
    size_t i = 0;
    while (p->pos < p->len && p->source[p->pos] != '\n' && i < 31) state_name[i++] = p->source[p->pos++];
    state_name[i] = '\0';
    
    Omega* active = &omega_root;
    for (int s = 0; s < 5; s++) {
        if (strstr(state_name, states[s]) != NULL) {
            hdgl_mutate(active, OMEGA_STATE_INIT + s);
            hdgl_print("mutated to "); hdgl_print(states[s]); hdgl_print("\n");
            break;
        }
    }
}

void hdgl_runtime_main(const char* source) {
    HDGLParser p; p.source = source; p.pos = 0; p.len = strlen(source);
    printf("HDGL RUNTIME - Pure Glyph Interpreter\n\n");
    
    while (p.pos < p.len) {
        hdgl_skip_whitespace(&p);
        if (p.pos >= p.len) break;
        
        if (p.source[p.pos] == 'g') { hdgl_parse_glyph(&p); continue; }
        if (p.source[p.pos] == 'm' && strstr(&p.source[p.pos], "mutate")) { hdgl_parse_mutate(&p); continue; }
        
        p.pos++;
    }
    printf("\nHDGL Execution Complete\n");
}

int main(void) {
    omega_root.id = 0; omega_root.class = OMEGA_ROOT; omega_root.state = OMEGA_STATE_INIT;
    printf("HDGL RUNTIME v1.0 - Glyph Interpreter\n");
    printf("Reset Vector: 0xFFFF:0000\n\n");
    
    const char* hdgl_source = "glyph root\nglyph cpu\nbranch cpu memory\nrecurse cpu\nmutate discovered\nmutate executed\n";
    hdgl_runtime_main(hdgl_source);
    return 0;
}
