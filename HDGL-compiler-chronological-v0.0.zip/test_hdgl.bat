@echo off
REM ═══════════════════════════════════════════════════════════════════════════
REM HDGL Firmware Test Suite - PowerShell-independent
REM ═══════════════════════════════════════════════════════════════════════════

echo ╔══════════════════════════════════════════════════════════╗
echo ║  HDGL Firmware Test Suite v1.0                           ║
echo ║  Testing: Glyph → Assembly → Firmware                    ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

REM Test 1: Check if HDGL source exists
echo Test 1: Checking HDGL Source Files...
if exist firmware.hdgl (
    echo [OK] firmware.hdgl found
) else (
    echo [ERROR] firmware.hdgl not found
)

REM Test 2: Check if compiler source exists
echo.
echo Test 2: Checking HDGL Compiler Source...
if exist hdglc.c (
    echo [OK] hdglc.c found
) else (
    echo [ERROR] hdglc.c not found
)

REM Test 3: Count lines in files
echo.
echo Test 3: File Statistics...
if exist firmware.hdgl (
    find /C /V "" firmware.hdgl > temp_count.txt
    for /f %%a in ('type temp_count.txt') do (
        echo [INFO] firmware.hdgl has %%a lines
    )
    del temp_count.txt
)

if exist hdglc.c (
    find /C /V "" hdglc.c > temp_count.txt
    for /f %%a in ('type temp_count.txt') do (
        echo [INFO] hdglc.c has %%a lines
    )
    del temp_count.txt
)

REM Test 4: Check GCC availability
echo.
echo Test 4: Checking GCC Availability...
where gcc > null 2>nul
if %errorlevel% == 0 (
    echo [OK] GCC found
    gcc --version > null 2>&1
    for /f %%a in ('gcc --version ^| findstr /i "gcc"') do (
        echo [INFO] %%~a
    )
) else (
    echo [INFO] GCC not in PATH - manual installation required
    echo [INFO] Download from: https://winlibs.com
)

REM Test 5: Validate HDGL syntax
echo.
echo Test 5: Validating HDGL Syntax...
if exist firmware.hdgl (
    findstr /R "^\s*glyph\s+" firmware.hdgl > null 2>nul
    if %errorlevel% == 0 (
        set /p glyph_count=<nul
        findstr /C:"glyph root" firmware.hdgl > nul 2>&1
        if %errorlevel% == 0 (
            echo [OK] Found 'glyph root' definition
        )
        findstr /C:"glyph cpu" firmware.hdgl > nul 2>&1
        if %errorlevel% == 0 (
            echo [OK] Found 'glyph cpu' definition
        )
        findstr /C:"recurse" firmware.hdgl > nul 2>&1
        if %errorlevel% == 0 (
            echo [OK] Found 'recurse' statements
        )
        findstr /C:"mutate" firmware.hdgl > nul 2>&1
        if %errorlevel% == 0 (
            echo [OK] Found 'mutate' statements
        )
    )
)

REM Test 6: Validate compiler structure
echo.
echo Test 6: Validating Compiler Structure...
if exist hdglc.c (
    findstr /C:"typedef struct" hdglc.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] Parser structs defined
    )
    findstr /C:"OmegaTable" hdglc.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] Omega table defined
    )
    findstr /C:"emit_instruction" hdglc.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] Code generator defined
    )
    findstr /C:"\.code16" hdglc.c > nul 2>&1
    if %errorlevel% == 0 (
        echo [OK] x86 assembly output defined
    )
)

REM Test 7: Show expected workflow
echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║  HDGL Firmware Workflow                                  ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
echo Step 1: Compile HDGL compiler (requires GCC)
echo   gcc hdglc.c -o hdglc.exe
echo.
echo Step 2: Compile HDGL source
echo   hdglc.exe firmware.hdgl -o firmware.s
echo.
echo Step 3: Assemble
echo   as firmware.s -o firmware.o
echo.
echo Step 4: Link
echo   ld firmware.o -o firmware.bin
echo.
echo Step 5: Test in QEMU (if installed)
echo   qemu-system-x86_64 -bios firmware.bin -boot n

echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║  HDGL Firmware Pipeline Ready                            ║
echo ║  Glyph Source → Compiler → Assembly → Binary             ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
