HDGL Native Compiler - Self-Hosting Firmware Language

Contents:
  - hdgl_self_hosting_compiler.hdgl  : Self-hosting HDGL compiler source
  - hdgl_self_hosting_runtime_final.c : C runtime interpreter
  - hdgl_runtime_v3.c                 : Working runtime (file I/O support)
  - firmware.hdgl                     : Example HDGL firmware source

Usage:
  1. Compile runtime:
     clang-cl hdgl_self_hosting_runtime_final.c -o hdgl_self_hosting.exe

  2. Execute self-hosting compiler:
     .\hdgl_self_hosting.exe hdgl_self_hosting_compiler.hdgl

  3. Test with example firmware:
     .\hdgl_self_hosting.exe firmware.hdgl

Achievement: HDGL is a TRUE self-hosting language!
The compiler is written in HDGL, executes HDGL, and compiles HDGL.