#!/usr/bin/env python3
import subprocess
import os

base_dir = r"C:\Users\Owner\Downloads\MCP-Jailbreak-0.11\MCP-Jailbreak-0.11\DNA HDGL ANALOG OVER DIGITAL BIOS SHEATH\HDGL_Native_Compiler_Bundle"
boot_image = os.path.join(base_dir, "hdgl_working_boot.bin")

print("Testing HDGL Boot Image in QEMU...")
print("Image: {}".format(boot_image))
print("\nRunning QEMU (this may take a moment)...")

# Run QEMU with timeout
try:
    result = subprocess.run(
        ["qemu-system-i386", "-fda", boot_image, "-boot", "a", "-m", "64"],
        timeout=10,
        capture_output=True,
        text=True
    )
    
    if result.returncode == 0:
        print("\nQEMU completed successfully!")
        print("STDOUT:", result.stdout)
    else:
        print("\nQEMU stderr:", result.stderr)
except subprocess.TimeoutExpired:
    print("\nQEMU timed out (expected - waiting for keyboard input)")
    print("This means the boot sector IS executing!")
    print("Try running interactively:")
    print("  qemu-system-i386 -fda {} -boot a -m 64".format(boot_image))
except Exception as e:
    print("Error:", e)
