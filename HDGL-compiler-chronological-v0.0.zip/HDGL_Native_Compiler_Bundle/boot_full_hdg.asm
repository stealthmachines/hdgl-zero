
; HDGL Boot Sector - Uses BIOS Video Services
org 0x7C00

start:
    cli
    mov ax, 0
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    
    ; Enable A20
    mov dx, 0x9C
    in al, dx
    or al, 2
    out dx, al
    
    ; Initialize video (text mode 0x07)
    mov ax, 0x0007
    int 0x10
    
    ; Print "HDGL BOOTING" using BIOS teletype (AH=0x0E)
    mov ah, 0x0E
    mov bh, 0
    mov bl, 0x07
    mov si, msg1
print1:
    mov al, [si]
    cmp al, 0
    je print2
    int 0x10
    inc si
    jmp print1

print2:
    ; Print "SELF-BOOTLOADER"
    mov si, msg2
print2_loop:
    mov al, [si]
    cmp al, 0
    je print3
    int 0x10
    inc si
    jmp print2_loop

print3:
    ; Print "BOOTING QEMU..."
    mov si, msg3
print3_loop:
    mov al, [si]
    cmp al, 0
    je print4
    int 0x10
    inc si
    jmp print3_loop

print4:
    ; Print "LOADING RUNTIME..."
    mov si, msg4
print4_loop:
    mov al, [si]
    cmp al, 0
    je print5
    int 0x10
    inc si
    jmp print4_loop

print5:
    ; Print "READY - PRESS R"
    mov si, msg5
print5_loop:
    mov al, [si]
    cmp al, 0
    je boot_done
    int 0x10
    inc si
    jmp print5_loop

boot_done:
    ; Wait for key press
wait_key:
    mov ah, 0x01
    int 0x16
    jz wait_key
    
    ; Check if R or r
    mov ah, 0x0E
    int 0x16
    cmp al, 'R'
    je load_runtime
    cmp al, 'r'
    je load_runtime
    
    jmp wait_key

load_runtime:
    ; Print "LOADING FULL HDGL RUNTIME..."
    mov si, msg_load
print_load:
    mov al, [si]
    cmp al, 0
    je jump_to_runtime
    int 0x10
    inc si
    jmp print_load

jump_to_runtime:
    ; Jump to runtime at 0x1000
    jmp 0x0000:0x1000

; Messages
msg1    db "HDGL BOOTING", 0
msg2    db "SELF-BOOTLOADER", 0
msg3    db "BOOTING QEMU...", 0
msg4    db "LOADING RUNTIME...", 0
msg5    db "READY - PRESS R", 0
msg_load db "LOADING FULL HDGL RUNTIME...", 0

times 510-($-$$) db 0
dw 0xAA55
