
; ============================================================================
; HDGL Production Boot Sector - x86 Real Mode
; Entry Point: 0x7C00
; Purpose: Boot HDGL system in QEMU
; ============================================================================

org 0x7C00

;-----------------------------------------------------------------------------
; Section 1: Initialization
;-----------------------------------------------------------------------------
start:
    cli                              ; Disable interrupts
    
    ; Setup segments
    mov ax, 0x0000
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00                   ; Stack at end of boot sector
    
    ; Setup video mode 0x07 (80x25 text, green on black)
    mov ax, 0x0007
    int 0x10
    
    ; Enable A20 gate (needed for >1MB addressing)
    mov dx, 0x9C
    in al, dx
    or al, 0x02
    out dx, al
    
    ; Initialize BIOS data area
    mov ax, 0x0000
    mov es, ax
    
    ;-------------------------------------------------------------------------
    ; Section 2: Boot Messages
    ;-------------------------------------------------------------------------
    
    ; Print "HDGL Booting..."
    mov dx, msg_boot
print_boot:
    mov al, [dx]
    cmp al, 0
    je print_hdgl
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp print_boot

print_hdgl:
    ; Print "HDGL Self-Bootloader v1.0"
    mov dx, msg_hdgl
print_version:
    mov al, [dx]
    cmp al, 0
    je print_loading
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp print_version

print_loading:
    ; Print "Loading HDGL Runtime..."
    mov dx, msg_loading
print_loading_msg:
    mov al, [dx]
    cmp al, 0
    je display_info
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp print_loading_msg

display_info:
    ; Print system information
    mov dx, msg_info
print_info:
    mov al, [dx]
    cmp al, 0
    je setup_heap
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp print_info

setup_heap:
    ; Print "Heap initialized at 0x1000"
    mov dx, msg_heap
print_heap:
    mov al, [dx]
    cmp al, 0
    je print_waiting
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp print_heap

print_waiting:
    ; Print "Waiting for runtime..."
    mov dx, msg_waiting
print_waiting_msg:
    mov al, [dx]
    cmp al, 0
    je wait_loop
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp print_waiting_msg

wait_loop:
    ; Simple wait loop (could be replaced with disk loading)
    nop
    nop
    nop
    nop
    jmp wait_loop

;-----------------------------------------------------------------------------
; Section 3: Messages (stored in video memory area)
;-----------------------------------------------------------------------------

msg_boot    db 0Dh, 0Ah, "HDGL Booting...", 0
msg_hdgl    db 0Dh, 0Ah, "HDGL Self-Bootloader v1.0", 0
msg_loading db 0Dh, 0Ah, "Loading HDGL Runtime...", 0
msg_info    db 0Dh, 0Ah, "CPU: Intel/AMD x86", 0
msg_info2   db 0Dh, 0Ah, "Memory: 640 KB conventional", 0
msg_heap    db 0Dh, 0Ah, "Heap initialized at 0x001000", 0
msg_waiting db 0Dh, 0Ah, "Waiting for runtime...", 0

;-----------------------------------------------------------------------------
; Section 4: Disk Loading Routine (Simplified)
;-----------------------------------------------------------------------------
; Note: Full BIOS disk I/O is too large for boot sector
; For QEMU, we'll use a simplified approach

; Load runtime from sector 2 (offset 1024) into memory at 0x1000
; This is a placeholder - actual implementation would need:
; - INT 0x13 disk services
; - Sector reading loop
; - Memory copy
; - Segment setup

load_runtime_stub:
    ; Set up for disk read (simplified)
    mov ah, 0x02           ; AH=02: Read sectors
    mov al, 0x01           ; AL=1 sector
    mov dl, 0x80           ; DL=Drive 0 (floppy/hard)
    
    ; Sector number (sector 2 = 0x02)
    xor cx, cx             ; CH=0, CL=0
    mov ch, 0x02
    
    ; Head = 0
    mov dh, 0x00
    
    ; Cylinder = 0
    mov bx, 0x0000
    
    ; Pointer to buffer
    mov di, 0x1000
    
    ; Call disk read (INT 0x13)
    int 0x13
    
    ; Check for error
    jc load_error
    
    ; Set ES to segment 0
    mov ax, 0x0000
    mov es, ax
    
    ; Jump to runtime entry point (would be loaded at 0x1000)
    ; For now, just jump to a placeholder
    jmp 0x0000:0x1000

load_error:
    ; Display error
    mov dx, msg_error
print_error:
    mov al, [dx]
    cmp al, 0
    je loop_forever
    mov bh, 0x0F
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp print_error

msg_error db 0Dh, 0Ah, 0Dh, 0Ah, "DISK READ ERROR!", 0

;-----------------------------------------------------------------------------
; Section 5: Boot Loop
;-----------------------------------------------------------------------------
loop_forever:
    jmp loop_forever

;-----------------------------------------------------------------------------
; Section 6: PADDING
;-----------------------------------------------------------------------------
times 510-($-$$) db 0
dw 0xAA55                    ; MBR signature
