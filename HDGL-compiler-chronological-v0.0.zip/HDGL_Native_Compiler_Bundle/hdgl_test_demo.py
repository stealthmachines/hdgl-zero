#!/usr/bin/env python3
"""
HDGL Self-Bootloader Test Script
Demonstrates the complete HDGL boot and self-replication workflow
"""

import os
import sys

base_dir = r"C:\Users\Owner\Downloads\MCP-Jailbreak-0.11\MCP-Jailbreak-0.11\DNA HDGL ANALOG OVER DIGITAL BIOS SHEATH\HDGL_Native_Compiler_Bundle"

print("=" * 70)
print("HDGL SELF-BOOTLOADER - DEMONSTRATION")
print("=" * 70)

# Check if HDGL runtime exists
runtime_exe = os.path.join(base_dir, "hdgl_self_hosting.exe")
if not os.path.exists(runtime_exe):
    print("ERROR: hdgl_self_hosting.exe not found!")
    print("Run: clang-cl hdgl_self_hosting_runtime_final.c -o hdgl_self_hosting.exe")
    sys.exit(1)

print("\nRuntime executable found: {}".format(runtime_exe))

# Load HDGL bootloader source
hdgl_file = os.path.join(base_dir, "hdgl_self_bootloader.hdg")
if not os.path.exists(hdgl_file):
    print("ERROR: {} not found!".format(hdgl_file))
    sys.exit(1)

with open(hdgl_file, "r", encoding="utf-8") as f:
    hdgl_source = f.read()

print("\nHDGL source loaded: {} bytes".format(len(hdgl_source)))

# Parse and display key sections
print("\n" + "=" * 70)
print("HDGL SOURCE ANALYSIS")
print("=" * 70)

sections = [
    ("boot_stub", "Boot Stub"),
    ("omega_runtime", "Omega Runtime"),
    ("self_replicate_engine", "Self-Replication Engine"),
    ("default_program", "Default Program"),
    ("self_compile_loop", "Self-Compilation Loop")
]

for keyword, name in sections:
    if keyword in hdgl_source:
        print("\n[{}]".format(name))
        # Find section boundaries
        start = hdgl_source.find(keyword)
        if start != -1:
            # Get next section start or end of file
            next_start = len(hdgl_source)
            for k, n in sections:
                if k in hdgl_source and hdgl_source.find(k) > start:
                    next_start = min(next_start, hdgl_source.find(k))
            
            section = hdgl_source[start:next_start][:200].replace('\\n', '\n')
            print(section)
            print("...")

# Execute HDGL source through runtime
print("\n" + "=" * 70)
print("EXECUTING HDGL SOURCE THROUGH RUNTIME")
print("=" * 70)

import subprocess

result = subprocess.run(
    [runtime_exe, hdgl_file],
    capture_output=True,
    text=True,
    encoding="utf-8"
)

print(result.stdout)

if result.stderr:
    print("STDERR:", result.stderr)

# Summary
print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)

print("\nFiles in {}:".format(base_dir))
for f in os.listdir(base_dir):
    if f.endswith(('.bin', '.hdg', '.hdgl', '.c', '.exe', '.txt', '.md')):
        fpath = os.path.join(base_dir, f)
        if os.path.isfile(fpath):
            size = os.path.getsize(fpath)
            print("  {:40s} {:>8,} bytes".format(f, size))

print("\n" + "=" * 70)
print("NEXT STEPS")
print("=" * 70)

print("\n1. Test boot image in QEMU:")
print("   qemu-system-i386 -fda {} -boot a".format(os.path.join(base_dir, "hdgl_complete_boot_image.bin")))

print("\n2. Compile HDGL code to assembly:")
print("   {} {}".format(runtime_exe, hdgl_file))
print("   (Generates: hdgl_self_bootloader.s)")

print("\n3. Assemble to binary:")
print("   nasm -f bin hdgl_self_bootloader.s -o hdgl_bootloader.bin")

print("\n4. Flash to hardware (optional):")
print("   dd if={} of=/dev/sdX bs=512 count=2".format(os.path.join(base_dir, "hdgl_complete_boot_image.bin")))

print("\n5. Test self-replication:")
print("   Press 'R' when runtime is running")

print("\n" + "=" * 70)
print("HDGL Self-Bootloader Demonstration Complete!")
print("=" * 70)
