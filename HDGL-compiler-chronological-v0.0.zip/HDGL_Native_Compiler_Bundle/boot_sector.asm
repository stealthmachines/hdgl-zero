; Minimal HDGL Boot Sector - x86 Real Mode
org 0x7C00

start:
    cli
    mov ax, 0x0000
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    
    mov ax, 0x0007
    int 0x10
    
    mov dx, msg1
p1:
    mov al, [dx]
    cmp al, 0
    je p2
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp p1

p2:
    mov dx, msg2
p3:
    mov al, [dx]
    cmp al, 0
    je display
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp p3

display:
    mov dx, msg3
p4:
    mov al, [dx]
    cmp al, 0
    je p5
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp p4

p5:
    mov dx, msg4
p6:
    mov al, [dx]
    cmp al, 0
    je p7
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp p6

p7:
    mov dx, msg5
p8:
    mov al, [dx]
    cmp al, 0
    je wait
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp p8

wait:
wait_in:
    mov ah, 0x01
    int 0x16
    jz wait_in
    mov ah, 0x0E
    int 0x16
    cmp al, 'R'
    je trigger
    cmp al, 'r'
    je trigger
    jmp wait_in

trigger:
    mov dx, msgR
p9:
    mov al, [dx]
    cmp al, 0
    je loop
    mov bh, 0x07
    mov bl, 0x00
    mov ah, 0x0E
    int 0x10
    inc dx
    jmp p9

loop:
    jmp loop

msg1 db 0Dh, 0Ah, "HDGL Self-Bootloader", 0Dh, 0Ah
msg2 db "Booting from HDGL firmware...", 0Dh, 0Ah
msg3 db 0Dh, 0Ah, "HDGL Self-Bootloader v1.0", 0Dh, 0Ah
msg4 db "Press 'R' to trigger self-replication...", 0Dh, 0Ah
msg5 db "Glyph system: ACTIVE", 0Dh, 0Ah
msgR db 0Dh, 0Ah, "*** SELF-REPLICATION TRIGGERED! ***", 0Dh, 0Ah

times 510-($-$$) db 0
dw 0xAA55
