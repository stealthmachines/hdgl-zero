
; HDGL Runtime Stub - Displays full boot information
; Entry point: 0x1000

org 0x1000

entry:
    ; Setup stack
    mov sp, 0x7FFF
    
    ; Initialize VGA text mode
    mov ax, 0x0007
    int 0x10
    
    ; Clear screen (optional, BIOS already did this)
    
    ; Print full boot sequence using BIOS teletype
    mov ax, 0x0E0A  ; Extended teletype - print until CR
    mov bx, 0x0007  ; Attribute
    mov cx, 0x0000  ; Clear video
    mov dx, msg_full1
print_full1:
    mov al, [dx]
    cmp al, 0
    je print_full2
    int 0x10
    inc dx
    jmp print_full1

print_full2:
    mov dx, msg_full2
print_full2_loop:
    mov al, [dx]
    cmp al, 0
    je print_full3
    int 0x10
    inc dx
    jmp print_full2_loop

print_full3:
    mov dx, msg_full3
print_full3_loop:
    mov al, [dx]
    cmp al, 0
    je print_full4
    int 0x10
    inc dx
    jmp print_full3_loop

print_full4:
    mov dx, msg_full4
print_full4_loop:
    mov al, [dx]
    cmp al, 0
    je print_full5
    int 0x10
    inc dx
    jmp print_full4_loop

print_full5:
    mov dx, msg_full5
print_full5_loop:
    mov al, [dx]
    cmp al, 0
    je display_glyphs
    int 0x10
    inc dx
    jmp print_full5_loop

display_glyphs:
    ; Display glyph information (simulated)
    mov dx, msg_glyphs
print_glyphs:
    mov al, [dx]
    cmp al, 0
    je wait_key
    int 0x10
    inc dx
    jmp print_glyphs

wait_key:
    ; Wait for keyboard input
wait_input:
    mov ah, 0x01
    int 0x16
    jz wait_input
    
    ; Echo key
    mov ah, 0x0E
    int 0x16
    
    cmp al, 'Q'
    je quit
    cmp al, 'q'
    je quit
    
    jmp wait_input

quit:
    ; Exit gracefully
    mov ah, 0x30
    int 0x10
    
loop_forever:
    jmp loop_forever

; Full boot messages
msg_full1 db 0Dh, 0Ah, "=========================================="
msg_full2 db "HDGL FULL BOOT SEQUENCE", 0Dh, 0Ah
msg_full3 db "=========================================="
msg_full4 db "BIOS LOADED FROM SECTOR 0", 0Dh, 0Ah
msg_full5 db "BOOT SECTOR EXECUTED SUCCESSFULLY", 0Dh, 0Ah
msg_glyphs db 0Dh, 0Ah, "HDGL RUNTIME LOADED", 0Dh, 0Ah
msg_glyphs db "OMEGA GYPHL SYSTEM: INITIALIZED", 0Dh, 0Ah
msg_glyphs db "GLYPH COUNT: 23 (FULL SYSTEM)", 0Dh, 0Ah
msg_glyphs db 0Dh, 0Ah, "SELF-REPLICATION: ENABLED", 0Dh, 0Ah
msg_glyphs db 0Dh, 0Ah, "=========================================="
msg_glyphs db "PRESS 'R' TO TRIGGER SELF-REPLICATION", 0Dh, 0Ah
msg_glyphs db "PRESS 'Q' TO QUIT", 0Dh, 0Ah

times 4096-($-$$) db 0
