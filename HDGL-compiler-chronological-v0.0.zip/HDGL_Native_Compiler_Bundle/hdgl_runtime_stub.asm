
; Minimal HDGL Runtime Stub - Loads into memory at 0x1000
; Called by boot sector after loading from disk

org 0x1000

; Entry point
entry:
    ; Set up stack
    mov sp, 0x7FFF
    
    ; Initialize VGA text mode (already set by BIOS, but ensure it's correct)
    mov ax, 0x0007
    int 0x10
    
    ; Clear screen
    mov ax, 0x0000
    mov bx, 0x0000  ; Start of screen (0xB800:0000)
    mov cx, 0x1820  ; 80x25 = 2000 characters
    mov dh, 0x07    ; Attribute (green on black)
    mov si, msg_clear
clear_screen:
    mov al, [si]
    cmp al, 0
    je print_hdgl
    mov [bx], ax
    add bx, 2
    inc si
    loop clear_screen

print_hdgl:
    ; Print "HDGL System Booting..."
    mov bx, 0xB800
    mov si, msg_hdgl1
print_loop1:
    mov al, [si]
    cmp al, 0
    je print_hdgl2
    mov ah, 0x07
    mov [bx], ax
    add bx, 2
    inc si
    jmp print_loop1

print_hdgl2:
    ; Print "HDGL Self-Bootloader v1.0"
    mov bx, 0xB800
    mov si, msg_hdgl2
print_loop2:
    mov al, [si]
    cmp al, 0
    je print_ready
    mov ah, 0x07
    mov [bx], ax
    add bx, 2
    inc si
    jmp print_loop2

print_ready:
    ; Print "HDGL Runtime: READY"
    mov bx, 0xB800
    mov si, msg_ready
print_loop3:
    mov al, [si]
    cmp al, 0
    je print_wait
    mov ah, 0x07
    mov [bx], ax
    add bx, 2
    inc si
    jmp print_loop3

print_wait:
    ; Print "Ready to load full runtime..."
    mov bx, 0xB800
    mov si, msg_wait
print_loop4:
    mov al, [si]
    cmp al, 0
    je print_status
    mov ah, 0x07
    mov [bx], ax
    add bx, 2
    inc si
    jmp print_loop4

print_status:
    ; Print system status
    mov bx, 0xB800
    mov si, msg_status
print_loop5:
    mov al, [si]
    cmp al, 0
    je loop_forever
    mov ah, 0x07
    mov [bx], ax
    add bx, 2
    inc si
    jmp print_loop5

loop_forever:
    ; Wait forever
    nop
    nop
    jmp loop_forever

; Messages in memory (at offset 0x300)
msg_clear db 0Dh, 0Ah, "  "
msg_hdgl1 db 0Dh, 0Ah, "HDGL System Booting..."
msg_hdgl2 db 0Dh, 0Ah, "HDGL Self-Bootloader v1.0"
msg_ready db 0Dh, 0Ah, "HDGL Runtime: READY"
msg_wait  db 0Dh, 0Ah, "Ready to load full runtime..."
msg_status db 0Dh, 0Ah, "CPU: x86 | Mem: 640KB | Disk: HDGL Source"

; Padding to fill 4KB page
times 4096-($-$$) db 0
