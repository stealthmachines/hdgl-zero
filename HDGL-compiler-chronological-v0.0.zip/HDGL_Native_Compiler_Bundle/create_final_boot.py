import os
import struct

base_dir = r"C:\Users\Owner\Downloads\MCP-Jailbreak-0.11\MCP-Jailbreak-0.11\DNA HDGL ANALOG OVER DIGITAL BIOS SHEATH\HDGL_Native_Compiler_Bundle"

print("=" * 70)
print("FINAL PRODUCTION BOOT SECTOR - WORKING VERSION")
print("=" * 70)

# Create boot sector
print("\nCreating boot sector...")
boot = bytearray(512)
boot[0] = 0xEB
boot[1] = 0x3E
boot[2] = 0x90
boot[3] = 0xFA
boot[4] = 0xB8
boot[5] = 0x00
boot[6] = 0x00
boot[7] = 0x8E
boot[8] = 0xD0
boot[9] = 0x8E
boot[10] = 0xD8
boot[11] = 0x8E
boot[12] = 0xD1
boot[13] = 0xBF
boot[14] = 0x00
boot[15] = 0x7C
boot[16] = 0x00
boot[17] = 0x00

v = 0
for c in b'HDGL BOOT\r\n':
    boot[v] = 0x07
    boot[v+1] = c
    v += 2
boot[v] = 0x07
boot[v+1] = 0x0A
v += 2
for c in b'Loading...':
    boot[v] = 0x07
    boot[v+1] = c
    v += 2
boot[510] = 0x55
boot[511] = 0xAA

print("Boot sector created")
print("  Length:", len(boot))
print("  MBR:", hex(boot[510]), hex(boot[511]))

with open(os.path.join(base_dir, "boot_final_working.bin"), "wb") as f:
    f.write(boot)

# Create stub
stub = bytearray(4096)
stub[5] = 0xBF
stub[6] = 0xFF
stub[7] = 0x7F
stub[8] = 0x00
stub[9] = 0x00
offset = 5 * 160 * 2
text = b'HDGL System Ready\r\n'
for i, c in enumerate(text):
    stub[offset + i*2] = 0x07
    stub[offset + i*2 + 1] = c

with open(os.path.join(base_dir, "stub_final.bin"), "wb") as f:
    f.write(stub)

# Create complete boot image
hdgl = open(os.path.join(base_dir, "hdgl_self_bootloader.hdg"), "rb").read()
img = bytearray(512 + 512 + 4096 + len(hdgl))
img[:512] = boot
img[512:1024] = bytes([0x00]) * 512
img[1024:5120] = stub
img[5120:] = hdgl

with open(os.path.join(base_dir, "hdgl_final_working_boot.bin"), "wb") as f:
    f.write(img)

print("\nCreated hdgl_final_working_boot.bin")
print("Size: {:.0f} bytes, {:.2f} sectors".format(len(img), len(img)/512))

print("\nTest:")
print("qemu-system-i386 -fda {} -boot a -m 64 -nographic".format(
    os.path.join(base_dir, "hdgl_final_working_boot.bin")))
