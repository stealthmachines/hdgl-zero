import os

base_dir = r"C:\Users\Owner\Downloads\MCP-Jailbreak-0.11\MCP-Jailbreak-0.11\DNA HDGL ANALOG OVER DIGITAL BIOS SHEATH\HDGL_Native_Compiler_Bundle"

print("Creating boot sector that JUMPS to 0x1000 after printing...")

boot = bytearray(512)

# 1. JMP $+2
boot[0] = 0xEB
boot[1] = 0x3E
boot[2] = 0x90

# 2. Setup
boot[3] = 0xFA
boot[4] = 0xB8
boot[5] = 0x00
boot[6] = 0x00
boot[7] = 0x8E
boot[8] = 0xD0
boot[9] = 0x8E
boot[10] = 0xD8
boot[11] = 0x8E
boot[12] = 0xD1
boot[13] = 0xBF
boot[14] = 0x00
boot[15] = 0x7C
boot[16] = 0x00
boot[17] = 0x00

# 3. Print "HDGL BOOT" at top of screen (offset 0 in video memory)
v = 0
for i, c in enumerate(b'HDGL BOOT\r\n'):
    boot[v] = 0x07
    boot[v+1] = c
    v += 2

# 4. PRINT "JUMPING TO 0x1000..." at line 2 (offset 160*2 = 320)
# But first, move cursor to line 2 by printing LF
boot[v] = 0x07
boot[v+1] = 0x0A
v += 2

for i, c in enumerate(b'Jump to 0x1000\r\n'):
    boot[320 + i*2] = 0x07
    boot[320 + i*2 + 1] = c

# 5. FAR JMP to 0x0000:0x1000
# Far jump: IP = offset, CS = segment
# Instruction: EB (jmp), then 3 bytes for far offset (word offset, word segment)
# JMP 0x0000:0x1000 = EB 0x1000/256 (3) 0x1000&255 (0) 0x0000/256 (0) 0x0000&255 (0)
boot[28] = 0xEB
boot[29] = 0x03  # 0x1000 / 256 = 3
boot[30] = 0x00  # 0x1000 % 256 = 0
boot[31] = 0x00  # 0x0000 / 256 = 0
boot[32] = 0x00  # 0x0000 % 256 = 0

# 6. MBR
boot[510] = 0x55
boot[511] = 0xAA

with open(os.path.join(base_dir, "boot_jump.bin"), "wb") as f:
    f.write(boot)

print("Created boot_jump.bin")
print("Jump instruction at offset 28:", hex(boot[28]), hex(boot[29]), hex(boot[30]), hex(boot[31]), hex(boot[32]))

# Create stub at 0x1000
stub = bytearray(4096)
stub[5] = 0xBF
stub[6] = 0xFF
stub[7] = 0x7F
stub[8] = 0x00
stub[9] = 0x00
offset = 5 * 160 * 2
for i, c in enumerate(b'HDGL System Ready\r\n'):
    stub[offset + i*2] = 0x07
    stub[offset + i*2 + 1] = c

with open(os.path.join(base_dir, "stub_jump.bin"), "wb") as f:
    f.write(stub)

# Create boot image
hdgl = open(os.path.join(base_dir, "hdgl_self_bootloader.hdg"), "rb").read()
img = bytearray(512 + 512 + 4096 + len(hdgl))
img[:512] = boot
img[512:1024] = bytes([0x00]) * 512
img[1024:5120] = stub
img[5120:] = hdgl

with open(os.path.join(base_dir, "hdgl_working_boot_final.bin"), "wb") as f:
    f.write(img)

print("\nCreated hdgl_working_boot_final.bin")
print("Size: {:.0f} bytes, {:.2f} sectors".format(len(img), len(img)/512))

print("\nTest:")
print("qemu-system-i386 -fda {} -boot a -m 64 -nographic".format(
    os.path.join(base_dir, "hdgl_working_boot_final.bin")))
