/*
 * bench_hdgl.c — Benchmark / test / tune / refine harness
 *
 * Measures hdgl_analog_engine.c across all three primitives:
 *   1. dn_r()           — Dₙ(r) amplitude per slot
 *   2. dn_lattice_compute() — full 32-slot lattice + aggregate
 *   3. kuramoto_step()  — 8D RK4 (N²=64 sin calls / step)
 *   4. hdgl_analog_run() — full run to LOCK (1000 iters max)
 *
 * ROUND 1: baseline (current engine, naive N² Kuramoto)
 * ROUND 2: tuned (mean-field Kuramoto from conscious ll_analog — 4× fewer trig calls)
 * ROUND 3: phi-seeded init path correctness validation
 * ROUND 4: GOI/GUZ saturation test on phi_tick primitive
 */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <time.h>

/* ── Timer ── */
static double now_s(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

/* ── Constants (from conscious) ── */
#define PHI       1.6180339887498948
#define PHI_INV   0.6180339887498948
#define SQRT_PHI  1.2720196495140570
#define LN_PHI    0.4812118250596035
#define PI        3.14159265358979323846
#define DT        0.01
#define DIMS      8

static const double FIB[8]    = {1,1,2,3,5,8,13,21};
static const double PRIMES[8] = {2,3,5,7,11,13,17,19};
#define D_N_R  0.732

/* Kuramoto K/γ from conscious/ll_analog.c wu-wei ratios */
static const double K_PLUCK=5.0,  G_PLUCK=0.005;
static const double K_SUSTAIN=3.0,G_SUSTAIN=0.008;
static const double K_FT=2.0,     G_FT=0.010;
static const double K_LOCK=1.8,   G_LOCK=0.012;
#define CV_SUSTAIN  0.50
#define CV_FINETUNE 0.30
#define CV_LOCK     0.10
#define CV_LOCKED   0.05
#define VCO_FLOOR   0.1
#define SYNC_INT    8
#define SYNC_ALPHA  0.8
#define SYNC_PASSES 4

typedef enum { PLUCK=0, SUSTAIN=1, FINETUNE=2, LOCK=3 } APhase;

/* ── PHI SEED TABLE (from conscious, refactored) ── */
/* seed[i] = fib[i%8]*prime[i%8]*PHI^(1+(i%4))*65536 */
static const uint32_t PHI_SEEDS_CORRECT[16] = {
    0x00033C6F, 0x0007DAA6, 0x002A5C56, 0x008FEFA7,
    0x0058FDEB, 0x01104689, 0x03A82BC8, 0x0AAEC964,
    0x00033C6F, 0x0007DAA6, 0x002A5C56, 0x008FEFA7,
    0x0058FDEB, 0x01104689, 0x03A82BC8, 0x0AAEC964,
};
static const uint32_t PHI_SEEDS_OLD[16] = {
    0x00000003, 0x00000007, 0x0000002A, 0x0000008F,
    0x00000058, 0x00000110, 0x000003A8, 0x00000AAE,
    0x000004F1, 0x0000104F, 0x00002DA7, 0x00008EA6,
    0x00003C61, 0x0000A5C8, 0x0001DA68, 0x00057890,
};

/* ════════════════════════════════════════════════
 * BASELINE ENGINE (naive N² Kuramoto — current)
 * ════════════════════════════════════════════════ */

typedef struct {
    double theta[DIMS];
    double omega[DIMS];
    double omega0[DIMS];
    double re[DIMS], im[DIMS];
    double k_coupling, gamma;
    double omega_u;
    APhase aphase;
    int tick_count;
    double cv;
} Kuramoto8D_Naive;

static double dn_r(int n, double r, double Omega) {
    int idx = (n-1) % DIMS;
    return sqrt(PHI * FIB[idx] * pow(2.0,(double)n) * PRIMES[idx] * Omega) * r;
}

static uint32_t dn_lattice(double dn_out[32]) {
    uint32_t agg = 0;
    for (int s=1; s<=8; s++) {
        double r = 0.3 + 0.1*(s-1);
        double Om = 1.0 / pow(pow(PHI,s), 7.0);
        int b = (s-1)*4;
        for (int sl=0; sl<4; sl++) {
            int n = b+sl+1;
            double d = dn_r(n, r, Om);
            dn_out[n-1] = d;
            if (d > SQRT_PHI) agg |= (1u << (n-1));
        }
    }
    return agg;
}

static double compute_cv_naive(Kuramoto8D_Naive *s) {
    double sx=0, sy=0;
    for (int i=0; i<DIMS; i++) { sx+=s->re[i]; sy+=s->im[i]; }
    double R = sqrt(sx*sx+sy*sy)/DIMS;
    return 1.0-R;
}

static void kuramoto_step_naive(Kuramoto8D_Naive *s) {
    /* NAIVE: full N² sin() calls — 4 evals × 64 sin = 256 sin/step */
    double k1[DIMS],k2[DIMS],k3[DIMS],k4[DIMS],th[DIMS];
    double K=s->k_coupling, g=s->gamma;
    for (int i=0; i<DIMS; i++) {
        double sum=0;
        for (int j=0; j<DIMS; j++) sum+=sin(s->theta[j]-s->theta[i]);
        k1[i] = s->omega[i]*(1-g) + K*sum/DIMS;
    }
    for (int i=0; i<DIMS; i++) th[i]=s->theta[i]+0.5*DT*k1[i];
    for (int i=0; i<DIMS; i++) {
        double sum=0;
        for (int j=0; j<DIMS; j++) sum+=sin(th[j]-th[i]);
        k2[i] = s->omega[i]*(1-g)+K*sum/DIMS;
    }
    for (int i=0; i<DIMS; i++) th[i]=s->theta[i]+0.5*DT*k2[i];
    for (int i=0; i<DIMS; i++) {
        double sum=0;
        for (int j=0; j<DIMS; j++) sum+=sin(th[j]-th[i]);
        k3[i] = s->omega[i]*(1-g)+K*sum/DIMS;
    }
    for (int i=0; i<DIMS; i++) th[i]=s->theta[i]+DT*k3[i];
    for (int i=0; i<DIMS; i++) {
        double sum=0;
        for (int j=0; j<DIMS; j++) sum+=sin(th[j]-th[i]);
        k4[i] = s->omega[i]*(1-g)+K*sum/DIMS;
    }
    for (int i=0; i<DIMS; i++) {
        s->theta[i] += DT*(k1[i]+2*k2[i]+2*k3[i]+k4[i])/6.0;
        s->re[i] = cos(s->theta[i]);
        s->im[i] = sin(s->theta[i]);
    }
}

/* ════════════════════════════════════════════════
 * TUNED ENGINE (mean-field Kuramoto — from conscious/ll_analog.c)
 * Exact algebraic identity: Σⱼ sin(θⱼ−θᵢ) = Im_Σ·cosθᵢ − Re_Σ·sinθᵢ
 * Trig budget: 4×N sincos = 32 trig/step  (vs 256 naive)  → 8× reduction
 * ════════════════════════════════════════════════ */

typedef struct {
    double theta[DIMS];
    double omega[DIMS];
    double omega0[DIMS];
    double re[DIMS], im[DIMS];  /* re=cos(θ), im=sin(θ) — always current */
    double k_coupling, gamma;
    double omega_u;
    APhase aphase;
    int tick_count;
    double cv;
} Kuramoto8D_Tuned;

static double compute_cv_tuned(Kuramoto8D_Tuned *s) {
    double rx=0,ry=0;
    for (int i=0; i<DIMS; i++) { rx+=s->re[i]; ry+=s->im[i]; }
    return 1.0-sqrt(rx*rx+ry*ry)/DIMS;
}

/* Mean-field derivative — N sincos per eval (vs N² sin naive) */
static void mf_deriv(const Kuramoto8D_Tuned *s, const double th[DIMS],
                     const double cs[DIMS], const double sn[DIMS],
                     double K, double g, double dt_half, double out[DIMS]) {
    double Re_S=0, Im_S=0;
    for (int j=0; j<DIMS; j++) { Re_S+=cs[j]; Im_S+=sn[j]; }
    for (int i=0; i<DIMS; i++)
        out[i] = s->omega[i]*(1-g) + K*(Im_S*cs[i]-Re_S*sn[i]);
}

static void kuramoto_step_tuned(Kuramoto8D_Tuned *s) {
    /* k1: reuse s->re/im — zero extra trig calls */
    double K=s->k_coupling, g=s->gamma;
    double Re_S1=0, Im_S1=0;
    for (int j=0; j<DIMS; j++) { Re_S1+=s->re[j]; Im_S1+=s->im[j]; }
    double k1[DIMS];
    for (int i=0; i<DIMS; i++)
        k1[i] = s->omega[i]*(1-g) + K*(Im_S1*s->re[i]-Re_S1*s->im[i]);

    /* k2: N sincos for t1 */
    double t1[DIMS], cs[DIMS], sn[DIMS], k2[DIMS];
    for (int i=0; i<DIMS; i++) t1[i]=s->theta[i]+0.5*DT*k1[i];
    for (int j=0; j<DIMS; j++) { cs[j]=cos(t1[j]); sn[j]=sin(t1[j]); }
    mf_deriv(s,t1,cs,sn,K,g,0.5*DT,k2);

    /* k3: N sincos for t2 */
    double t2[DIMS], k3[DIMS];
    for (int i=0; i<DIMS; i++) t2[i]=s->theta[i]+0.5*DT*k2[i];
    for (int j=0; j<DIMS; j++) { cs[j]=cos(t2[j]); sn[j]=sin(t2[j]); }
    mf_deriv(s,t2,cs,sn,K,g,0.5*DT,k3);

    /* k4: N sincos for t3 */
    double t3[DIMS], k4[DIMS];
    for (int i=0; i<DIMS; i++) t3[i]=s->theta[i]+DT*k3[i];
    for (int j=0; j<DIMS; j++) { cs[j]=cos(t3[j]); sn[j]=sin(t3[j]); }
    mf_deriv(s,t3,cs,sn,K,g,DT,k4);

    /* update + keep re/im consistent */
    for (int i=0; i<DIMS; i++) {
        s->theta[i] += (DT/6.0)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
        s->re[i] = cos(s->theta[i]);
        s->im[i] = sin(s->theta[i]);
    }
}

/* ════════════════════════════════════════════════
 * PHI TICK — firmware lattice primitive test
 * Tests GOI/GUZ saturation from conscious bootloaderZ
 * ════════════════════════════════════════════════ */
#define LATTICE_SLOTS 128
#define GOI_LIMIT  0xFFFF0000u
#define GUZ_LIMIT  0x00000100u

typedef struct {
    uint32_t slot[LATTICE_SLOTS];
    uint32_t tick;
    int goi_events;
    int guz_events;
} PhiLattice;

static void phi_lattice_init(PhiLattice *lat, const uint32_t seeds[16]) {
    lat->tick = 0; lat->goi_events = 0; lat->guz_events = 0;
    for (int i=0; i<LATTICE_SLOTS; i++) {
        uint32_t seed = seeds[i%16];
        if (i==0) { lat->slot[0]=seed; continue; }
        lat->slot[i] = lat->slot[i-1]*3 + seed;
    }
}

static void phi_tick(PhiLattice *lat) {
    lat->tick++;
    for (int i=0; i<LATTICE_SLOTS; i++) {
        if (lat->slot[i] >= GOI_LIMIT) {
            lat->slot[i] = GOI_LIMIT;
            lat->goi_events++;
        } else {
            uint32_t nxt = lat->slot[i]*3 + lat->tick;
            lat->slot[i] = nxt;
        }
        if (lat->slot[i] < GUZ_LIMIT) {
            lat->slot[i] = GUZ_LIMIT;
            lat->guz_events++;
        }
    }
}

static double phi_consensus(PhiLattice *lat) {
    uint64_t sum=0;
    for (int i=0; i<LATTICE_SLOTS; i++) sum+=lat->slot[i];
    uint32_t mean=(uint32_t)(sum/LATTICE_SLOTS);
    uint32_t max_dev=0;
    for (int i=0; i<LATTICE_SLOTS; i++) {
        uint32_t d = lat->slot[i]>mean ? lat->slot[i]-mean : mean-lat->slot[i];
        if (d>max_dev) max_dev=d;
    }
    return (mean>0) ? (double)max_dev/(double)mean : 1.0;
}

/* ════════════════════════════════════════════════
 * BENCHMARK RESULT STRUCT
 * ════════════════════════════════════════════════ */
typedef struct {
    const char *name;
    double mean_us, min_us, max_us;
    int iters;
    double throughput;
} BenchResult;

static volatile double g_sink = 0.0;
static volatile uint32_t g_sink_u = 0;

#define BENCH_REPS 5

static BenchResult bench_run(const char *name, int N, void(*fn)(int, double*),
                              double *out) {
    double times[BENCH_REPS];
    for (int rep=0; rep<BENCH_REPS; rep++) {
        double t0 = now_s();
        fn(N, out);
        times[rep] = now_s()-t0;
    }
    double mn=times[0], mx=times[0], sum=0;
    for (int i=0; i<BENCH_REPS; i++) {
        if(times[i]<mn) mn=times[i];
        if(times[i]>mx) mx=times[i];
        sum+=times[i];
    }
    BenchResult r;
    r.name=name; r.iters=N;
    r.mean_us=sum/BENCH_REPS/N*1e6;
    r.min_us=mn/N*1e6;
    r.max_us=mx/N*1e6;
    r.throughput=N/(sum/BENCH_REPS);
    return r;
}

static void print_result(const BenchResult *r) {
    printf("  %-52s  mean=%7.3f µs  min=%7.3f  max=%7.3f  [%8d iters]  %9.0f ops/s\n",
           r->name, r->mean_us, r->min_us, r->max_us, r->iters, r->throughput);
}

static void print_tsv(FILE *f, const BenchResult *r) {
    fprintf(f, "%s\t%.4f\t%.4f\t%.4f\t%d\t%.0f\n",
            r->name, r->mean_us, r->min_us, r->max_us, r->iters, r->throughput);
}

/* ════════════════════════════════════════════════════════════
 * MAIN BENCHMARK SUITE
 * ════════════════════════════════════════════════════════════ */

static void bmark_dn_r_slot(int N, double *acc) {
    *acc=0;
    for (int i=0; i<N; i++) {
        int n=(i%32)+1;
        double r=0.3+0.1*(n%8);
        double Om=1.0/pow(pow(PHI,(n%8)+1),7.0);
        *acc+=dn_r(n,r,Om);
    }
    g_sink = *acc;
}

static void bmark_dn_lattice(int N, double *acc) {
    double dn[32];
    *acc=0;
    for (int i=0; i<N; i++) *acc+=(double)dn_lattice(dn);
    g_sink = *acc;
}

static Kuramoto8D_Naive  g_naive;
static Kuramoto8D_Tuned  g_tuned;

static void init_osc_naive(Kuramoto8D_Naive *s) {
    s->aphase=PLUCK; s->k_coupling=K_PLUCK; s->gamma=G_PLUCK;
    s->omega_u=0.5; s->tick_count=0; s->cv=1.0;
    double Lambda=1.618, frac_L=0.618;
    double Omega=0.5*(1+sin(PI*frac_L*PHI));
    for (int i=0; i<DIMS; i++) {
        s->theta[i]=PI*frac_L+2*PI*(0.618*PHI_INV+frac_L+i*D_N_R);
        s->omega0[i]=Omega*pow(PHI,1.0+i*D_N_R)*DT;
        s->omega[i]=s->omega0[i];
        s->re[i]=cos(s->theta[i]);
        s->im[i]=sin(s->theta[i]);
    }
}

static void init_osc_tuned(Kuramoto8D_Tuned *s) {
    s->aphase=PLUCK; s->k_coupling=K_PLUCK; s->gamma=G_PLUCK;
    s->omega_u=0.5; s->tick_count=0; s->cv=1.0;
    double Lambda=1.618, frac_L=0.618;
    double Omega=0.5*(1+sin(PI*frac_L*PHI));
    for (int i=0; i<DIMS; i++) {
        s->theta[i]=PI*frac_L+2*PI*(0.618*PHI_INV+frac_L+i*D_N_R);
        s->omega0[i]=Omega*pow(PHI,1.0+i*D_N_R)*DT;
        s->omega[i]=s->omega0[i];
        s->re[i]=cos(s->theta[i]);
        s->im[i]=sin(s->theta[i]);
    }
}

static void bmark_kuramoto_naive(int N, double *acc) {
    *acc=0;
    for (int i=0; i<N; i++) {
        kuramoto_step_naive(&g_naive);
        *acc+=g_naive.cv;
    }
    g_sink = *acc;
}
static void bmark_kuramoto_tuned(int N, double *acc) {
    *acc=0;
    for (int i=0; i<N; i++) {
        kuramoto_step_tuned(&g_tuned);
        *acc+=g_tuned.cv;
    }
    g_sink = *acc;
}

/* ════════════════════════════════════════════════
 * CORRECTNESS TESTS
 * ════════════════════════════════════════════════ */

static int test_dn_aggregate(void) {
    double dn[32];
    uint32_t agg = dn_lattice(dn);
    /* Expected from conscious compute_Dn_r: 0x80C0C0E8 */
    uint32_t expected = 0x80C0C0E8;
    int pass = (agg == expected);
    printf("  [TEST] Dn aggregate: got 0x%08X  expected 0x%08X  %s\n",
           agg, expected, pass?"PASS":"FAIL");
    return pass;
}

static int test_phi_seed_correctness(void) {
    /* Verify our refactored seeds are phi-harmonic (not the old arbitrary constants) */
    PhiLattice lat_new, lat_old;
    phi_lattice_init(&lat_new, PHI_SEEDS_CORRECT);
    phi_lattice_init(&lat_old, PHI_SEEDS_OLD);
    /* Run 100 ticks */
    for (int i=0; i<100; i++) { phi_tick(&lat_new); phi_tick(&lat_old); }
    /* New seeds should reach lower consensus variance (phi-harmonic = better spread) */
    double cv_new = phi_consensus(&lat_new);
    double cv_old = phi_consensus(&lat_old);
    int pass = (cv_new <= cv_old);
    printf("  [TEST] Phi seed quality: new_cv=%.4f  old_cv=%.4f  %s\n",
           cv_new, cv_old, pass?"PASS (new seeds better/equal)":"NOTE (old seeds tighter)");
    return 1; /* Informational — not a hard pass/fail */
}

static int test_goi_guz_saturation(void) {
    PhiLattice lat;
    phi_lattice_init(&lat, PHI_SEEDS_CORRECT);
    /* Force a slot to GOI territory */
    lat.slot[0] = GOI_LIMIT;
    phi_tick(&lat);
    int goi_ok = (lat.slot[0] == GOI_LIMIT);
    /* Force a slot to GUZ territory */
    lat.slot[1] = 1;
    phi_tick(&lat);
    int guz_ok = (lat.slot[1] == GUZ_LIMIT);
    printf("  [TEST] GOI saturation: slot stays at 0x%08X  %s\n",
           lat.slot[0], goi_ok?"PASS":"FAIL");
    printf("  [TEST] GUZ floor: slot floored to 0x%08X  %s\n",
           lat.slot[1], guz_ok?"PASS":"FAIL");
    return goi_ok && guz_ok;
}

static int test_kuramoto_lock(void) {
    Kuramoto8D_Tuned s;
    init_osc_tuned(&s);
    /* Run to convergence */
    int steps=0, locked=0;
    for (int i=0; i<2000 && !locked; i++) {
        kuramoto_step_tuned(&s);
        s.cv = compute_cv_tuned(&s);
        steps++;
        /* Phase transitions */
        if (s.aphase==PLUCK && s.cv<CV_SUSTAIN) {
            s.aphase=SUSTAIN; s.gamma=G_SUSTAIN;
        } else if (s.aphase==SUSTAIN && s.cv<CV_FINETUNE) {
            s.aphase=FINETUNE; s.gamma=G_FT;
        } else if (s.aphase==FINETUNE && s.cv<CV_LOCK) {
            s.aphase=LOCK; s.gamma=G_LOCK;
        }
        if (s.aphase==LOCK && s.cv<CV_LOCKED) locked=1;
    }
    const char *names[]={"PLUCK","SUSTAIN","FINETUNE","LOCK"};
    printf("  [TEST] Kuramoto LOCK: %s in %d steps, CV=%.6f  %s\n",
           names[s.aphase], steps, s.cv, locked?"PASS":"PARTIAL (CV=%.6f)");
    return locked;
}

/* ════════════════════════════════════════════════
 * PHI TICK LATTICE BENCHMARK
 * ════════════════════════════════════════════════ */
static PhiLattice g_lat_new, g_lat_old;
static void bmark_phi_tick_new(int N, double *acc) {
    *acc=0;
    for (int i=0; i<N; i++) { phi_tick(&g_lat_new); *acc+=g_lat_new.slot[0]; }
    g_sink_u = (uint32_t)*acc;
}
static void bmark_phi_tick_old(int N, double *acc) {
    *acc=0;
    for (int i=0; i<N; i++) { phi_tick(&g_lat_old); *acc+=g_lat_old.slot[0]; }
    g_sink_u = (uint32_t)*acc;
}

int main(void) {
    FILE *tsv = fopen("bench_hdgl_results.tsv","w");
    if (tsv) fprintf(tsv,"function\tmean_us\tmin_us\tmax_us\titers\tops_per_s\n");

    printf("\n");
    printf("══════════════════════════════════════════════════════════════════════\n");
    printf("  HDGL ANALOG ENGINE — Benchmark / Test / Tune / Refine\n");
    printf("  Round 1: Baseline  |  Round 2: Tuned  |  Round 3: Correctness\n");
    printf("══════════════════════════════════════════════════════════════════════\n\n");

    /* ── ROUND 1: Correctness Tests ── */
    printf("── ROUND 1: CORRECTNESS TESTS ──────────────────────────────────────\n");
    int all_pass = 1;
    all_pass &= test_dn_aggregate();
    all_pass &= test_phi_seed_correctness();
    all_pass &= test_goi_guz_saturation();
    all_pass &= test_kuramoto_lock();
    printf("  Overall: %s\n\n", all_pass?"ALL PASS":"FAILURES — see above");

    /* ── ROUND 2: Dn(r) Benchmarks ── */
    printf("── ROUND 2: Dn(r) PRIMITIVES ────────────────────────────────────────\n");
    double acc=0;
    BenchResult r;

    r = bench_run("dn_r(n,r,Omega) — single slot amplitude",
                  500000, bmark_dn_r_slot, &acc);
    print_result(&r); if(tsv) print_tsv(tsv,&r);

    r = bench_run("dn_lattice_compute() — 32-slot + aggregate",
                  100000, bmark_dn_lattice, &acc);
    print_result(&r); if(tsv) print_tsv(tsv,&r);
    printf("\n");

    /* ── ROUND 3: Kuramoto Naive vs Tuned ── */
    printf("── ROUND 3: KURAMOTO RK4 — NAIVE N² vs TUNED MEAN-FIELD ─────────────\n");
    printf("  Naive:  4 evals × N² sin = 256 sin/step\n");
    printf("  Tuned:  4 evals × N sincos = 32 trig/step  (8× reduction from conscious)\n\n");

    init_osc_naive(&g_naive);
    init_osc_tuned(&g_tuned);

    r = bench_run("kuramoto_step NAIVE  (N²=64 sin/eval, 256/step)",
                  200000, bmark_kuramoto_naive, &acc);
    BenchResult r_naive = r;
    print_result(&r); if(tsv) print_tsv(tsv,&r);

    init_osc_naive(&g_naive);
    init_osc_tuned(&g_tuned);

    r = bench_run("kuramoto_step TUNED  (mean-field, 32 trig/step)",
                  200000, bmark_kuramoto_tuned, &acc);
    BenchResult r_tuned = r;
    print_result(&r); if(tsv) print_tsv(tsv,&r);

    printf("\n  Speedup: %.2fx  (mean-field vs naive)\n\n",
           r_naive.mean_us / r_tuned.mean_us);

    /* ── ROUND 4: Phi Tick Lattice — Seed Quality ── */
    printf("── ROUND 4: PHI_TICK — SEED COMPARISON (refactored vs original) ──────\n");
    printf("  Old seeds: arbitrary raw constants (files__12_.zip)\n");
    printf("  New seeds: phi-harmonic (fib×prime×PHI^n×65536 from conscious)\n\n");

    phi_lattice_init(&g_lat_new, PHI_SEEDS_CORRECT);
    phi_lattice_init(&g_lat_old, PHI_SEEDS_OLD);

    r = bench_run("phi_tick lattice — old seeds (arbitrary constants)",
                  500000, bmark_phi_tick_old, &acc);
    print_result(&r); if(tsv) print_tsv(tsv,&r);

    phi_lattice_init(&g_lat_new, PHI_SEEDS_CORRECT);
    phi_lattice_init(&g_lat_old, PHI_SEEDS_OLD);

    r = bench_run("phi_tick lattice — new seeds (phi-harmonic, conscious)",
                  500000, bmark_phi_tick_new, &acc);
    print_result(&r); if(tsv) print_tsv(tsv,&r);

    /* Post-100-tick consensus comparison */
    phi_lattice_init(&g_lat_new, PHI_SEEDS_CORRECT);
    phi_lattice_init(&g_lat_old, PHI_SEEDS_OLD);
    for (int i=0; i<1000; i++) { phi_tick(&g_lat_new); phi_tick(&g_lat_old); }
    printf("\n  After 1000 ticks:\n");
    printf("    Old seeds consensus variance: %.6f\n", phi_consensus(&g_lat_old));
    printf("    New seeds consensus variance: %.6f\n", phi_consensus(&g_lat_new));
    printf("    GOI events (new): %d\n", g_lat_new.goi_events);
    printf("    GUZ events (new): %d\n", g_lat_new.guz_events);

    /* ── SUMMARY ── */
    printf("\n");
    printf("══════════════════════════════════════════════════════════════════════\n");
    printf("  SUMMARY TABLE\n");
    printf("══════════════════════════════════════════════════════════════════════\n");
    printf("  Correctness:   %s\n", all_pass?"ALL PASS":"CHECK ABOVE");
    printf("  Dn(r) slot:    %.3f µs/call\n", 
           (double)(bench_run("",500000,bmark_dn_r_slot,&acc)).mean_us);
    printf("  Kuramoto tuned vs naive speedup gleaned from conscious/ll_analog.c\n");
    printf("  Phi seeds: phi-harmonic (conscious) vs raw (old)\n");
    printf("  GOI/GUZ: 0x%08X / 0x%08X (bootloaderZ V6.0)\n", GOI_LIMIT, GUZ_LIMIT);
    printf("══════════════════════════════════════════════════════════════════════\n\n");

    if (tsv) fclose(tsv);
    printf("  Results written to bench_hdgl_results.tsv\n\n");
    return 0;
}
