#!/bin/bash
# HDGL Firmware — refactored build
# Requires: gcc, nasm (nasm used only for binary output; runtime.asm is NASM-macro-free)
#
# REFACTOR vs original:
#   - firmware_runtime.asm: NO %define/%macro/equ NASM-isms in logic
#   - firmware_runtime.asm: NO xor reg,reg for zero-init → mov reg,0
#   - firmware_runtime.asm: NO xor-based crypto → phi_fold (additive) throughout
#   - hdgl_boot_stub.asm:   NO xor ax,ax → mov ax,0 for segment flatten
#   - phi_seed_table gleaned from conscious-128-bit-floor ll_analog.c:
#       seed[i] = fib[i%8] * prime[i%8] * PHI^(1+(i%4)) * 65536
#   - Dn aggregate 0x80C0C0E8 computed from conscious ll_analog compute_Dn_r
#   - GOI=0xFFFF0000 / GUZ=0x00000100 from conscious bootloaderZ V6.0
set -e
echo "[1/4] Compile bootstrap..."
gcc -O2 -std=c99 hdgl_bootstrap.c -o hdgl_bootstrap -lm

echo "[2/4] Parse glyphs -> emit x86 (refactored: xor-free, phi-seeded)..."
./hdgl_bootstrap hdgl_firmware.hdgl firmware_runtime.asm

echo "[3/4] Assemble (nasm binary output only; asm source is macro-free)..."
nasm -f bin hdgl_boot_stub.asm -o hdgl_boot_stub.bin
nasm -f bin firmware_runtime.asm -o firmware_runtime.bin

echo "[4/4] Compose image..."
SRCSEC=$(( ($(wc -c < hdgl_firmware.hdgl) + 511) / 512 ))
IMGSZ=$(( (18 + SRCSEC) * 512 ))
dd if=/dev/zero bs=$IMGSZ count=1 of=hdgl_firmware.img 2>/dev/null
dd if=hdgl_boot_stub.bin  bs=512 count=1        seek=0  conv=notrunc of=hdgl_firmware.img 2>/dev/null
dd if=firmware_runtime.bin bs=512 count=16      seek=1  conv=notrunc of=hdgl_firmware.img 2>/dev/null
dd if=hdgl_firmware.hdgl   bs=512 count=$SRCSEC seek=18 conv=notrunc of=hdgl_firmware.img 2>/dev/null
echo ""
echo "Done: hdgl_firmware.img"
echo "Run:  qemu-system-x86_64 -drive file=hdgl_firmware.img,format=raw,if=ide -boot order=c -m 64M -no-reboot -display none -serial stdio"
echo "Flash: dd if=hdgl_firmware.img of=/dev/sdX bs=512 oflag=sync"
echo ""
echo "REFACTOR SUMMARY (gleaned from conscious-128-bit-floor):"
echo "  - phi_seed_table: fib*prime*PHI^n*65536 (not arbitrary raw constants)"
echo "  - register zero: mov reg,0 (not xor reg,reg)"
echo "  - segment zero: mov ax,0 (not xor ax,ax)"
echo "  - omega region zero: explicit mov dword loop (not xor+rep stosd)"
echo "  - reset zero: explicit mov dword loop (not xor eax,eax + rep stosd)"
echo "  - phi_lk_read: additive (acc*3+byte+lattice) (not xor-based hash)"
echo "  - Dn aggregate: 0x80C0C0E8 (verified from ll_analog compute_Dn_r)"
echo "  - GOI/GUZ: 0xFFFF0000/0x00000100 (from bootloaderZ V6.0)"
echo "  - NASM macros: eliminated from runtime (no %define, no equ in logic)"
