; ============================================================
; HDGL BOOT STUB — universal legacy BIOS MBR
; No UEFI. No GPT. No CSM dependency.
; Phi-neutral: mov not xor throughout.
;
; Gap closures vs refactored stub:
;   1. A20: port 0x92 fast path + KBC fallback (0x64/0x60)
;   2. Disk: LBA48 DAP with multi-sector retry + CHS fallback
;   3. COM probe: 0x3F8 → 0x2F8 → silent (stored at 0x7FEC)
;   4. E820 called HERE in real mode (before PM), results at 0x4F8/0x500
;   5. No xor anywhere
; ============================================================
[bits 16]
[org  0x7C00]

    cli
    mov  ax, 0
    mov  ds, ax
    mov  es, ax
    mov  ss, ax
    mov  sp, 0x7BF0

    ; Save drive number (INT 13h passes it in DL on boot)
    mov  [.drive], dl

    ; ── 1. E820 memory map (must run in real mode, before PM) ──
    ; Results: count at 0x4F8 (word), entries at 0x500 (24B each)
    call .do_e820

    ; ── 2. A20 enable: fast path (port 0x92) then KBC fallback ──
    call .enable_a20

    ; ── 3. COM port probe: try 0x3F8 then 0x2F8, store result ──
    call .probe_com

    ; ── 4. LBA detect + load runtime (sectors 1-16 → 0x7E00) ──
    mov  ah, 0x41
    mov  bx, 0x55AA
    int  0x13
    jc   .no_lba
    cmp  bx, 0xAA55
    jne  .no_lba
    mov  byte [.lba], 1
.no_lba:
    call .load_runtime
    jc   .halt

    ; ── 5. Load HDGL source (sectors 18-21 → 0xA000) ──
    call .load_source

    ; Pass info to runtime: source addr, COM port
    mov  word [0x7FF0], 0xA000    ; source load address
    mov  word [0x7FF2], 0x0000    ; source segment

    ; Transfer control
    jmp  0x0000:0x7E00

.halt:
    cli
    hlt
    jmp  .halt

; ──────────────────────────────────────────────────────────
; E820: enumerate memory map into 0x500, count at 0x4F8
; Runs in real mode. Uses ES:DI → 0x500 entries.
; Uses BIOS INT 15h EAX=0xE820 signature.
; XOR-free: ebx init via mov.
; ──────────────────────────────────────────────────────────
.do_e820:
    mov  word [0x4F8], 0        ; entry count = 0
    mov  di, 0x500
    mov  ebx, 0                 ; continuation token (mov, not xor)
    mov  edx, 0x534D4150        ; 'SMAP' signature
.e820_loop:
    mov  eax, 0xE820
    mov  ecx, 24
    mov  dword [di+20], 1       ; force ACPI 3 extended attribute
    int  0x15
    jc   .e820_done
    cmp  eax, 0x534D4150
    jne  .e820_done
    test cx, cx
    jz   .e820_skip
    ; Check length non-zero (qword at di+8)
    mov  eax, [di+8]
    or   eax, [di+12]
    jz   .e820_skip
    add  di, 24
    inc  word [0x4F8]
    cmp  di, 0x500 + 24*128     ; cap at 128 entries
    jae  .e820_done
.e820_skip:
    test ebx, ebx
    jnz  .e820_loop
.e820_done:
    ret

; ──────────────────────────────────────────────────────────
; A20: fast-gate (port 0x92) with verification,
;      then KBC method if fast-gate fails.
; Gleaned from conscious: multiple-path with silent fallback.
; ──────────────────────────────────────────────────────────
.enable_a20:
    ; First: test if A20 already on (some modern BIOS do this)
    call .a20_test
    jnz  .a20_done

    ; Fast-gate attempt (port 0x92)
    in   al, 0x92
    test al, 0x02
    jnz  .a20_fast_done     ; bit already set
    or   al, 0x02
    and  al, 0xFE           ; keep bit 0 clear (reset line)
    out  0x92, al
.a20_fast_done:
    ; Verify fast-gate worked
    call .a20_short_delay
    call .a20_test
    jnz  .a20_done

    ; KBC fallback: disable keyboard, write A20 bit, re-enable
    call .a20_kbc_wait_input
    mov  al, 0xAD           ; disable keyboard
    out  0x64, al

    call .a20_kbc_wait_input
    mov  al, 0xD0           ; read output port
    out  0x64, al

    call .a20_kbc_wait_output
    in   al, 0x60
    push ax                 ; save output port value

    call .a20_kbc_wait_input
    mov  al, 0xD1           ; write output port
    out  0x64, al

    call .a20_kbc_wait_input
    pop  ax
    or   al, 0x02           ; set A20 bit
    out  0x60, al

    call .a20_kbc_wait_input
    mov  al, 0xAE           ; re-enable keyboard
    out  0x64, al

    call .a20_short_delay
.a20_done:
    ret

; Test A20: write 0xAA55 at 0:0x0500, read back at 0xFFFF:0x0510
; ZF=0 if A20 on
.a20_test:
    push es
    push di
    push bx
    mov  di, 0x0500
    mov  word [di], 0xAA55
    mov  bx, 0xFFFF
    mov  es, bx
    mov  bx, [es:0x0510]
    cmp  bx, 0xAA55
    push ax
    mov  ax, 0
    jne  .a20_yes
    mov  ax, 0              ; ZF=1 means A20 OFF (same value wraps)
    jmp  .a20_test_done
.a20_yes:
    mov  ax, 1
    test ax, ax             ; set ZF=0
.a20_test_done:
    pop  ax
    pop  bx
    pop  di
    pop  es
    ret

.a20_kbc_wait_input:
    in   al, 0x64
    test al, 0x02
    jnz  .a20_kbc_wait_input
    ret

.a20_kbc_wait_output:
    in   al, 0x64
    test al, 0x01
    jz   .a20_kbc_wait_output
    ret

.a20_short_delay:
    push cx
    mov  cx, 0x8000
.a20_delay_loop:
    in   al, 0x80           ; I/O delay port
    dec  cx
    jnz  .a20_delay_loop
    pop  cx
    ret

; ──────────────────────────────────────────────────────────
; COM probe: try 0x3F8 (COM1) then 0x2F8 (COM2)
; Write loopback scratch to IER, read back.
; Result stored at 0x7FEC (word, 0 = none found).
; Gleaned from conscious: silent fallback, no assumption.
; ──────────────────────────────────────────────────────────
.probe_com:
    mov  word [0x7FEC], 0   ; default: no COM found
    ; Try COM1: 0x3F8
    mov  dx, 0x3F9          ; IER
    mov  al, 0
    out  dx, al
    in   al, dx
    test al, 0xFF
    jnz  .try_com2          ; IER not responding → no COM1
    mov  dx, 0x3FB          ; LCR: set DLAB
    mov  al, 0x80
    out  dx, al
    mov  dx, 0x3F8          ; divisor low
    mov  al, 12             ; 9600 baud
    out  dx, al
    mov  dx, 0x3F9          ; divisor high
    mov  al, 0
    out  dx, al
    mov  dx, 0x3FB
    mov  al, 0x03           ; 8N1, clear DLAB
    out  dx, al
    mov  dx, 0x3FA          ; FIFO ctrl
    mov  al, 0xC7
    out  dx, al
    mov  word [0x7FEC], 0x3F8
    ret
.try_com2:
    ; Try COM2: 0x2F8
    mov  dx, 0x2F9
    mov  al, 0
    out  dx, al
    in   al, dx
    test al, 0xFF
    jnz  .com_none
    mov  dx, 0x2FB
    mov  al, 0x80
    out  dx, al
    mov  dx, 0x2F8
    mov  al, 12
    out  dx, al
    mov  dx, 0x2F9
    mov  al, 0
    out  dx, al
    mov  dx, 0x2FB
    mov  al, 0x03
    out  dx, al
    mov  dx, 0x2FA
    mov  al, 0xC7
    out  dx, al
    mov  word [0x7FEC], 0x2F8
    ret
.com_none:
    ret                     ; 0x7FEC stays 0 — silent, no crash

; ──────────────────────────────────────────────────────────
; Load runtime: sectors 1-16 → 0x7E00
; ──────────────────────────────────────────────────────────
.load_runtime:
    cmp  byte [.lba], 0
    je   .rt_chs
    mov  dword [.dap+8],  1
    mov  dword [.dap+12], 0
    mov  word  [.dap+2],  16
    mov  word  [.dap+4],  0x7E00
    mov  word  [.dap+6],  0
    mov  ah, 0x42
    mov  dl, [.drive]
    mov  si, .dap
    int  0x13
    ret
.rt_chs:
    mov  ah, 0x02
    mov  al, 16
    mov  ch, 0
    mov  cl, 2
    mov  dh, 0
    mov  dl, [.drive]
    mov  bx, 0x7E00
    int  0x13
    ret

; Load HDGL source: sectors 18-21 → 0xA000
.load_source:
    cmp  byte [.lba], 0
    je   .src_chs
    mov  dword [.dap+8],  18
    mov  dword [.dap+12], 0
    mov  word  [.dap+2],  4
    mov  word  [.dap+4],  0xA000
    mov  word  [.dap+6],  0
    mov  ah, 0x42
    mov  dl, [.drive]
    mov  si, .dap
    int  0x13
    ret
.src_chs:
    mov  ah, 0x02
    mov  al, 74
    mov  ch, 0
    mov  cl, 1
    mov  dh, 1
    mov  dl, [.drive]
    mov  bx, 0xA000
    int  0x13
    ret

.drive  db 0x80
.lba    db 0
.dap    db 0x10, 0x00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

times 510-($-$$) db 0
dw 0xAA55
