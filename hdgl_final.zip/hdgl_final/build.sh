#!/bin/bash
# HDGL Universal Firmware — complete build
# Requires: nasm, gcc
set -e

echo "[1] MBR stage1 (sector 0, 512B)..."
nasm -f bin src/hdgl_mbr.asm -o bin/hdgl_mbr.bin

echo "[2] Stage2 stub (sector 1, 512B: A20+KBC+E820+COM+load)..."
nasm -f bin src/hdgl_stage2.asm -o bin/hdgl_stage2.bin

echo "[3] Runtime64 (sectors 2-17, 8KB: 64-bit long mode phi-lattice)..."
nasm -f bin src/hdgl_runtime64.asm -o bin/hdgl_runtime64.bin

echo "[4] UEFI stub (PE32+ EFI application, prefers legacy)..."
nasm -f bin src/hdgl_uefi_stub.asm -o uefi/BOOTX64.EFI

echo "[5] Conscious OS port self-test..."
gcc -O3 -std=c99 -D_POSIX_C_SOURCE=200809L src/conscious_os_port.c -o bin/cos_test -lm
./bin/cos_test

echo "[6] Disk image..."
SRC=src/hdgl_firmware.hdgl
SRCSEC=$(( ($(wc -c < $SRC) + 511)/512 ))
TOTAL=$(( 18 + SRCSEC + 4 ))
dd if=/dev/zero bs=512 count=$TOTAL of=bin/hdgl_universal.img 2>/dev/null
dd if=bin/hdgl_mbr.bin       bs=512 count=1        seek=0  conv=notrunc of=bin/hdgl_universal.img 2>/dev/null
dd if=bin/hdgl_stage2.bin    bs=512 count=1        seek=1  conv=notrunc of=bin/hdgl_universal.img 2>/dev/null
dd if=bin/hdgl_runtime64.bin bs=512 count=16       seek=2  conv=notrunc of=bin/hdgl_universal.img 2>/dev/null
dd if=$SRC                   bs=512 count=$SRCSEC  seek=18 conv=notrunc of=bin/hdgl_universal.img 2>/dev/null

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Done. Run:"
echo ""
echo "  Legacy BIOS (any x86, 2008+):"
echo "  qemu-system-x86_64 \\"
echo "    -drive file=bin/hdgl_universal.img,format=raw,if=ide \\"
echo "    -boot order=c -m 64M -serial stdio"
echo ""
echo "  UEFI (Q35 + OVMF, prefers legacy, falls back):"
echo "  qemu-system-x86_64 -machine q35 -m 128M \\"
echo "    -bios /usr/share/ovmf/OVMF.fd \\"
echo "    -drive file=uefi/hdgl_esp.img,format=raw,if=ide \\"
echo "    -boot order=c -serial stdio"
echo ""
echo "  Flash:"
echo "  dd if=bin/hdgl_universal.img of=/dev/sdX bs=512 oflag=sync"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
